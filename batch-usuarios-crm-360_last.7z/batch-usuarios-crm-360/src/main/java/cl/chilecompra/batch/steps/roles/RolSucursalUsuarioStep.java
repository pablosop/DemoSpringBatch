package cl.chilecompra.batch.steps.roles;

import javax.sql.DataSource;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;
import cl.chilecompra.batch.dto.RolSucursalUsuarioDTO;
import cl.chilecompra.batch.listener.rol.RolSucursalUsuarioListener;
import cl.chilecompra.batch.mapper.rol.RolSucursalUsuarioRowMapper;
import cl.chilecompra.batch.processor.rol.RolSucursalUsuarioProcessor;



@Configuration
public class RolSucursalUsuarioStep {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;
    
    @Value("${step.reintentos}")
    private Integer reintentos;
    
    @Value("${step.cantidad.lote}")
    private Integer tamañoLote;

    @Value("${step.cantidad.tolerancia.skip}")
    private Integer tolerancia;
    
    private final RolSucursalUsuarioProcessor rolSucursalUsuarioProcessor;

    public RolSucursalUsuarioStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			            @Qualifier("origenDataSource") DataSource sourceDataSource,
			            @Qualifier("destinoDataSource") DataSource targetDataSource,
			            RolSucursalUsuarioProcessor rolSucursalUsuarioProcessor){
		this.jobRepository                   = jobRepository;
		this.transactionManager              = transactionManager;
		this.sourceDataSource                = sourceDataSource;
		this.targetDataSource                = targetDataSource;
		this.rolSucursalUsuarioProcessor             = rolSucursalUsuarioProcessor;	
				
	}
    
    // Reader
    @Bean
    public JdbcCursorItemReader<RolSucursalUsuarioDTO> rolSucursalUsuarioReader(RolSucursalUsuarioRowMapper rolSucursalUsuarioRowMapper) {
        return new JdbcCursorItemReaderBuilder<RolSucursalUsuarioDTO>()
                .name("RolSucursalUsuarioReader")
                .dataSource(sourceDataSource)
                .sql("SELECT r.uroRole\r\n"
                		+ "	,r.uroOrganization\r\n"
                		+ "	,r.uroUser\r\n"
                		+ "	,r.uroIsActive\r\n"
                		+ "FROM dbo.gblSecUserRole r\r\n"
                		+ "JOIN dbo.gbluser u ON r.uroUser = u.usrCode\r\n"
                		+ "JOIN dbo.gblOrganization o ON r.uroOrganization = o.orgCode\r\n"
                		+ "WHERE r.uroIsActive = 1\r\n"
                		+ "	AND o.orgClass = 1\r\n"
                        + "	AND o.orgIsActive = 1\r\n"
                		+ "	AND u.usrLastLogin >= DATEADD(month, - 12, GETDATE())\r\n"
                		+ "GROUP BY r.uroRole\r\n"
                		+ "	,r.uroOrganization\r\n"
                		+ "	,r.uroUser\r\n"
                		+ "	,r.uroIsActive")
                .rowMapper(rolSucursalUsuarioRowMapper)
                .fetchSize(tamañoLote)
                .build();
    }

    // Writer
    @Bean
    public JdbcBatchItemWriter<RolSucursalUsuarioDTO> RolSucursalUsuario1Writer() {
        return new JdbcBatchItemWriterBuilder<RolSucursalUsuarioDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO ROL_SUCURSAL_USUARIO\r\n"
                		+ "(ID_ROL_SUCURSAL, ID_USUARIO, ID_ESTADOACTIVO, CREACION, CREACIONFECHA)\r\n"
                		+ "VALUES(:idRolSucursal, :idUsuario, :idEstadoActivo, :creacion, :creacionFecha)\r\n"
                		+ "    ON DUPLICATE KEY update\r\n"
                		+ "    ID_ESTADOACTIVO    = values(ID_ESTADOACTIVO), \r\n"
                		+ "    ACTUALIZACION      = :actualizacion, \r\n"
                		+ "    ACTUALIZACIONFECHA = :actualizacionFecha")
                .dataSource(targetDataSource)
                .build();
    }
    
   
    // Step
    @Bean
    public Step rolSucursalUsuario1Step(RolSucursalUsuarioListener listener, RolSucursalUsuarioRowMapper rolSucursalUsuarioRowMapper) {
        return new StepBuilder("rolSucursalUsuario1Step", jobRepository)
                .<RolSucursalUsuarioDTO, RolSucursalUsuarioDTO>chunk(tamañoLote, transactionManager)
                .reader(rolSucursalUsuarioReader(rolSucursalUsuarioRowMapper))
                .processor(rolSucursalUsuarioProcessor)
                .writer(RolSucursalUsuario1Writer())
                .listener((ItemReadListener<? super RolSucursalUsuarioDTO>) listener)
                .listener((ItemProcessListener<? super RolSucursalUsuarioDTO, ? super RolSucursalUsuarioDTO>) listener)
                .listener((ItemWriteListener<? super RolSucursalUsuarioDTO>) listener)
                .listener((StepExecutionListener) listener)
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(tolerancia) 
                .retryLimit(reintentos)
                .retry(Exception.class)      
                .build();
    }
        
}
