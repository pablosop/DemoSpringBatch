package cl.chilecompra.batch.processor.usuario;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.TipoUsuarioDTO;


@Component
public class ObtenerTipoUsuarioProcessor implements ItemProcessor<TipoUsuarioDTO, TipoUsuarioDTO> {

	private Map<Integer, String> userMap = new HashMap<>();
    

    @Override
    public TipoUsuarioDTO process(TipoUsuarioDTO item) {
        String idUsuario = userMap.get(Integer.valueOf(item.getUroUser()));
        if (idUsuario != null) {
            item.setId_usuario(idUsuario);
            return item;
        }
	     return null;               
     }

     @BeforeStep
    public void beforeStep(StepExecution stepExecution) {        
        JobExecution jobExecution = stepExecution.getJobExecution();
        this.userMap = (Map<Integer, String>) jobExecution.getExecutionContext().get("userMap");        
    }
}
