package cl.chilecompra.batch.runner;

import java.util.concurrent.locks.ReentrantLock;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class JobRunner {

    private final JobLauncher jobLauncher;
    private final Job usuariosETL;
    private final ReentrantLock lock = new ReentrantLock(); // Mecanismo de bloqueo

    public JobRunner(JobLauncher jobLauncher, @Qualifier("usuariosETL") Job usuariosETL) {
        this.jobLauncher = jobLauncher;
        this.usuariosETL = usuariosETL;
    }

    @Scheduled(cron = "${job.scheduler.cron}")
    public void runJobFromCron() {
        runJob("Cron automatico");
    }

    @Async
    public void runJobFromService() {
        runJob("Servicio web asincrono");
    }
    
    public boolean isJobRunning() {
        return lock.isLocked();
    }

    private void runJob(String source) {
        if (lock.tryLock()) {
            try {
                JobParameters jobParameters = new JobParametersBuilder()
                        .addLong("time", System.currentTimeMillis())
                        .toJobParameters();

                JobExecution execution = jobLauncher.run(usuariosETL, jobParameters);
                log.info("Estado del Job iniciado desde {}: {}", source, execution.getStatus());
            } catch (Exception e) {
                log.error("Error al ejecutar el Job desde {}: ", source, e);
            } finally {
                lock.unlock(); // Liberar el bloqueo al terminar
                System.exit(0);
            }
        } else {
            log.warn("El Job ya está en ejecución. Intento iniciado desde: {}", source);
        }
    }
}
