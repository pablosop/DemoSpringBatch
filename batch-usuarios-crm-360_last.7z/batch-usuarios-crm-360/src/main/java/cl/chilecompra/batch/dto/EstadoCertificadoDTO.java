package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;

@Data
public class EstadoCertificadoDTO {

    private Long idEstadoCertificado;
    private String estadoCertificado;
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;

}
