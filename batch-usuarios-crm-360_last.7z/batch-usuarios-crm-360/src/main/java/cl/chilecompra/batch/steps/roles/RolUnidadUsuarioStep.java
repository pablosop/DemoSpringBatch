package cl.chilecompra.batch.steps.roles;

import javax.sql.DataSource;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import cl.chilecompra.batch.dto.RolUnidadUsuarioDTO;
import cl.chilecompra.batch.listener.rol.RolUnidadUsuarioListener;
import cl.chilecompra.batch.mapper.rol.RolUnidadUsuarioRowMapper;
import cl.chilecompra.batch.processor.rol.RolUnidadUsuarioProcessor;

@Configuration
public class RolUnidadUsuarioStep {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;
    
    @Value("${step.reintentos}")
    private Integer reintentos;
    
    @Value("${step.cantidad.lote}")
    private Integer tamañoLote;

    @Value("${step.cantidad.tolerancia.skip}")
    private Integer tolerancia;
    
    private final RolUnidadUsuarioProcessor rolUnidadUsuarioDTOProcessor;

    public RolUnidadUsuarioStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			            @Qualifier("origenDataSource") DataSource sourceDataSource,
			            @Qualifier("destinoDataSource") DataSource targetDataSource,
			            RolUnidadUsuarioProcessor rolUnidadUsuarioDTOProcessor){
		this.jobRepository           = jobRepository;
		this.transactionManager      = transactionManager;
		this.sourceDataSource        = sourceDataSource;
		this.targetDataSource        = targetDataSource;
		this.rolUnidadUsuarioDTOProcessor     = rolUnidadUsuarioDTOProcessor;		
		
	}
    
    // Reader
    @Bean
    public JdbcCursorItemReader<RolUnidadUsuarioDTO> rolUnidadUsuarioReader(RolUnidadUsuarioRowMapper rolUnidadUsuarioRowMapper) {
        return new JdbcCursorItemReaderBuilder<RolUnidadUsuarioDTO>()
                .name("RolUnidadUsuarioReader")
                .dataSource(sourceDataSource)
                .sql("SELECT r.uroRole\r\n"
                		+ "	  ,r.uroUser\r\n"
                		+ "	  ,r.uroOrganization\r\n"
                		+ "	  ,r.uroIsActive\r\n"
                		+ " FROM dbo.gblSecUserRole r\r\n"
                		+ " JOIN dbo.gbluser u ON r.uroUser = u.usrCode\r\n"
                		+ " JOIN gblOrganization go2 ON r.uroOrganization = go2.orgCode\r\n"
                		+ "WHERE\r\n"
                		+ "  -- r.uroIsActive = 1\r\n"
                		+ "  go2.orgIsActive = 1\r\n"
                		+ "  AND u.usrIsActive = 1\r\n"
                		+ "  AND go2.orgClass = 2\r\n"
                		+ "  AND u.usrLastLogin >= DATEADD(month, - 12, GETDATE())\r\n"
                		+ "GROUP BY r.uroRole\r\n"
                		+ "	    ,r.uroUser\r\n"
                		+ "	    ,r.uroOrganization\r\n"
                		+ "	    ,r.uroIsActive")
                .rowMapper(rolUnidadUsuarioRowMapper)
                .fetchSize(tamañoLote)
                .build();
    }

    // Writer
    @Bean
    public JdbcBatchItemWriter<RolUnidadUsuarioDTO> rolUnidadUsuarioWriter() {
        return new JdbcBatchItemWriterBuilder<RolUnidadUsuarioDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO ROL_UNIDAD_USUARIO\r\n"
                		+ "(ID, ID_ROL_UNIDAD, ID_USUARIO, ID_ESTADOACTIVO, CREACION, CREACIONFECHA)\r\n"
                		+ "VALUES(:id, :idRolUnidad, :idUsuario, :uroIsActive, :creacion, :creacionFecha)\r\n"
                		+ "    ON DUPLICATE KEY update\r\n"
                		+ "    ID_ESTADOACTIVO = values(ID_ESTADOACTIVO), \r\n"
                		+ "    ACTUALIZACION   = :actualizacion, \r\n"
                		+ "    ACTUALIZACIONFECHA = :actualizacionFecha")
                .dataSource(targetDataSource)
                .build();
    }
       
    
    // Step
    @Bean
    public Step rolUnidadUsuario1Step(RolUnidadUsuarioListener listener, RolUnidadUsuarioRowMapper rolUnidadUsuarioRowMapper) {
        return new StepBuilder("rolUnidadUsuario1Step", jobRepository)
                .<RolUnidadUsuarioDTO, RolUnidadUsuarioDTO>chunk(tamañoLote, transactionManager)
                .reader(rolUnidadUsuarioReader(rolUnidadUsuarioRowMapper))
                .processor(rolUnidadUsuarioDTOProcessor)
                .writer(rolUnidadUsuarioWriter())
                .listener((ItemReadListener<? super RolUnidadUsuarioDTO>) listener)
                .listener((ItemProcessListener<? super RolUnidadUsuarioDTO, ? super RolUnidadUsuarioDTO>) listener)
                .listener((ItemWriteListener<? super RolUnidadUsuarioDTO>) listener)
                .listener((StepExecutionListener) listener)
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(tolerancia) 
                .retryLimit(reintentos)
                .retry(Exception.class)      
                .build();
    }
    
}
