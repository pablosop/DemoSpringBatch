package cl.chilecompra.batch.steps.parametros;
import javax.sql.DataSource;

import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import cl.chilecompra.batch.dto.OrganismoDTO;
import cl.chilecompra.batch.listener.organismo.OrganismoListener;
import cl.chilecompra.batch.mapper.parametros.OrganismoParametroRowMapper;

@Configuration
public class OrganismoParametrosStep {
    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;
    
    @Value("${step.reintentos}")
    private Integer reintentos;
    
    @Value("${step.cantidad.lote}")
    private Integer tamañoLote;
    
    public OrganismoParametrosStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			            @Qualifier("origenDataSource") DataSource sourceDataSource,
			            @Qualifier("destinoDataSource") DataSource targetDataSource) {
		this.jobRepository = jobRepository;
		this.transactionManager = transactionManager;
		this.sourceDataSource = sourceDataSource;
		this.targetDataSource = targetDataSource;
	}
    
    // Reader
    @Bean
    public JdbcCursorItemReader<OrganismoDTO> organismoReader(OrganismoParametroRowMapper organismoRowMapper) {
        return new JdbcCursorItemReaderBuilder<OrganismoDTO>()
                .name("OrganismoDTOReader")
                .dataSource(sourceDataSource)
                .sql("WITH aux_OrgTaxIDUnicos AS (" 
                    +  "select x.orgTaxID, count(1) cta from ( "
                    +  "select orgTaxID, orgEnterprise, count(*) cant from gblOrganization  "
                    +  "group by orgTaxID, orgEnterprise) x "
                    +  "group by x.orgTaxID having count(1) > 1), "
                    +  "aux_EntIDUnicos AS (select x.orgEnterprise, count(1) cta from ("
                    +  "select orgEnterprise, orgTaxID, count(*) cant from gblOrganization  "
                    +  "group by orgEnterprise, orgTaxID ) x "
                    +  "group by x.orgEnterprise having count(1) > 1) "
                    +  "SELECT DISTINCT e.entCode, o.orgTaxID, e.entName FROM dbo.gblenterprise e "
                    +  "INNER JOIN dbo.gblOrganization o ON e.entcode = o.orgenterprise "
                    +  "INNER JOIN dbo.gblSecUserRole ur ON ur.uroOrganization = o.orgCode "
                    +  "INNER JOIN dbo.gblUser gu ON gu.usrCode = ur.uroUser "
                    +  "WHERE e.entIsActive = 1 "
                    +  "AND o.orgIsActive = 1 AND o.orgClass = 1 AND gu.usrLastLogin >=  DATEADD(month, -12, GETDATE()) "
                    +  "AND o.orgTaxID not in (SELECT orgTaxID from aux_OrgTaxIDUnicos)  "
                    +  "AND e.entCode not in (SELECT orgEnterprise from aux_EntIDUnicos) "                    
                )
                .rowMapper(organismoRowMapper)
                .fetchSize(tamañoLote)
                .build();
    }

    // Writer
    @Bean
    public JdbcBatchItemWriter<OrganismoDTO> organismoWriter() {
        return new JdbcBatchItemWriterBuilder<OrganismoDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO ORGANISMO (ID_ORGANISMO, CODIGO, RUT, ORGANISMO, CREACION, CREACIONFECHA) VALUES (:idOrganismo, :codigo, :rut, :organismo, :creacion, :creacionFecha) " +
                     "ON DUPLICATE KEY UPDATE ORGANISMO = VALUES(ORGANISMO), ACTUALIZACION = :actualizacion, ACTUALIZACIONFECHA = :actualizacionFecha")
                .dataSource(targetDataSource)
                .build();
    }

    // Step
    @Bean
    public Step organismoParametroStep(OrganismoListener listener, OrganismoParametroRowMapper organismoRowMapper) {
        return new StepBuilder("organismoParametroStep", jobRepository)
                .<OrganismoDTO, OrganismoDTO>chunk(tamañoLote, transactionManager)
                .reader(organismoReader(organismoRowMapper))
                .writer(organismoWriter())
                .listener((StepExecutionListener) listener)
                .listener((ItemReadListener<? super OrganismoDTO>) listener)
                .listener((ItemWriteListener<? super OrganismoDTO>) listener)
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(reintentos)
                .build();
    }


    


}

