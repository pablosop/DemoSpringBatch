package cl.chilecompra.batch.mapper.rol;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.RolUnidadDTO;
import cl.chilecompra.batch.utils.FechasUtils;

@Component
public class RolUnidadRowMapper implements RowMapper<RolUnidadDTO> {
	
    private final String nombreCreacion;

    public RolUnidadRowMapper(@Value("${batch.nombre.rol.unidad}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }
    
    @Override
    public RolUnidadDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	RolUnidadDTO rolUnidad = new RolUnidadDTO();
    	
		FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();  
        
    	rolUnidad.setUroRole        (rs.getInt("uroRole"));	
    	rolUnidad.setUroOrganization(rs.getInt("uroOrganization"));
    	rolUnidad.setOrgClass       (rs.getInt("orgClass"));
    	rolUnidad.setUroIsActive    (rs.getInt("uroIsActive"));
    	
    	rolUnidad.setIdEstadoActivo(1);
    	rolUnidad.setCreacion(nombreCreacion);
    	rolUnidad.setCreacionFecha(fechaActual);
    	rolUnidad.setActualizacion(nombreCreacion);
    	rolUnidad.setActualizacionFecha(fechaActual);    	
    	
        return rolUnidad;
    }
}

