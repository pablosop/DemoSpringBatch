package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;

@Data
public class UsuarioCertificacionDTO {

    private Long id;
    private String idUsuario;
    private int idCursoCertificado;
    private int idNivelCertificado;
    private int idEstadoCertificado;
    private int idEstadoActivo;
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;

}
