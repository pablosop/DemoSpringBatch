package cl.chilecompra.batch.steps.parametros;

import javax.sql.DataSource;

import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import cl.chilecompra.batch.dto.InstitucionDTO;
import cl.chilecompra.batch.listener.parametros.InstitucionListener;
import cl.chilecompra.batch.mapper.parametros.InstitucionRowMapper;

@Configuration
public class InstitucionStep {

	private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;
    
    @Value("${step.reintentos}")
    private Integer reintentos;
    
    @Value("${step.cantidad.lote}")
    private Integer tamañoLote;
        
    public InstitucionStep(JobRepository jobRepository, 
    		               PlatformTransactionManager transactionManager,
			               @Qualifier("origenDataSource") DataSource sourceDataSource,
			               @Qualifier("destinoDataSource") DataSource targetDataSource) {
		this.jobRepository = jobRepository;
		this.transactionManager = transactionManager;
		this.sourceDataSource = sourceDataSource;
		this.targetDataSource = targetDataSource;
	}
    
    // Reader
    @Bean
    public JdbcCursorItemReader<InstitucionDTO> institucionReader(InstitucionRowMapper institucionRowMapper) {
        return new JdbcCursorItemReaderBuilder<InstitucionDTO>()
                .name("InstitutoDTOReader")
                .dataSource(sourceDataSource)
                .sql("SELECT e.entID, e.entName \r\n" +
                                        "FROM dbo.gblenterprise e \r\n" +
                                        "JOIN dbo.gblOrganization o \r\n" +
                                        "ON e.entcode = o.orgenterprise \r\n" +
                                        "WHERE \r\n" +
                                        " e.entIsActive = 1\r\n" +
                                        " and o.orgIsActive = 1 \r\n" +
                                        " and o.orgClass = 2 \r\n" +
                                        "GROUP BY\r\n" +
                                        " e.entID,\r\n" +
                                        " e.entName\r\n")
                .rowMapper(institucionRowMapper)
                .fetchSize(tamañoLote)
                .build();
    }

    // Writer
    @Bean
    public JdbcBatchItemWriter<InstitucionDTO> institucionWriter() {
        return new JdbcBatchItemWriterBuilder<InstitucionDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO INSTITUCION (ID_INSTITUCION, CODIGO, INSTITUCION, CREACION, CREACIONFECHA)  \r\n"
                		+ "VALUES (:idInstitucion, :codigo, :institucion, :creacion, :creacionFecha)  \r\n"
                		+ "ON DUPLICATE KEY UPDATE \r\n"
                		+ "    INSTITUCION        = VALUES(INSTITUCION), \r\n"                		
                		+ "    ACTUALIZACION      = :actualizacion, \r\n"
                		+ "    ACTUALIZACIONFECHA = :actualizacionFecha")
                .dataSource(targetDataSource)
                .build();
    }

    // Step
    @Bean
    public Step institucion1Step(InstitucionListener listener, InstitucionRowMapper institucionRowMapper) {
        return new StepBuilder("institucion1Step", jobRepository)
                .<InstitucionDTO, InstitucionDTO>chunk(tamañoLote, transactionManager)
                .reader(institucionReader(institucionRowMapper))
                .writer(institucionWriter())
                .listener((StepExecutionListener) listener)
                .listener((ItemReadListener<? super InstitucionDTO>) listener)
                .listener((ItemWriteListener<? super InstitucionDTO>) listener)
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(reintentos)
                .build();
    }


    


}
