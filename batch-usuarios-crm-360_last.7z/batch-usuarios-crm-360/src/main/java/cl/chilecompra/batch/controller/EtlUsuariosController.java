package cl.chilecompra.batch.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.chilecompra.batch.runner.JobRunner;

@RestController
@RequestMapping("/v1/batch-crm-360")
public class EtlUsuariosController {

    @Value("${service.api-key}")
    private String apiKeyConfig;
	
    private final JobRunner jobRunner;

    public EtlUsuariosController(JobRunner jobRunner) {
        this.jobRunner = jobRunner;
    }


    @PostMapping("/usuarios-etl")
    public ResponseEntity<String> runUsuariosETL(@RequestHeader("api-key") String apiKey) {
    	if (!apiKeyConfig.equals(apiKey)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Invalid API key");
        }
    	
        if (jobRunner.isJobRunning()) {
        	return ResponseEntity.ok("ETL ya se encuentra en ejecución por CRON.");
        }
        jobRunner.runJobFromService(); // Llamada asíncrona
            return ResponseEntity.ok("ETL se ha iniciado correctamente y se está ejecutando en segundo plano.");
    }
}
