package cl.chilecompra.batch.mapper.parametros;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.OrganismoDTO;
import cl.chilecompra.batch.utils.FechasUtils;

@Component
public class OrganismoParametroRowMapper implements RowMapper<OrganismoDTO> {

    private static final Date FECHA_ACTUAL = new Date();
    
    private final String nombreCreacion;

    public OrganismoParametroRowMapper(@Value("${batch.nombre.parametro.organismo}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }

    @Override
    public OrganismoDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	OrganismoDTO organismo = new OrganismoDTO();
    	
        UUID uuid = UUID.randomUUID();
        FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();  
        organismo.setIdOrganismo(uuid.toString());    	
    	organismo.setCodigo(rs.getLong("entcode"));
        organismo.setRut(rs.getString("orgTaxID"));
        organismo.setOrganismo(rs.getString("entName"));
        organismo.setCreacion(nombreCreacion);
        organismo.setCreacionFecha(fechaActual);
    	organismo.setActualizacion(nombreCreacion);
    	organismo.setActualizacionFecha(fechaActual);
        return organismo;
    }
}


