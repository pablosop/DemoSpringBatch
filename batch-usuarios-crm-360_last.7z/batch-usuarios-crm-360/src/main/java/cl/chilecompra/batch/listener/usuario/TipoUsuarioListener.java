package cl.chilecompra.batch.listener.usuario;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.Chunk;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.TipoUsuarioDTO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class TipoUsuarioListener implements StepExecutionListener,
                                          ItemReadListener<TipoUsuarioDTO>, 
                                          ItemProcessListener<TipoUsuarioDTO, TipoUsuarioDTO>, 
                                          ItemWriteListener<TipoUsuarioDTO> {

    private static final String INSERTED_COUNT_KEY = "insertedCount";
    private static final String UPDATED_COUNT_KEY = "updatedCount";
    private static final String SKIPPED_COUNT_KEY = "skippedCount";
    
    private StepExecution stepExecution;    

       private  DataSource destinoDataSource;
        public TipoUsuarioListener(@Qualifier("destinoDataSource") DataSource destinoDataSource) {
        this.destinoDataSource = destinoDataSource;
    } 
    
 
   @Override
    public void beforeStep(StepExecution stepExecution) {   
        this.stepExecution = stepExecution; 	
        log.info("Iniciando step: {}", stepExecution.getStepName());       
    }
    
    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        // Obtener contadores del ExecutionContext
        int insertedCount = stepExecution.getExecutionContext().getInt(INSERTED_COUNT_KEY, 0);
        int updatedCount = stepExecution.getExecutionContext().getInt(UPDATED_COUNT_KEY, 0);
        int skippedCount = stepExecution.getExecutionContext().getInt(SKIPPED_COUNT_KEY, 0);

        // Registrar estadísticas
        log.info("Fin del paso de escritura.");
        log.info("Total de registros insertados: {}", insertedCount);
        log.info("Total de registros actualizados: {}", updatedCount);
        log.info("Total de registros omitidos: {}", skippedCount);
        log.info("Termino step: {}", stepExecution.getStepName());
        return ExitStatus.COMPLETED;
    }
					   
    @Override
    public void beforeRead() {
        log.trace("Iniciando lectura de un item...");
    }

    @Override
    public void afterRead(TipoUsuarioDTO item) {
        log.trace("Lectura completada: {}", item);
    }

    @Override
    public void onReadError(Exception ex) {
        log.error("Error durante la lectura: ", ex);
    }

							 
    @Override
    public void beforeProcess(TipoUsuarioDTO item) {
        log.trace("Procesando item: {}", item);
    }

    @Override
    public void afterProcess(TipoUsuarioDTO item, TipoUsuarioDTO result) {
        if (result == null) {
            log.trace("Registro omitido durante el procesamiento: {}", item);
            incrementStepCounter(SKIPPED_COUNT_KEY);
        } else {
            log.trace("Procesamiento exitoso: {}", result);
        }
    }

    @Override
    public void onProcessError(TipoUsuarioDTO item, Exception e) {
        log.error("Error durante el procesamiento de item: {}", item, e);
    }

						  
    @Override
    public void beforeWrite(Chunk<? extends TipoUsuarioDTO> items) {
        log.trace("Iniciando escritura de {} items", items.size());
    }

    @Override
    public void afterWrite(Chunk<? extends TipoUsuarioDTO> items) {
        for (TipoUsuarioDTO item : items) {
            if (item != null && item.getId() != null) {
                if (isNewRecord(item)) {
                    incrementStepCounter(INSERTED_COUNT_KEY);
                } else {
                    incrementStepCounter(UPDATED_COUNT_KEY);
                }
            }
        }
        log.debug("Escritura completada para {} items", items.size());
    }

    @Override
    public void onWriteError(Exception exception, Chunk<? extends TipoUsuarioDTO> items) {
        log.error("Error durante la escritura de items", exception);
    }

    private boolean isNewRecord(TipoUsuarioDTO item) {
																					   
																		  
        return item.getId() == null;
    }

    private void incrementStepCounter(String counterKey) {
    	int currentCount= stepExecution.getExecutionContext().getInt(counterKey, 0);
    	        stepExecution.getExecutionContext().putInt(counterKey, currentCount + 1);
	 

								  
							
	 

								  
							
    	    }
}
 