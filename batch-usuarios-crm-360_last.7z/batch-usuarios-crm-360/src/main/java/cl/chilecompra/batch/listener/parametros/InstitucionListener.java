package cl.chilecompra.batch.listener.parametros;
						   

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.Chunk;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.InstitucionDTO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class InstitucionListener implements StepExecutionListener,
                                          ItemReadListener<InstitucionDTO>, 
                                          ItemProcessListener<InstitucionDTO, InstitucionDTO>, 
                                          ItemWriteListener<InstitucionDTO> {

    private static final String INSERTED_COUNT_KEY = "insertedCount";
    private static final String UPDATED_COUNT_KEY = "updatedCount";
    private static final String SKIPPED_COUNT_KEY = "skippedCount";
    
    private StepExecution stepExecution;    
    
 
    @Override
    public void beforeStep(StepExecution stepExecution) {
    	this.stepExecution = stepExecution;
        log.info("Iniciando step: {}", stepExecution.getStepName());
    }

    
    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        // Obtener contadores del ExecutionContext
        int insertedCount = stepExecution.getExecutionContext().getInt(INSERTED_COUNT_KEY, 0);
        int updatedCount = stepExecution.getExecutionContext().getInt(UPDATED_COUNT_KEY, 0);
        int skippedCount = stepExecution.getExecutionContext().getInt(SKIPPED_COUNT_KEY, 0);

        // Registrar estadísticas
        log.info("Fin del paso de escritura.");
        log.info("Total de registros insertados: {}", insertedCount);
        log.info("Total de registros actualizados: {}", updatedCount);
        log.info("Total de registros omitidos: {}", skippedCount);
        log.info("Termino step: {}", stepExecution.getStepName());
        return ExitStatus.COMPLETED;
    }

					   
    @Override
    public void beforeRead() {
        log.trace("Iniciando lectura de un item...");
    }

    @Override
    public void afterRead(InstitucionDTO item) {
        log.trace("Lectura completada: {}", item);
    }

    @Override
    public void onReadError(Exception ex) {
        log.error("Error durante la lectura: ", ex);
    }

							 
    @Override
    public void beforeProcess(InstitucionDTO item) {
        log.trace("Procesando item: {}", item);
    }

    @Override
    public void afterProcess(InstitucionDTO item, InstitucionDTO result) {
        if (result == null) {
            log.trace("Registro omitido durante el procesamiento: {}", item);
            incrementStepCounter(SKIPPED_COUNT_KEY);
        } else {
            log.trace("Procesamiento exitoso: {}", result);
        }
    }

    @Override
    public void onProcessError(InstitucionDTO item, Exception e) {
        log.error("Error durante el procesamiento de item: {}", item, e);
    }

						  
    @Override
    public void beforeWrite(Chunk<? extends InstitucionDTO> items) {
        log.trace("Iniciando escritura de {} items", items.size());
    }

    @Override
    public void afterWrite(Chunk<? extends InstitucionDTO> items) {
        for (InstitucionDTO item : items) {
            if (item != null && item.getIdInstitucion() != null) {
                if (isNewRecord(item)) {
                    incrementStepCounter(INSERTED_COUNT_KEY);
                } else {
                    incrementStepCounter(UPDATED_COUNT_KEY);
                }
            }
        }
        log.debug("Escritura completada para {} items", items.size());
    }

    @Override
    public void onWriteError(Exception exception, Chunk<? extends InstitucionDTO> items) {
        log.error("Error durante la escritura de items", exception);
    }

    private boolean isNewRecord(InstitucionDTO item) {
																					   
																		  
        return item.getIdInstitucion() == null;
    }

    private void incrementStepCounter(String counterKey) {
    	int currentCount= stepExecution.getExecutionContext().getInt(counterKey, 0);
    	        stepExecution.getExecutionContext().putInt(counterKey, currentCount + 1);
	 

								  
							
	 

								  
							
    	    }
}
 