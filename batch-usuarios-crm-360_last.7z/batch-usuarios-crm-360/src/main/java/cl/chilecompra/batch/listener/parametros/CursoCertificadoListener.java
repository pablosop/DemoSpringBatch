package cl.chilecompra.batch.listener.parametros;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.Chunk;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.CursoCertificadoDTO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CursoCertificadoListener implements StepExecutionListener,
                                                 ItemReadListener<CursoCertificadoDTO>, 
                                                 ItemProcessListener<CursoCertificadoDTO, CursoCertificadoDTO>, 
                                                 ItemWriteListener<CursoCertificadoDTO> {
	    
    private int insertedCount = 0;
    private int updatedCount = 0;
    private int skippedCount = 0;
	
    @Override
	public void beforeStep(StepExecution stepExecution) {
    	log.info("--> Iniciando step: "+stepExecution.getStepName()+"<--");
	}
    
    @Override
	public ExitStatus afterStep(StepExecution stepExecution) {
    	log.info("--> Termino step: "+stepExecution.getStepName()+"<--");
        // Registro más detallado en los logs
        log.debug("Fin del paso de escritura.");
        log.debug("Total de registros insertados: {}", insertedCount);
        log.debug("Total de registros actualizados: {}", updatedCount);
        log.debug("Total de registros omitidos: {}", skippedCount);    	
		return null;
	}
    
    // Logs para Reader
    @Override
    public void beforeRead() {
        log.debug("==> Iniciando lectura de un item...");
    }

    @Override
    public void afterRead(CursoCertificadoDTO item) {
        log.debug("==> Lectura completada: {}", item);
    }

    @Override
    public void onReadError(Exception ex) {
        log.error("==> Error durante la lectura: ", ex);
    }

    // loggers para Processor
    @Override
    public void beforeProcess(CursoCertificadoDTO item) {
        log.debug("==> Procesando item: {}", item);
    }

    @Override
    public void afterProcess(CursoCertificadoDTO item, CursoCertificadoDTO result) {
        if (result == null) {
            log.debug("Registro omitido durante el procesamiento: {}", item);
            skippedCount++; // Contabiliza como skipped si el resultado es null
        } else {
            log.debug("Procesamiento exitoso: {}", result);
        }
    }

    @Override
    public void onProcessError(CursoCertificadoDTO item, Exception e) {
        log.error("==> Error durante el procesamiento de item: {}", item, e);
    }

    // loggers para Writer
    @Override
    public void beforeWrite(Chunk<? extends CursoCertificadoDTO> items) {
        log.debug("==> Iniciando escritura de {} items", items.size());
    }

    @Override
    public void afterWrite(Chunk<? extends CursoCertificadoDTO> items) {
        for (CursoCertificadoDTO item : items) {
            if (item != null && item.getIdCursoCertificado()!=0) {
                if (isNewRecord(item)) {
                    insertedCount++;
                } else {
                    updatedCount++;
                }
            } // Si el item es null o tiene valores nulos en los campos relevantes, ya se contabiliza en el afterProcess
        }

    }

    @Override
    public void onWriteError(Exception exception, Chunk<? extends CursoCertificadoDTO> items) {
        log.error("==> Error durante la escritura de items: {}", items, exception);
    }
    
    private boolean isNewRecord(CursoCertificadoDTO item) {
        // Aquí puedes agregar la lógica para determinar si el registro es nuevo o no
        // por ejemplo, verificando si el ID ya existe en la base de datos
        return item.getIdCursoCertificado() != 0;  // Ajusta esta lógica según tus necesidades
    }

    // Métodos getter para acceder a los contadores
    public int getInsertedCount() {
        return insertedCount;
    }

    public int getUpdatedCount() {
        return updatedCount;
    }

    public int getSkippedCount() {
        return skippedCount;
    }
}
