package cl.chilecompra.batch.mapper.parametros;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.InstitucionDTO;
import cl.chilecompra.batch.utils.FechasUtils;

@Component
public class InstitucionRowMapper implements RowMapper<InstitucionDTO> {

      
    private final String nombreCreacion;

    public InstitucionRowMapper(@Value("${batch.nombre.parametro.institucion}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }
    
    @Override
    public InstitucionDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	InstitucionDTO institutoDTO = new InstitucionDTO();
        FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();    	
        UUID uuid = UUID.randomUUID();
        institutoDTO.setIdInstitucion(uuid.toString());
        institutoDTO.setCodigo(rs.getLong("entID"));        
        institutoDTO.setInstitucion(rs.getString("entName"));
        institutoDTO.setCreacion(nombreCreacion);
        institutoDTO.setCreacionFecha(fechaActual);
        institutoDTO.setActualizacionFecha(fechaActual);
        institutoDTO.setActualizacion(nombreCreacion);
        
        return institutoDTO;
    }
}

