package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;

@Data
public class OrganismoDTO {

     private String idOrganismo;
    
     private Long codigo;
     private String rut;
     private String organismo;
     private Date vigencia;
     private int idOrganismoTamanoSII;
     private int idOrganismoHabilidad;
     private int idEstadoAcreditado;
     private String creacion;
     private Date creacionFecha;
     private String actualizacion;
     private Date actualizacionFecha;
     

}
