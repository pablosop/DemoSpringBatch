package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;

@Data
public class CursoCertificadoDTO {

    private int idCursoCertificado;
    private String cursoCertificado;
    private String cursoCortoCertificado;
    private Date fechaCertificado;
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;

}
