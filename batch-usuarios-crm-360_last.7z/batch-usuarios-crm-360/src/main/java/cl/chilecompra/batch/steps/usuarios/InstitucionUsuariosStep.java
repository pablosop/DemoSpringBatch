package cl.chilecompra.batch.steps.usuarios;

import javax.sql.DataSource;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;
import cl.chilecompra.batch.dto.UsuarioInstitucionDTO;
import cl.chilecompra.batch.listener.usuario.UsuarioInstitucionListener;
import cl.chilecompra.batch.mapper.usuario.InstitucionUsuarioRowMapper;
import cl.chilecompra.batch.processor.usuario.ObtenerDatosInstitucionProcessor;

@Configuration
public class InstitucionUsuariosStep {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;
    
    @Value("${step.reintentos}")
    private Integer reintentos;
    
    @Value("${step.cantidad.lote}")
    private Integer tamañoLote;

    @Value("${step.cantidad.tolerancia.skip}")
    private Integer tolerancia;
       
    private  ObtenerDatosInstitucionProcessor obtenerDatosInstitucionProcessor;

    public InstitucionUsuariosStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			            @Qualifier("origenDataSource") DataSource sourceDataSource,
			            @Qualifier("destinoDataSource") DataSource targetDataSource,			           
			            ObtenerDatosInstitucionProcessor obtenerDatosInstitucionProcessor){
		this.jobRepository                    = jobRepository;
		this.transactionManager               = transactionManager;
		this.sourceDataSource                 = sourceDataSource;
		this.targetDataSource                 = targetDataSource;	
		this.obtenerDatosInstitucionProcessor = obtenerDatosInstitucionProcessor;
		
		
	}
    
    // Reader
    @Bean
    public JdbcCursorItemReader<UsuarioInstitucionDTO> usuarioReader4(InstitucionUsuarioRowMapper institucionUsuarioRowMapper) {
        return new JdbcCursorItemReaderBuilder<UsuarioInstitucionDTO>()
                .name("UsuarioReader4")
                .dataSource(sourceDataSource)
                .sql("SELECT r.uroUser,\r\n"
                		+ "		e.entID,\r\n"
                		+ "		o.orgClass \r\n"
                		+ "FROM \r\n"
                		+ "		dbo.gblSecUserRole r\r\n"
                		+ "JOIN\r\n"
                		+ "		dbo.gbluser u\r\n"
                		+ "on\r\n"
                		+ "		r.uroUser = u.usrCode \r\n"
                		+ "JOIN\r\n"
                		+ "		gblOrganization o\r\n"
                		+ "on\r\n"
                		+ "		r.uroOrganization = o.orgCode \r\n"
                		+ "join\r\n"
                		+ "		gblEnterprise e\r\n"
                		+ "on\r\n"
                		+ "		o.orgEnterprise = e.entCode \r\n"
                		+ "WHERE\r\n"
                		+ "		r.uroIsActive = 1\r\n"
                		+ "		and o.orgClass = 2\r\n"
                		+ "		and u.usrLastLogin >=  DATEADD(month, -12, GETDATE())\r\n"
                        + "     and LEN(REPLACE(TRANSLATE(u.usrTaxID, 'abcdefghijlmnopqrstuvwxyz+()- ,#+.', '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'), '@', '')) in (8,9)\r\n"
                		+ "group by\r\n"
                		+ "		r.uroUser,\r\n"
                		+ "		e.entID,\r\n"
                		+ "		o.orgClass")
                .rowMapper(institucionUsuarioRowMapper)
                .fetchSize(tamañoLote)
                .build();
    }

    // Writer
    @Bean
    public JdbcBatchItemWriter<UsuarioInstitucionDTO> usuarioWriter4() {
        return new JdbcBatchItemWriterBuilder<UsuarioInstitucionDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO INSTITUCION_USUARIO\r\n"
            		+ "( ID_INSTITUCION, ID_USUARIO, ID_ESTADOACTIVO, CREACION, CREACIONFECHA)\r\n"
            		+ "VALUES( :id_institucion, :id_usuario, :estado, :creacion, :creacionFecha)\r\n"
            		+ "ON DUPLICATE KEY update\r\n"
            		+ "	ID_ESTADOACTIVO = values(ID_ESTADOACTIVO), \r\n"            		
            		+ "	ACTUALIZACION = :actualizacion,\r\n"
            		+ "	ACTUALIZACIONFECHA = :actualizacionFecha")
                .dataSource(targetDataSource)
                .build();
    }
      
    
    // Step
    @Bean
    public Step institucionUsuarioStep(UsuarioInstitucionListener listener, InstitucionUsuarioRowMapper usuario4RowMapper) {
        return new StepBuilder("institucionUsuarioStep", jobRepository)
                .<UsuarioInstitucionDTO, UsuarioInstitucionDTO>chunk(tamañoLote, transactionManager)
                .reader(usuarioReader4(usuario4RowMapper))
                .processor(obtenerDatosInstitucionProcessor)
                .writer(usuarioWriter4())
                .listener((ItemReadListener<? super UsuarioInstitucionDTO>) listener)
                .listener((ItemProcessListener<? super UsuarioInstitucionDTO, ? super UsuarioInstitucionDTO>) listener)
                .listener((ItemWriteListener<? super UsuarioInstitucionDTO>) listener)
                .listener((StepExecutionListener) listener)
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(tolerancia) 
                .retryLimit(reintentos)
                .retry(Exception.class)      
                .build();
    }
    
}
