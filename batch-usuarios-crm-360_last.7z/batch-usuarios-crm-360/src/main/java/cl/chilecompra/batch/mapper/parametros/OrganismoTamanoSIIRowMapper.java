package cl.chilecompra.batch.mapper.parametros;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.OrganismoTamanoSIIDTO;
import cl.chilecompra.batch.utils.FechasUtils;
import lombok.extern.slf4j.Slf4j;

@Component
public class OrganismoTamanoSIIRowMapper   implements RowMapper<OrganismoTamanoSIIDTO> {

    private static final Date FECHA_ACTUAL = new Date();
    
    private final String nombreCreacion;

    public OrganismoTamanoSIIRowMapper(@Value("${batch.nombre.parametro.organismosii}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }

    @Override
    public OrganismoTamanoSIIDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	OrganismoTamanoSIIDTO organismoTamanoSIIDTO = new OrganismoTamanoSIIDTO();
        FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();  
    	
        organismoTamanoSIIDTO.setIdOrganismoTamanoSII(rs.getInt("idtamano_sii"));
        organismoTamanoSIIDTO.setTamanoPrincipal(rs.getString("tamano_principal"));
        organismoTamanoSIIDTO.setTamanoSubgrupo(rs.getString("tamano_subgrupo"));
        organismoTamanoSIIDTO.setTramoVenta(rs.getString("tramo_ventas"));
        organismoTamanoSIIDTO.setGlosaCompletaSII(rs.getString("glosa_completa_sii"));
        organismoTamanoSIIDTO.setIdEstadoActivo(rs.getInt("valido"));

        organismoTamanoSIIDTO.setCreacion(nombreCreacion);
        organismoTamanoSIIDTO.setCreacionFecha(fechaActual);
        organismoTamanoSIIDTO.setActualizacion(nombreCreacion);
        organismoTamanoSIIDTO.setActualizacionFecha(fechaActual);

        return organismoTamanoSIIDTO;
    }
}

