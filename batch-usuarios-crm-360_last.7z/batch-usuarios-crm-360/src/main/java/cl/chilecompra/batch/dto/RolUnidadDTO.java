
package cl.chilecompra.batch.dto;

import java.util.Date;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Table(name = "ROL_UNIDAD")
public class RolUnidadDTO {

	private Integer uroRole;
	private Integer uroOrganization;
	private Integer orgClass;
	private Integer uroIsActive;
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String idRol;
    private String idUnidad;
    
    private int idEstadoActivo;
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;

}
