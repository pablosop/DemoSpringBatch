package cl.chilecompra.batch.steps.usuarios;

import javax.sql.DataSource;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import cl.chilecompra.batch.dto.TipoUsuarioDTO;
import cl.chilecompra.batch.listener.usuario.TipoUsuarioListener;
import cl.chilecompra.batch.mapper.usuario.TipoUsuarioRowMapper;
import cl.chilecompra.batch.processor.usuario.ObtenerTipoUsuarioProcessor;


@Configuration
public class TipoUsuariosStep {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;
    
    @Value("${step.reintentos}")
    private Integer reintentos;
    
    @Value("${step.cantidad.lote}")
    private Integer tamañoLote;

    @Value("${step.cantidad.tolerancia.skip}")
    private Integer tolerancia;
    
    private final ObtenerTipoUsuarioProcessor obtenerTipoUsuarioProcessor;

    public TipoUsuariosStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			            @Qualifier("origenDataSource") DataSource sourceDataSource,
			            @Qualifier("destinoDataSource") DataSource targetDataSource,
			            ObtenerTipoUsuarioProcessor obtenerTipoUsuarioProcessor){
		this.jobRepository                  = jobRepository;
		this.transactionManager             = transactionManager;
		this.sourceDataSource               = sourceDataSource;
		this.targetDataSource               = targetDataSource;
		this.obtenerTipoUsuarioProcessor  = obtenerTipoUsuarioProcessor;
		
	}
    
    // Reader
    @Bean
    public JdbcCursorItemReader<TipoUsuarioDTO> usuarioReader6(TipoUsuarioRowMapper tipoUsuarioRowMapper) {
        return new JdbcCursorItemReaderBuilder<TipoUsuarioDTO>()
                .name("UsuarioReader6")
                .dataSource(sourceDataSource)
                .sql("SELECT r.uroUser\r\n"
                		+ "	,o.orgClass\r\n"
                		+ "FROM dbo.gblSecUserRole r\r\n"
                		+ "JOIN dbo.gbluser u ON r.uroUser = u.usrCode\r\n"
                		+ "JOIN gblOrganization o ON r.uroOrganization = o.orgCode\r\n"
                		+ "WHERE r.uroIsActive = 1\r\n"
                		+ "	AND u.usrIsActive = 1\r\n"
                		+ "	AND u.usrLastLogin >= DATEADD(month, - 12, GETDATE())\r\n"
                        + " AND LEN(REPLACE(TRANSLATE(u.usrTaxID, 'abcdefghijlmnopqrstuvwxyz+()- ,#+.', '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'), '@', '')) in (8,9)\r\n"
                		+ "GROUP BY r.uroUser\r\n"
                		+ "	,o.orgClass")
                .rowMapper(tipoUsuarioRowMapper)
                .fetchSize(tamañoLote)
                .build();
    }

    // Writer
    @Bean
    public JdbcBatchItemWriter<TipoUsuarioDTO> usuarioWriter6() {
        return new JdbcBatchItemWriterBuilder<TipoUsuarioDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO TIPO_USUARIO\r\n"
                		+ "      (ID_USUARIO, ID_TIPO, CREACION, CREACIONFECHA)\r\n"
                		+ "VALUES(:id_usuario, :orgClass, :creacion, :creacionFecha)\r\n"
                		+ "ON DUPLICATE KEY update\r\n"
                		+ "   ID_TIPO = values(ID_TIPO),\r\n"
                		+ "	ACTUALIZACION = :actualizacion,\r\n"
            		    + "	ACTUALIZACIONFECHA = :actualizacionFecha")
                .dataSource(targetDataSource)
                .build();
    }
    
    
    
    // Step
    @Bean
    public Step tipoUsuario1Step(TipoUsuarioListener listener, TipoUsuarioRowMapper usuario6RowMapper) {
        return new StepBuilder("tipoUsuario1Step", jobRepository)
                .<TipoUsuarioDTO, TipoUsuarioDTO>chunk(tamañoLote, transactionManager)
                .reader(usuarioReader6(usuario6RowMapper))
                .processor(obtenerTipoUsuarioProcessor)
                .writer(usuarioWriter6())
                .listener((ItemReadListener<? super TipoUsuarioDTO>) listener)
                .listener((ItemProcessListener<? super TipoUsuarioDTO, ? super TipoUsuarioDTO>) listener)
                .listener((ItemWriteListener<? super TipoUsuarioDTO>) listener)
                .listener((StepExecutionListener) listener)
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(tolerancia) 
                .retryLimit(reintentos)
                .retry(Exception.class)      
                .build();
    }


  


    
    
}
