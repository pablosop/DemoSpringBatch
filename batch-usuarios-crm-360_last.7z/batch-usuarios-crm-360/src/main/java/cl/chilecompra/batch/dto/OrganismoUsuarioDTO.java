package cl.chilecompra.batch.dto;

import java.util.Date;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Table(name = "ORGANISMO_USUARIO")
public class OrganismoUsuarioDTO {

    private String  uroUser;//para buscar id_usuario	
    private Integer entID;  //para buscar id_institucion	
    private Integer orgClas; 
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String  id_organismo;
    private String  id_usuario;
    private Integer estado;
    private String  creacion;
    private Date    creacionFecha;
    private String  actualizacion;
    private Date    actualizacionFecha;    
}
