package cl.chilecompra.batch.mapper.organismo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.OrganismoDTO;
import cl.chilecompra.batch.utils.FechasUtils;

@Component
public class OrganismoHabilidadRowMapper implements RowMapper<OrganismoDTO> {
	
    private final String nombreCreacion;

    public OrganismoHabilidadRowMapper(@Value("${batch.nombre.organismoHabilidad}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }
	
    @Override
    public OrganismoDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	OrganismoDTO organismo = new OrganismoDTO();
    	
        UUID uuid = UUID.randomUUID();
        FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();    	
        organismo.setIdOrganismo(uuid.toString());
    	
        organismo.setActualizacion(nombreCreacion);
        organismo.setActualizacionFecha(fechaActual);
    	organismo.setRut(rs.getString("rutProveedor"));
    	organismo.setIdEstadoAcreditado(rs.getInt("acreditacion"));
    	organismo.setIdOrganismoHabilidad(rs.getInt("habilidad"));

    	return organismo;
    }
}

