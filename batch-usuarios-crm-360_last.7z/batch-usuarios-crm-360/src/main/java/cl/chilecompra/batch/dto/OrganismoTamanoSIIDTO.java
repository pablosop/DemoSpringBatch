package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;

@Data
public class OrganismoTamanoSIIDTO {

    private Integer idOrganismoTamanoSII;
    private String tamanoPrincipal;
    private String tamanoSubgrupo;
    private String tramoVenta;
    private String glosaCompletaSII;
    private Integer idEstadoActivo; 
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;

}
