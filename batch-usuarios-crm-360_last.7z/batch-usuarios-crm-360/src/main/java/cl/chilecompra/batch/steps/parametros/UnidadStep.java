package cl.chilecompra.batch.steps.parametros;

import javax.sql.DataSource;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import cl.chilecompra.batch.dto.UnidadDTO;
import cl.chilecompra.batch.listener.parametros.UnidadListener;
import cl.chilecompra.batch.mapper.parametros.UnidadRowMapper;
import cl.chilecompra.batch.processor.parametros.UnidadProcessor;

@Configuration
public class UnidadStep  {
    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;

    @Value("${step.reintentos}")
    private Integer reintentos;
    
    @Value("${step.cantidad.lote}")
    private Integer tamañoLote;
    
    private final UnidadProcessor unidadProcessor;
    
    public UnidadStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			            @Qualifier("origenDataSource") DataSource sourceDataSource,
			            @Qualifier("destinoDataSource") DataSource targetDataSource,
                        @Autowired(required = false) UnidadProcessor unidadProcessor) {
		this.jobRepository = jobRepository;
		this.transactionManager = transactionManager;
		this.sourceDataSource = sourceDataSource;
		this.targetDataSource = targetDataSource;
        this.unidadProcessor = unidadProcessor;
	}
    

    // Reader
    @Bean
    public JdbcCursorItemReader<UnidadDTO> unidadReader(UnidadRowMapper unidadRowMapper) {
        return new JdbcCursorItemReaderBuilder<UnidadDTO>()
                .name("UnidadDTOReader")
                .dataSource(sourceDataSource)
                .sql("SELECT dbo.gblOrganization.orgID, dbo.gblOrganization.orgIsActive, \r\n" +
                     "orgCode, dbo.gblOrganization.orgEnterprise, dbo.gblOrganization.orgName \r\n" +
                    "FROM dbo.gblOrganization \r\n" +                                      
                    "WHERE orgIsActive = 1 AND orgClass = 2\r\n"                    
                )
                .rowMapper(unidadRowMapper)
                .fetchSize(tamañoLote)
                .build();
    }

    // Writer
    @Bean
    public JdbcBatchItemWriter<UnidadDTO> unidadWriter() {
        return new JdbcBatchItemWriterBuilder<UnidadDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO UNIDAD (ID_UNIDAD, CODIGO, ID_INSTITUCION, UNIDAD, CREACION, CREACIONFECHA)" +
                     " VALUES (:idUnidad, :codigo, :idInstitucion, :unidad, :creacion, :creacionFecha) " +
                     "ON DUPLICATE KEY UPDATE UNIDAD = VALUES(UNIDAD), ACTUALIZACION = :actualizacion, ACTUALIZACIONFECHA = :actualizacionFecha")
                .dataSource(targetDataSource)
                .build();
    }

    // Step
    @Bean
    public Step unidad1Step(UnidadListener listener, UnidadRowMapper unidadRowMapper) {
        return new StepBuilder("unidad1Step", jobRepository)
                .<UnidadDTO, UnidadDTO>chunk(tamañoLote, transactionManager)
                .reader(unidadReader(unidadRowMapper))
                .processor(unidadProcessor)
                .writer(unidadWriter())
                .listener((ItemReadListener<? super UnidadDTO>) listener)
                .listener((ItemProcessListener<? super UnidadDTO, ? super UnidadDTO>) listener)
                .listener((ItemWriteListener<? super UnidadDTO>) listener)
                .listener((StepExecutionListener) listener)
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(reintentos)
                .build();
    }

}

