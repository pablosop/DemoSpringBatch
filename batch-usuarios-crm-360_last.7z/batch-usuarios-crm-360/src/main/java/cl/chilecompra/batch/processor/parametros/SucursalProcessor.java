package cl.chilecompra.batch.processor.parametros;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;

import cl.chilecompra.batch.dto.SucursalDTO;

public class SucursalProcessor  implements ItemProcessor<SucursalDTO, SucursalDTO> {

    private final Map<Integer, String> userMap = new HashMap<>();

    
    /**
     * TODO
     * OJO aqui, esto carga todos los registros en memoria
     * */
    
    public SucursalProcessor(@Qualifier("destinoDataSource") DataSource targetDataSource) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(targetDataSource);
        String sql = "SELECT ID_ORGANISMO, CODIGO FROM ORGANISMO";
        jdbcTemplate.query(sql, rs -> {
            userMap.put(rs.getInt("CODIGO"), rs.getString("ID_ORGANISMO"));
        });
    }

    @Override
    public SucursalDTO process(SucursalDTO item) {
        String idOrganismo = userMap.get(item.getCodigo());
        if (idOrganismo != null) {
            item.setIdOrganismo(idOrganismo);
            return item;
        }
        return null; // O manejar el caso donde no hay coincidencia
    }
}
