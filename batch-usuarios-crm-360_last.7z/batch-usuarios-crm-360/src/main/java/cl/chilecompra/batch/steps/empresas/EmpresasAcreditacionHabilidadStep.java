package cl.chilecompra.batch.steps.empresas;

import javax.sql.DataSource;

import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import cl.chilecompra.batch.dto.OrganismoDTO;
import cl.chilecompra.batch.listener.organismo.OrganismoListener;
import cl.chilecompra.batch.mapper.organismo.OrganismoHabilidadRowMapper;


@Configuration
public class EmpresasAcreditacionHabilidadStep {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;
    
    @Value("${step.reintentos}")
    private Integer reintentos;

    @Value("${step.cantidad.lote}")
    private Integer tamañoLote;

    @Value("${step.cantidad.tolerancia.skip}")
    private Integer tolerancia;
    
    public EmpresasAcreditacionHabilidadStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			            @Qualifier("origenDataSource") DataSource sourceDataSource,
			            @Qualifier("destinoDataSource") DataSource targetDataSource){
		this.jobRepository                    = jobRepository;
		this.transactionManager               = transactionManager;
		this.sourceDataSource                 = sourceDataSource;
		this.targetDataSource                 = targetDataSource;
		
	}
    
    // Reader
    @Bean
    public JdbcCursorItemReader<OrganismoDTO> organismoHabilidadReader(OrganismoHabilidadRowMapper organismoHabilidadRowMapper) {
        return new JdbcCursorItemReaderBuilder<OrganismoDTO>()
                .name("OrganismoReader")
                .dataSource(sourceDataSource)
                .sql("select a.RutProveedor  as rutProveedor,\r\n"
                	+ "	     a.Acreditacion  as acreditacion,\r\n"
                	+ "	     a.EstadoGeneral as habilidad\r\n"
                	+ " from DCCPHabilidades.habilidad.HabilidadProveedor a\r\n"
                	+ "group by a.RutProveedor, \r\n"
                	+ "         a.Acreditacion,\r\n"
                	+ "	        a.EstadoGeneral")
                .rowMapper(organismoHabilidadRowMapper)//Definir si es necesario otro mapper
                .fetchSize(tamañoLote)
                .build();
    }

    // Writer
    @Bean
    public JdbcBatchItemWriter<OrganismoDTO> organismoHabilidadWriter() {
        return new JdbcBatchItemWriterBuilder<OrganismoDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("UPDATE ORGANISMO\r\n"
                   + "   SET ID_ESTADOACREDITADO         = :idEstadoAcreditado        ,\r\n"
                   + "       ID_ORGANISMOHABILIDAD    = :idOrganismoHabilidad    \r\n"                  
                   + " WHERE RUT  = :rut")
                .dataSource(targetDataSource)
                .build();
    }    

    // Step
    @Bean
    public Step empresaAcreditacionHabilidadStep(OrganismoListener listener, OrganismoHabilidadRowMapper organismoHabilidadRowMapper) {
        return new StepBuilder("empresaAcreditacionHabilidadStep", jobRepository)
                .<OrganismoDTO, OrganismoDTO>chunk(tamañoLote, transactionManager)
                .reader(organismoHabilidadReader(organismoHabilidadRowMapper))
                .writer(organismoHabilidadWriter())
                .listener((ItemReadListener<? super OrganismoDTO>) listener)
                .listener((ItemWriteListener<? super OrganismoDTO>) listener)
                .listener((StepExecutionListener) listener)                
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(tolerancia) 
                .retryLimit(reintentos)
                .retry(Exception.class)      
                .build();
    }
  


    
    
}
