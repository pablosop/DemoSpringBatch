package cl.chilecompra.batch.mapper.rol;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.RolSucursalUsuarioDTO;
import cl.chilecompra.batch.utils.FechasUtils;

@Component
public class RolSucursalUsuarioRowMapper implements RowMapper<RolSucursalUsuarioDTO> {
	
    private final String nombreCreacion;

    public RolSucursalUsuarioRowMapper(@Value("${batch.nombre.rol.sucursalUsuario}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }
    
    @Override
    public RolSucursalUsuarioDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	RolSucursalUsuarioDTO rolSucursalUsuario = new RolSucursalUsuarioDTO();
    	FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();	
    	rolSucursalUsuario.setIdEstadoActivo(rs.getInt("uroIsActive"));          
        rolSucursalUsuario.setUroRole        (rs.getInt("uroRole"));
    	rolSucursalUsuario.setUroOrganization(rs.getInt("uroOrganization"));   	
    	rolSucursalUsuario.setUroUser(rs.getInt("uroUser"));   	

    	rolSucursalUsuario.setCreacion(nombreCreacion);
    	rolSucursalUsuario.setCreacionFecha(fechaActual);
    	rolSucursalUsuario.setActualizacion(nombreCreacion);
    	rolSucursalUsuario.setActualizacionFecha(fechaActual);
    	
        return rolSucursalUsuario;
    }
}

