package cl.chilecompra.batch.processor.rol;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;
import cl.chilecompra.batch.dto.RolSucursalDTO;


@Component
public class RolSucursalProcessor implements ItemProcessor<RolSucursalDTO, RolSucursalDTO> {

	private Map<Integer, String> rolMap = new HashMap<>();
    private Map<Integer, String> sucursalMap = new HashMap<>();
    
    @Override
    public RolSucursalDTO process(RolSucursalDTO item) {
        String idRol = rolMap.get(item.getUroRole());
        if (idRol != null) {
            item.setIdRol(idRol);
            String idSucursal = sucursalMap.get(item.getUroOrganization());
            if (idSucursal != null) {
                item.setIdSucursal(idSucursal);
                return item;
            }            
        }
        return null; 
    }

 @BeforeStep
    public void beforeStep(StepExecution stepExecution) {        
        JobExecution jobExecution = stepExecution.getJobExecution();
        this.rolMap = (Map<Integer, String>) jobExecution.getExecutionContext().get("rolMap"); 
        this.sucursalMap = (Map<Integer, String>) jobExecution.getExecutionContext().get("sucursalMap");        
    }


}
