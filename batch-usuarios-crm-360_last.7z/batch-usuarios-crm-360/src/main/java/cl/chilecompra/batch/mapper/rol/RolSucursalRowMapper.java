package cl.chilecompra.batch.mapper.rol;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.RolSucursalDTO;
import cl.chilecompra.batch.utils.FechasUtils;

@Component
public class RolSucursalRowMapper implements RowMapper<RolSucursalDTO> {
	
    private final String nombreCreacion;

    public RolSucursalRowMapper(@Value("${batch.nombre.rol.sucursal}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }
    
    @Override
    public RolSucursalDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	RolSucursalDTO rolSucursal = new RolSucursalDTO();
    	FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();  
        
    	rolSucursal.setUroRole        (rs.getInt("uroRole"));
    	rolSucursal.setUroOrganization(rs.getInt("uroOrganization"));    	
    	rolSucursal.setOrgClass       (rs.getInt("orgClass"));
    	
    	rolSucursal.setCreacion(nombreCreacion);
    	rolSucursal.setCreacionFecha(fechaActual);
    	rolSucursal.setActualizacion(nombreCreacion);
    	rolSucursal.setActualizacionFecha(fechaActual);    	
    	
        return rolSucursal;
    }
}

