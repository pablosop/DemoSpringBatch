package cl.chilecompra.batch.processor.usuario;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.OrganismoUsuarioDTO;


@Component
public class ObtenerDatosOrganismoUsuarioProcessor implements ItemProcessor<OrganismoUsuarioDTO, OrganismoUsuarioDTO> {

	private Map<Integer, String> userMap = new HashMap<>();      
    private Map<Integer, String> organismoMap = new HashMap<>(); 

    @Override
    public OrganismoUsuarioDTO process(OrganismoUsuarioDTO item) {
        String idUsuario = userMap.get(Integer.valueOf(item.getUroUser()));
        if (idUsuario != null) {
            item.setId_usuario(idUsuario);

            String idOrganismo = organismoMap.get(item.getEntID());
            if (idOrganismo != null) {
                item.setId_organismo(idOrganismo);
                return item;
            }else{return null;}           
        }
	     return null;               
     }

    @BeforeStep
    public void beforeStep(StepExecution stepExecution) {        
        JobExecution jobExecution = stepExecution.getJobExecution();
        this.organismoMap = (Map<Integer, String>) jobExecution.getExecutionContext().get("organismoMap"); 
        this.userMap = (Map<Integer, String>) jobExecution.getExecutionContext().get("userMap");
    }
}
