package cl.chilecompra.batch.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class FechasUtils {

    public Date obtenerFechaHoraMinutos(){

        Date currentDate = new Date(); // Fecha actual
        Date fechaFormateada = null;
        // Formato deseado
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        // Formatear la fecha
        String formattedDateStr = formatter.format(currentDate);
        try {
            fechaFormateada = formatter.parse(formattedDateStr);   
                    
        } catch (Exception e) {
            e.printStackTrace();
        }
        return currentDate; 
    }

}
