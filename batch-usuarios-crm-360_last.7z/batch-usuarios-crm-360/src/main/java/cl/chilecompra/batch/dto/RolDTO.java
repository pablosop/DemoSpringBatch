package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;

@Data
public class RolDTO {

    private String idRol;
    private Long codigo;
    private String rol;
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;

}
