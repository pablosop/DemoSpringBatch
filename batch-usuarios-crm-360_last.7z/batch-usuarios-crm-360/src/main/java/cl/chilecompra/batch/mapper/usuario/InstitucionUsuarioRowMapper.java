package cl.chilecompra.batch.mapper.usuario;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.UsuarioInstitucionDTO;
import cl.chilecompra.batch.utils.FechasUtils;

@Component
public class InstitucionUsuarioRowMapper implements RowMapper<UsuarioInstitucionDTO> {
	
    private final String nombreCreacion;

    public InstitucionUsuarioRowMapper(@Value("${batch.nombre.usuario4}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }
    
    @Override
    public UsuarioInstitucionDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	UsuarioInstitucionDTO usuarioInstitucion = new UsuarioInstitucionDTO();
		FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();
        
    	usuarioInstitucion.setUroUser(rs.getString("uroUser"));	
    	usuarioInstitucion.setEntID	 (rs.getInt   ("entID"  ));
    	usuarioInstitucion.setOrgClas(rs.getInt   ("orgClass"));
    	
    	usuarioInstitucion.setEstado(1);
    	usuarioInstitucion.setCreacion(nombreCreacion);
    	usuarioInstitucion.setCreacionFecha(fechaActual);
    	usuarioInstitucion.setActualizacion(nombreCreacion);
    	usuarioInstitucion.setActualizacionFecha(fechaActual);    	
    	
        return usuarioInstitucion;
    }
}

