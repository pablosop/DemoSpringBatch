package cl.chilecompra.batch.mapper.parametros;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.TipoDTO;
import cl.chilecompra.batch.utils.FechasUtils;

@Component
public class TipoRowMapper  implements RowMapper<TipoDTO> {       
   
    private final String nombreCreacion;

    public TipoRowMapper( @Value("${batch.nombre.parametro.tipo}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }

    @Override
    public TipoDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	TipoDTO tipoDTO = new TipoDTO();
    	FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();  
        tipoDTO.setIdTipo(rs.getLong("oclCode"));
        tipoDTO.setTipo(rs.getString("oclName"));
        tipoDTO.setCreacion(nombreCreacion);
        tipoDTO.setCreacionFecha(fechaActual);

        return tipoDTO;
    }
}

