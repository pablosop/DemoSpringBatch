package cl.chilecompra.batch.DataSourceconfig;

import javax.sql.DataSource;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@EnableConfigurationProperties
public class DataSourceConfig {

    @Primary
    @Bean(name = "dataSource")
    @ConfigurationProperties(prefix = "datasource.default")
    public DataSource dataSource() {
        return new DriverManagerDataSource();
    }

    @Bean(name = "origenDataSource")
    @ConfigurationProperties(prefix = "datasource.origen")
    public DataSource origenDataSource() {
        return new DriverManagerDataSource();
    }

    @Bean(name = "destinoDataSource")
    @ConfigurationProperties(prefix = "datasource.destino")
    public DataSource targetDataSource() {
        return new DriverManagerDataSource();
    }
}
