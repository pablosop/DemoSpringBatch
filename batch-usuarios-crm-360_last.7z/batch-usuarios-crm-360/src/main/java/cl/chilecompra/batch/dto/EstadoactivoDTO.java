package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;

@Data
public class EstadoactivoDTO {

    private Long idEstadoActivo;
    private String estadoActivo;
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;

}
