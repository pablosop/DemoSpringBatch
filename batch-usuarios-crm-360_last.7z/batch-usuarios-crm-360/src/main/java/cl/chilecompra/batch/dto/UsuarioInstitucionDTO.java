package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;

@Data
public class UsuarioInstitucionDTO {


    private String  uroUser;//para buscar id_usuario	
    private Integer entID;  //para buscar id_institucion	
    private Integer orgClas; 
    
    private String  id_institucion;
    private String  id_usuario;
    private Integer estado;
    private String  creacion;
    private Date    creacionFecha;
    private String  actualizacion;
    private Date    actualizacionFecha;    
    
}
