package cl.chilecompra.batch.mapper.usuario;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.UsuarioDTO;
import cl.chilecompra.batch.utils.FechasUtils;

@Component
public class UsuarioRowMapper implements RowMapper<UsuarioDTO> {	
	
    private final String nombreCreacion;

    public UsuarioRowMapper(@Value("${batch.nombre.usuario1}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }
    
    @Override
    public UsuarioDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	UsuarioDTO usuario = new UsuarioDTO();
    	
        UUID uuid = UUID.randomUUID();
        FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();  
        usuario.setIdUsuario(uuid.toString());
    	
        usuario.setCodigo(rs.getLong("usrCode"));
        usuario.setRutUsuario(rs.getInt("rut"));
        usuario.setDvUsuario(rs.getString("dv"));
        usuario.setNombresUsuario(rs.getString("usrFirstName"));
        usuario.setApellidosUsuario(rs.getString("usrLastName"));
        usuario.setAntiguedadUsuario(rs.getString("usrCreationDate"));
        usuario.setIdEstadoActivo(rs.getInt("usrIsActive"));
        usuario.setCreacion(nombreCreacion);
        usuario.setCreacionFecha(fechaActual);
        usuario.setActualizacion(nombreCreacion);
        usuario.setActualizacionFecha(fechaActual);        

        return usuario;
    }
}

