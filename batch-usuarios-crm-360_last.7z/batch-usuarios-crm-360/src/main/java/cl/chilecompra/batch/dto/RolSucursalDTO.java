package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;

@Data
public class RolSucursalDTO {

    private Long id;
    
    private Integer uroRole;
    private Integer uroOrganization;
    private Integer orgClass;    
    
    private String idRol;
    private String idSucursal;
    
    private int idEstadoActivo;
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;

}
