package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;

@Data
public class InstitucionUsuarioDTO {

    private Long id;
    private String idInstitucion;
    private String idUsuario;
    private int idEstadoActivo;
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;

}
