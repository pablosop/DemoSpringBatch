package cl.chilecompra.batch.mapper.usuario;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.UsuarioContactoDTO;
import cl.chilecompra.batch.utils.FechasUtils;

@Component
public class UsuarioContactoRowMapper implements RowMapper<UsuarioContactoDTO> {
	
    @Value("${batch.nombre.usuario3}")
    private final String nombreCreacion;

    public UsuarioContactoRowMapper(@Value("${batch.nombre.usuario3}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }
    
    @Override
    public UsuarioContactoDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	UsuarioContactoDTO usuarioContacto = new UsuarioContactoDTO();

        FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();
    	
    	String usrPhone  = rs.getString("UsrPhone");
    	String usrMobile = rs.getString("UsrMobile");
    	
    	//Limpia caracteres no soportados
    	if(usrPhone!=null)
    		usrPhone  = usrPhone.replaceAll("[\\p{C}\\p{Z}&&[^\\p{Zs}]]", "");
    	if(usrMobile!=null)
    		usrMobile = usrMobile.replaceAll("[\\p{C}\\p{Z}&&[^\\p{Zs}]]", "");
    	
    	usuarioContacto.setUsrCode			  (rs.getInt   ("UsrCode"));
    	usuarioContacto.setUsrEmail			  (rs.getString("UsrEmail"));
    	usuarioContacto.setUsrEmailAlternative(rs.getString("UsrEmailAlternative"));
    	usuarioContacto.setUsrPhone			  (usrPhone);
    	usuarioContacto.setUsrMobile		  (usrMobile);
    	usuarioContacto.setUsrFax			  (rs.getString("UsrFax"));
    	usuarioContacto.setUsrMailFormat	  (rs.getInt   ("UsrMailFormat"));
    	
    	usuarioContacto.setCreacion          (nombreCreacion);
    	usuarioContacto.setCreacionFecha     (fechaActual);
    	usuarioContacto.setActualizacion     (nombreCreacion);
    	usuarioContacto.setActualizacionFecha(fechaActual);
    	usuarioContacto.setEstado            (1);    	
    	
        return usuarioContacto;
    }
}

