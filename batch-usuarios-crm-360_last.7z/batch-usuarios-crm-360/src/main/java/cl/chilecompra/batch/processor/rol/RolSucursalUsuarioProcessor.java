package cl.chilecompra.batch.processor.rol;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;

import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.RolSucursalUsuarioDTO;

@Component
public class RolSucursalUsuarioProcessor  implements ItemProcessor<RolSucursalUsuarioDTO, RolSucursalUsuarioDTO> {

    private Map<Integer, String> rolMap = new HashMap<>();
    private Map<Integer, String> sucursalMap = new HashMap<>();
    private Map<Integer, String> userMap = new HashMap<>();
    Map<String, Integer> rolSucursalMap = new HashMap<>();


    
    @Override
    public RolSucursalUsuarioDTO process(RolSucursalUsuarioDTO item) {
        String idRol = rolMap.get(item.getUroRole());
        if (idRol != null) {
            item.setIdRol(idRol);
            String idSucursal = sucursalMap.get(item.getUroOrganization());
            if (idSucursal != null) {
                item.setIdSucursal(idSucursal);
                int uroUser = item.getUroUser();
                String idUsuario = userMap.get(uroUser);
                if (idUsuario != null) {
                    item.setIdUsuario(idUsuario);
                    // Generar la clave combinada para buscar en el mapa
                    String key = item.getIdRol() + "-" + item.getIdSucursal();
                    Integer idRolSucursal = rolSucursalMap.get(key);
                    // Si se encuentra el ID, lo asigna al objeto; si no, filtra el registro
                    if (idRolSucursal != null) {
                        item.setIdRolSucursal(idRolSucursal);
                        return item;
                    }                   
                }               
            }
        }
        return null;
    }


    @BeforeStep
    public void beforeStep(StepExecution stepExecution) {               
        JobExecution jobExecution = stepExecution.getJobExecution();
        this.rolMap = (Map<Integer, String>) jobExecution.getExecutionContext().get("rolMap"); 
        this.sucursalMap = (Map<Integer, String>) jobExecution.getExecutionContext().get("sucursalMap"); 
        this.userMap = (Map<Integer, String>) jobExecution.getExecutionContext().get("userMap"); 
        this.rolSucursalMap = (Map<String, Integer>) jobExecution.getExecutionContext().get("rolSucursalMap");      
    }
}
