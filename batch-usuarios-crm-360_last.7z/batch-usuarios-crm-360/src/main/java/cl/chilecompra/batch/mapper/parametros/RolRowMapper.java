package cl.chilecompra.batch.mapper.parametros;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.RolDTO;
import cl.chilecompra.batch.utils.FechasUtils;
import lombok.extern.slf4j.Slf4j;

@Component
public class RolRowMapper  implements RowMapper<RolDTO> {

    private static final Date FECHA_ACTUAL = new Date();
    
    private final String nombreCreacion;

    public RolRowMapper(@Value("${batch.nombre.parametro.rol}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }

    @Override
    public RolDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

    	RolDTO rolDTO = new RolDTO();
        UUID uuid = UUID.randomUUID();
        FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();  
        rolDTO.setIdRol(uuid.toString());
        rolDTO.setCodigo(rs.getLong("rolCode"));
        rolDTO.setRol(rs.getString("rolName"));
        rolDTO.setCreacion(nombreCreacion);
        rolDTO.setCreacionFecha(fechaActual);
        rolDTO.setActualizacion(nombreCreacion);
        rolDTO.setActualizacionFecha(fechaActual);

        return rolDTO;
    }
}

