package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;

@Data
public class UsuarioDTO {

    private String idUsuario;
    private Long codigo;
    private int rutUsuario;
    private String dvUsuario;
    private String nombresUsuario;
    private String apellidosUsuario;
    private String antiguedadUsuario;
    private int idEstadoActivo;
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;
}
