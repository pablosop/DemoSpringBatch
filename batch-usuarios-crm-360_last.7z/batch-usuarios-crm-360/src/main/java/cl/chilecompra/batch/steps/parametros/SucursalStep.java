package cl.chilecompra.batch.steps.parametros;

import javax.sql.DataSource;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import cl.chilecompra.batch.dto.SucursalDTO;
import cl.chilecompra.batch.listener.parametros.SucursalListener;
import cl.chilecompra.batch.mapper.parametros.SucursalRowMapper;
import cl.chilecompra.batch.processor.parametros.SucursalProcessor;

@Configuration
public class SucursalStep  {
    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;    

    @Value("${step.reintentos}")
    private Integer reintentos;
    
    @Value("${step.cantidad.lote}")
    private Integer tamañoLote;
    
    private final SucursalProcessor sucursalProcessor;

    public SucursalStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			            @Qualifier("origenDataSource") DataSource sourceDataSource,
			            @Qualifier("destinoDataSource") DataSource targetDataSource,
                        @Autowired(required = false) SucursalProcessor sucursalProcessor) {
		this.jobRepository = jobRepository;
		this.transactionManager = transactionManager;
		this.sourceDataSource = sourceDataSource;
		this.targetDataSource = targetDataSource;
        this.sucursalProcessor = sucursalProcessor;
	}
    
    // Reader
    @Bean
    public JdbcCursorItemReader<SucursalDTO> sucursalReader(SucursalRowMapper sucursalRowMapper) {
        return new JdbcCursorItemReaderBuilder<SucursalDTO>()
                .name("SucursalDTOReader")
                .dataSource(sourceDataSource)
                .sql(" WITH aux_OrgTaxIDUnicos AS ( " +
                     "SELECT x.orgTaxID, count(1) cta FROM " +
                     "(SELECT orgTaxID, orgEnterprise, count(*) cant " +
                     "FROM gblOrganization " +
                     "group BY orgTaxID, orgEnterprise) x " +
                     "group BY x.orgTaxID having count(1) > 1), " +
                     "aux_EntIDUnicos AS ( SELECT x.orgEnterprise, count(1) cta FROM " +
                     "(SELECT orgEnterprise, orgTaxID, count(*) cant " +
                     "FROM gblOrganization " +
                     "GROUP BY orgEnterprise, orgTaxID ) x " +
                     "GROUP BY x.orgEnterprise having count(1) > 1 ) " +
                     "SELECT o.orgEnterprise, o.orgCode, o.orgName " +
                     "FROM dbo.gblOrganization o " +
                     "JOIN dbo.gblEnterprise ge " +
                     "ON ge.entcode = o.orgenterprise " +
                     "JOIN dbo.gblSecUserRole ur " +
                     "ON ur.uroOrganization = o.orgCode " +
                     "JOIN dbo.gblUser gu " +
                     "ON gu.usrCode = ur.uroUser " +
                     "WHERE o.orgIsActive = 1 " +
                     "AND ur.uroIsActive = 1 " +
                     "AND o.orgClass = 1 " +
                     "AND gu.usrLastLogin >= DATEADD(month, -12, GETDATE()) " +
                     "AND ge.entIsActive = 1 " +
                     "AND o.orgTaxID not in " +
                     "(SELECT orgTaxID from aux_OrgTaxIDUnicos) " +
                     "AND ge.entCode not in ( SELECT orgEnterprise from aux_EntIDUnicos) " +
                     "GROUP BY o.orgEnterprise, o.orgCode, o.orgName"                    
                )
                .rowMapper(sucursalRowMapper)
                .fetchSize(tamañoLote)
                .build();
    }

    // Writer
    @Bean
    public JdbcBatchItemWriter<SucursalDTO> sucursalWriter() {
        return new JdbcBatchItemWriterBuilder<SucursalDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO SUCURSAL (ID_SUCURSAL, CODIGO, ID_ORGANISMO, SUCURSAL, CREACION, CREACIONFECHA) \r\n"
                		+ "VALUES (:idSucursal, :codigo, :idOrganismo, :sucursal, :creacion, :creacionFecha) \r\n" +
                     "ON DUPLICATE KEY UPDATE SUCURSAL = values(SUCURSAL), ACTUALIZACION = :actualizacion, ACTUALIZACIONFECHA = :actualizacionFecha")
                .dataSource(targetDataSource)
                .build();
    }

    // Step
    @Bean
    public Step sucursal1Step (SucursalListener listener, SucursalRowMapper sucursalRowMapper) {
        return new StepBuilder("sucursal1Step", jobRepository)
                .<SucursalDTO, SucursalDTO>chunk(tamañoLote, transactionManager)
                .reader(sucursalReader(sucursalRowMapper))                
                .processor(sucursalProcessor)
                .writer(sucursalWriter())    
                .listener((ItemReadListener<? super SucursalDTO>) listener)
                .listener((ItemProcessListener<? super SucursalDTO, ? super SucursalDTO>) listener)
                .listener((ItemWriteListener<? super SucursalDTO>) listener)
                .listener((StepExecutionListener) listener)
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(reintentos)
                .build();
    }

}
