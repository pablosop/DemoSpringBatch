package cl.chilecompra.batch.mapper.parametros;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.SucursalDTO;
import cl.chilecompra.batch.utils.FechasUtils;

@Component
public class SucursalRowMapper  implements RowMapper<SucursalDTO> {

    private static final Date FECHA_ACTUAL = new Date();
    
    
    private final String nombreCreacion;

    public SucursalRowMapper(@Value("${batch.nombre.parametro.sucursal}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }

    @Override
    public SucursalDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	SucursalDTO sucursalDTO = new SucursalDTO();
    	
        UUID uuid = UUID.randomUUID();
        FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();  
        sucursalDTO.setIdSucursal(uuid.toString());
        sucursalDTO.setCodigo(rs.getInt("orgCode"));
        
        String sucursal = rs.getString("orgName");
        
    	//Limpia caracteres no soportados
    	if(sucursal!=null)
    		sucursal  = sucursal.replaceAll("[^\\p{ASCII}]", "");
    	        
        sucursalDTO.setSucursal(sucursal);
        sucursalDTO.setCreacion(nombreCreacion);
        sucursalDTO.setCreacionFecha(fechaActual);
        sucursalDTO.setActualizacion(nombreCreacion);
        sucursalDTO.setActualizacionFecha(fechaActual);  

        return sucursalDTO;
    }
}

