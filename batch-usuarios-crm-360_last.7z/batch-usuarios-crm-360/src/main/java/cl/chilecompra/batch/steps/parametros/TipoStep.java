package cl.chilecompra.batch.steps.parametros;

import javax.sql.DataSource;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import cl.chilecompra.batch.dto.TipoDTO;
import cl.chilecompra.batch.listener.parametros.TipoListener;
import cl.chilecompra.batch.mapper.parametros.TipoRowMapper;

@Configuration
public class TipoStep  {
    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;
    
    @Value("${step.reintentos}")
    private Integer reintentos;
    
    @Value("${step.cantidad.lote}")
    private Integer tamañoLote;
    
    public TipoStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			            @Qualifier("origenDataSource") DataSource sourceDataSource,
			            @Qualifier("destinoDataSource") DataSource targetDataSource) {
		this.jobRepository = jobRepository;
		this.transactionManager = transactionManager;
		this.sourceDataSource = sourceDataSource;
		this.targetDataSource = targetDataSource;
	}    

    // Reader
    @Bean
    public JdbcCursorItemReader<TipoDTO> tipoReader(TipoRowMapper tipoRowMapper) {
        return new JdbcCursorItemReaderBuilder<TipoDTO>()
                .name("TipoDTOReader")
                .dataSource(sourceDataSource)
                .sql("SELECT dbo.gblOrganizationClass.oclCode, dbo.gblOrganizationClass.oclName  " 
                   + "FROM dbo.gblOrganizationClass " 
                   + "WHERE oclIsActive = 1 AND oclCode IN (1,2)"                    
                )
                .rowMapper(tipoRowMapper)
                .fetchSize(tamañoLote)
                .build();
    }

    // Writer
    @Bean
    public JdbcBatchItemWriter<TipoDTO> tipoWriter() {
        return new JdbcBatchItemWriterBuilder<TipoDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO TIPO (ID_TIPO, TIPO, CREACION, CREACIONFECHA) VALUES (:idTipo, :tipo, :creacion, :creacionFecha) " +
                     "ON DUPLICATE KEY UPDATE TIPO = values(TIPO), ACTUALIZACION = :actualizacion, ACTUALIZACIONFECHA = :actualizacionFecha")
                .dataSource(targetDataSource)
                .build();
    }

    // Step
    @Bean
    public Step tipo1Step(TipoListener listener, TipoRowMapper tipoRowMapper) {
        return new StepBuilder("tipo1Step", jobRepository)
                .<TipoDTO, TipoDTO>chunk(tamañoLote, transactionManager)
                .reader(tipoReader(tipoRowMapper))
                .writer(tipoWriter())
                .listener((ItemReadListener<? super TipoDTO>) listener)
                .listener((ItemProcessListener<? super TipoDTO, ? super TipoDTO>) listener)
                .listener((ItemWriteListener<? super TipoDTO>) listener)
                .listener((StepExecutionListener) listener)                
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(reintentos)
                .build();
    }

}

