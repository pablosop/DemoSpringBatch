package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;

@Data
public class UnidadDTO {

    private String idUnidad;
    private Integer codigo;
    private String idInstitucion;
    private String unidad;
    //Corresponde al origen del dato en este caso es BATCH-USUARIOS-CRM-360
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;



}
