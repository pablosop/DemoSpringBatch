package cl.chilecompra.batch.steps.usuarios;

import javax.sql.DataSource;

import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import cl.chilecompra.batch.dto.UsuarioDTO;
import cl.chilecompra.batch.listener.usuario.UsuarioListener;
import cl.chilecompra.batch.mapper.usuario.UsuarioRowMapper;



@Configuration
public class UsuariosStep {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;
    
    @Value("${step.reintentos}")
    private Integer reintentos;
    
    @Value("${step.cantidad.lote}")
    private Integer tamañoLote;

    @Value("${step.cantidad.tolerancia.skip}")
    private Integer tolerancia;
    
    public UsuariosStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			            @Qualifier("origenDataSource") DataSource sourceDataSource,
			            @Qualifier("destinoDataSource") DataSource targetDataSource){
		this.jobRepository                    = jobRepository;
		this.transactionManager               = transactionManager;
		this.sourceDataSource                 = sourceDataSource;
		this.targetDataSource                 = targetDataSource;
		
	}
    
    // Reader
    @Bean
    public JdbcCursorItemReader<UsuarioDTO> usuarioReader1(UsuarioRowMapper usuarioRowMapper) {
        return new JdbcCursorItemReaderBuilder<UsuarioDTO>()
                .name("UsuarioReader1")
                .dataSource(sourceDataSource)
                .sql("SELECT \r\n"
                		+ "	u.usrID,\r\n"
                		+ "	u.usrIsActive,\r\n"
                		+ "	u.usrCode,\r\n"
                		+ "	u.usrFirstName,\r\n"
                		+ "	u.usrLastName,\r\n"
                		+ "	u.usrTaxID,\r\n"
                		+ "	u.usrCreationDate,\r\n"
                		+ "	--12345678 as rut,\r\n"
                		+ "	-- '5' as dv\r\n"
                		+ "	LEFT(REPLACE(TRANSLATE(usrTaxID, 'abcdefghijklmnopqrstuvwxyz+()- ,#+./&', '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'), '@', ''), LEN(REPLACE(TRANSLATE(usrTaxID, 'abcdefghijlmnopqrstuvwxyz+()- ,#+.', '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'), '@', ''))-1) as rut, \r\n"
                		+ "	RIGHT(REPLACE(TRANSLATE(usrTaxID, 'abcdefghijlmnopqrstuvwxyz+()- ,#+./&', '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'), '@', ''),1) as dv\r\n"
                		+ "	--case when e.id is null then 0 else e.id end as idCertificado\r\n"
                		+ "FROM \r\n"
                		+ "	gblUser u\r\n"
                		+ "where \r\n"
                		+ "	--usrIsActive = 1\r\n"
                		+ "	usrLastLogin >=  DATEADD(month, -12, GETDATE())\r\n"
                		+ "	and LEN(REPLACE(TRANSLATE(usrTaxID, 'abcdefghijlmnopqrstuvwxyz+()- ,#+.', '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'), '@', '')) in (8,9)")
                .rowMapper(usuarioRowMapper)
                .fetchSize(tamañoLote)
                .build();
    }

    // Writer
    @Bean
    public JdbcBatchItemWriter<UsuarioDTO> usuarioWriter1() {
        return new JdbcBatchItemWriterBuilder<UsuarioDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO USUARIO\r\n"
                		+ "(ID_USUARIO, CODIGO, RUT_USUARIO, DV_USUARIO, NOMBRES_USUARIO, APELLIDOS_USUARIO, ANTIGUEDAD_USUARIO, ID_ESTADOACTIVO, CREACION, CREACIONFECHA)\r\n"
                		+ "VALUES(:idUsuario, :codigo, :rutUsuario, :dvUsuario, :nombresUsuario, :apellidosUsuario, :antiguedadUsuario, :idEstadoActivo, :creacion, :creacionFecha)\r\n"
                		+ "ON DUPLICATE KEY UPDATE\r\n"
                		+ "    NOMBRES_USUARIO = VALUES(NOMBRES_USUARIO),   -- Actualiza con el nuevo valor\r\n"
                		+ "    APELLIDOS_USUARIO = VALUES(APELLIDOS_USUARIO), -- Actualiza con el nuevo valor\r\n"
                		+ "    ANTIGUEDAD_USUARIO = VALUES(ANTIGUEDAD_USUARIO), -- Actualiza con el nuevo valor\r\n"
                		+ "    ID_ESTADOACTIVO = VALUES(ID_ESTADOACTIVO),   -- Actualiza con el nuevo valor\r\n"
                        + "    ACTUALIZACION      = :actualizacion, \r\n"
                		+ "    ACTUALIZACIONFECHA = :actualizacionFecha \r\n"                		
                		+ "")
                .dataSource(targetDataSource)
                .build();
    }
 
    // Step
    @Bean
    public Step usuarioStep(UsuarioListener listener, UsuarioRowMapper usuario1RowMapper) {
        return new StepBuilder("usuarioStep", jobRepository)
                .<UsuarioDTO, UsuarioDTO>chunk(tamañoLote, transactionManager)
                .reader(usuarioReader1(usuario1RowMapper))
                .writer(usuarioWriter1())
                .listener((ItemReadListener<? super UsuarioDTO>) listener)
                .listener((ItemWriteListener<? super UsuarioDTO>) listener)
                .listener((StepExecutionListener) listener)                
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(tolerancia) 
                .retryLimit(reintentos)
                .retry(Exception.class)      
                .build();
    }
  


    
    
}
