package cl.chilecompra.batch.mapper.rol;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.RolUnidadUsuarioDTO;
import cl.chilecompra.batch.utils.FechasUtils;

@Component
public class RolUnidadUsuarioRowMapper implements RowMapper<RolUnidadUsuarioDTO> {
	
    private final String nombreCreacion;

    public RolUnidadUsuarioRowMapper(@Value("${batch.nombre.rol.unidadUsuario}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }
	
    @Override
    public RolUnidadUsuarioDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	RolUnidadUsuarioDTO rolUnidad = new RolUnidadUsuarioDTO();
    	
        FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();  
        
    	rolUnidad.setUroRole        (rs.getInt("uroRole"));
    	rolUnidad.setUroUser        (rs.getInt("uroUser"));
    	rolUnidad.setUroOrganization(rs.getInt("uroOrganization"));    	
    	rolUnidad.setUroIsActive    (rs.getInt("uroIsActive"));   	
    	
    	rolUnidad.setCreacion(nombreCreacion);
    	rolUnidad.setCreacionFecha(fechaActual);
    	rolUnidad.setActualizacion(nombreCreacion);
    	rolUnidad.setActualizacionFecha(fechaActual);    	
    	
        return rolUnidad;
    }
}

