package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;


@Data
public class InstitucionDTO { 

    private String idInstitucion;

    private Long codigo;

    private String institucion;

    private String creacion;

    private Date creacionFecha;

    private String actualizacion;

    private Date actualizacionFecha;


// Campos de tabla de origen

    private long entID;

    private String entName;

    

}

