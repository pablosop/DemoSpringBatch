package cl.chilecompra.batch.steps.usuarios;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.batch.item.support.CompositeItemWriter;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import cl.chilecompra.batch.dto.UsuarioContactoDTO;
import cl.chilecompra.batch.listener.usuario.UsuarioContactoListener;
import cl.chilecompra.batch.mapper.usuario.UsuarioContactoRowMapper;
import cl.chilecompra.batch.processor.usuario.ObtenerIDUsuarioProcessor;

@Configuration
public class UsuariosContactosStep {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;
    
    @Value("${step.reintentos}")
    private Integer reintentos;
    
    @Value("${step.cantidad.lote}")
    private Integer tamañoLote;

    @Value("${step.cantidad.tolerancia.skip}")
    private Integer tolerancia;
    
    private ObtenerIDUsuarioProcessor obtenerIDUsuarioProcessor;

    public UsuariosContactosStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			            @Qualifier("origenDataSource") DataSource sourceDataSource,
			            @Qualifier("destinoDataSource") DataSource targetDataSource,
			            ObtenerIDUsuarioProcessor obtenerIDUsuarioProcessor    		){
		this.jobRepository                    = jobRepository;
		this.transactionManager               = transactionManager;
		this.sourceDataSource                 = sourceDataSource;
		this.targetDataSource                 = targetDataSource;
		this.obtenerIDUsuarioProcessor        = obtenerIDUsuarioProcessor;
		
	}
    
    // Reader
    @Bean
    public JdbcCursorItemReader<UsuarioContactoDTO> usuarioReader3(UsuarioContactoRowMapper usuarioContactoRowMapper) {
       
        return new JdbcCursorItemReaderBuilder<UsuarioContactoDTO>()
                .name("UsuarioReader3")
                .dataSource(sourceDataSource)
                .sql("SELECT u.usrID,\r\n"
                		+ "  		u.usrCode,\r\n"
                		+ "  		u.usrEmail,\r\n"
                		+ "  		u.usrEmailAlternative,\r\n"
                		+ "  		case left(REPLACE(TRANSLATE(usrPhone, 'abcdefghijklmnopqrstuvwxyz+()- ,#+', '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'), '@', '') ,\r\n"
                		+ "  	4)\r\n"
                		+ "  	when '5602' then '562' + SUBSTRING(REPLACE(TRANSLATE(usrPhone, 'abcdefghijklmnopqrstuvwxyz+()- ,#+', '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'), '@', ''), 5, 20)\r\n"
                		+ "  	else REPLACE(TRANSLATE(usrPhone, 'abcdefghijklmnopqrstuvwxyz+()- ,#+', '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'), '@', '')\r\n"
                		+ "  end as usrPhone,\r\n"
                		+ "  /*		case\r\n"
                		+ "  	when LEN(u.usrMobile) > 0 then SUBSTRING(u.usrMobile, 1, 10)\r\n"
                		+ "  	ELSE null\r\n"
                		+ "  end as usrMobile,\r\n"
                		+ "  */\r\n"
                		+ "  replace(u.usrMobile,'-','') as usrMobile,\r\n"
                		+ "  		u.usrFax,\r\n"
                		+ "  		u.usrMailFormat\r\n"
                		+ "  FROM\r\n"
                		+ "  gblUser u\r\n"
                		+ "  where\r\n"
                		+ "  usrIsActive = 1\r\n"
                		+ "  and usrLastLogin >= DATEADD(month, -12, GETDATE())\r\n"
                        + "  and LEN(REPLACE(TRANSLATE(u.usrTaxID, 'abcdefghijlmnopqrstuvwxyz+()- ,#+.', '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'), '@', '')) in (8,9)\r\n"
                		+ "  order by usrCode ASC")
                .rowMapper(usuarioContactoRowMapper)
                .fetchSize(tamañoLote)
                .build();
    }

    // Writer
    @Bean
    public JdbcBatchItemWriter<UsuarioContactoDTO> usuarioWriter31() {
        return new JdbcBatchItemWriterBuilder<UsuarioContactoDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO TELEFONO_USUARIO\r\n"
                		+ "( ID_USUARIO, TELEFONO, ID_ESTADOACTIVO, CREACION, CREACIONFECHA)\r\n"
                		+ "VALUES( :id_usuario, COALESCE(COALESCE(:usrMobile, :usrPhone),'NO ENCONTRADO'), :estado, :creacion, :creacionFecha)\r\n"
                		+ "ON DUPLICATE KEY update\r\n"
                		+ "   TELEFONO = values(TELEFONO), \r\n"
                		+ "   ID_ESTADOACTIVO = values(ID_ESTADOACTIVO), \r\n"
                		+ "   ACTUALIZACION = :actualizacion, \r\n"
                		+ "   ACTUALIZACIONFECHA = :actualizacionFecha")
                .dataSource(targetDataSource)
                .build();
    }
    
    // Writer
    @Bean
    public JdbcBatchItemWriter<UsuarioContactoDTO> usuarioWriter32() {
        return new JdbcBatchItemWriterBuilder<UsuarioContactoDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO EMAIL_USUARIO\r\n"
                		+ "( ID_USUARIO, EMAIL_USUARIO, ID_ESTADOACTIVO, CREACION, CREACIONFECHA)\r\n"
                		+ "VALUES( :id_usuario, :usrEmail, :estado, :creacion, :creacionFecha)\r\n"
                		+ "ON DUPLICATE KEY update\r\n"
                		+ "    EMAIL_USUARIO = VALUES(EMAIL_USUARIO),\r\n"
                		+ "    ID_ESTADOACTIVO = VALUES(ID_ESTADOACTIVO),\r\n"
                		+ "    ACTUALIZACION = :actualizacion,\r\n"
                		+ "    ACTUALIZACIONFECHA = :actualizacionFecha")
                .dataSource(targetDataSource)
                .build();
    }
        

    @Bean
    public CompositeItemWriter<UsuarioContactoDTO> compositeItemWriter(
            ItemWriter<UsuarioContactoDTO> usuarioWriter31,
            ItemWriter<UsuarioContactoDTO> usuarioWriter32) {
        CompositeItemWriter<UsuarioContactoDTO> compositeWriter = new CompositeItemWriter<>();
        compositeWriter.setDelegates(List.of(usuarioWriter31, usuarioWriter32));
        return compositeWriter;
    }

    @Bean
    public Step usuarioContactoStep(UsuarioContactoListener listener,
    		                  CompositeItemWriter<UsuarioContactoDTO> compositeItemWriter,
    		                  UsuarioContactoRowMapper usuario3RowMapper) {
        return new StepBuilder("usuarioContactoStep", jobRepository)
                .<UsuarioContactoDTO, UsuarioContactoDTO>chunk(tamañoLote, transactionManager)
                .reader(usuarioReader3(usuario3RowMapper))
                .processor(obtenerIDUsuarioProcessor)
                .writer(compositeItemWriter)
                .listener((ItemReadListener<? super UsuarioContactoDTO>) listener)
                .listener((ItemProcessListener<? super UsuarioContactoDTO, ? super UsuarioContactoDTO>) listener)
                .listener((ItemWriteListener<? super UsuarioContactoDTO>) listener)
                .listener((StepExecutionListener) listener)
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(tolerancia) 
                .retryLimit(reintentos)
                .retry(Exception.class)      
                .build();
    }
  
}
