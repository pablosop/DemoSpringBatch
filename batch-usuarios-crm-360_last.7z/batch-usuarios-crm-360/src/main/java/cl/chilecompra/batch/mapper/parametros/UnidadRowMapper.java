package cl.chilecompra.batch.mapper.parametros;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.UnidadDTO;
import cl.chilecompra.batch.utils.FechasUtils;

@Component
public class UnidadRowMapper implements RowMapper<UnidadDTO> {    
    
    private final String nombreCreacion;

    public UnidadRowMapper(@Value("${batch.nombre.parametro.unidad}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }

    @Override
    public UnidadDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	UnidadDTO unidadDTO = new UnidadDTO();
    	
        UUID uuid = UUID.randomUUID();
        FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();  
        unidadDTO.setIdUnidad(uuid.toString());
        unidadDTO.setUnidad(rs.getString("orgName"));    
        unidadDTO.setCodigo(rs.getInt("orgID"));
        unidadDTO.setCreacion(nombreCreacion);
        unidadDTO.setCreacionFecha(fechaActual);
        unidadDTO.setActualizacion(nombreCreacion);
        unidadDTO.setActualizacionFecha(fechaActual);

        return unidadDTO;
    }
}

