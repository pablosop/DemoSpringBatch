package cl.chilecompra.batch.steps.empresas;

import javax.sql.DataSource;

import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import cl.chilecompra.batch.dto.OrganismoDTO;
import cl.chilecompra.batch.listener.organismo.OrganismoListener;
import cl.chilecompra.batch.mapper.organismo.OrganismoRowMapper;

@Configuration
public class EmpresasStep {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;

    @Value("${step.reintentos}")
    private Integer reintentos;
    
    @Value("${step.cantidad.lote}")
    private Integer tamañoLote;

    @Value("${step.cantidad.tolerancia.skip}")
    private Integer tolerancia;
    
    public EmpresasStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			            @Qualifier("origenDataSource") DataSource sourceDataSource,
			            @Qualifier("destinoDataSource") DataSource targetDataSource){
		this.jobRepository                    = jobRepository;
		this.transactionManager               = transactionManager;
		this.sourceDataSource                 = sourceDataSource;
		this.targetDataSource                 = targetDataSource;
		
	}
    
    // Reader
    @Bean
    public JdbcCursorItemReader<OrganismoDTO> tamañoEmpresasReader(OrganismoRowMapper organismoRowMapper) {
        return new JdbcCursorItemReaderBuilder<OrganismoDTO>()
                .name("OrganismoReader")
                .dataSource(sourceDataSource)
                .sql("SELECT  t.entcode, \r\n"
            		+ "	      t.idtamano_sii\r\n"
            		+ "  FROM DCCPProveedor.dbo.proveedor_tamano_oficial t\r\n"
            		+ "  JOIN gblOrganization o\r\n"
            		+ "    ON CAST(t.entcode AS INT) = o.orgEnterprise \r\n"
            		+ "  JOIN gblSecUserRole gsur \r\n"
            		+ "    ON o.orgCode = gsur.uroOrganization \r\n"
            		+ "  JOIN gblUser gu \r\n"
            		+ "    ON gsur.uroUser = gu.usrCode \r\n"
            		+ " WHERE o.orgIsActive = 1\r\n"
            		+ "   AND gsur.uroIsActive = 1\r\n"
            		+ "   AND gu.usrIsActive = 1\r\n"
            		+ "   AND gu.usrLastLogin >=  DATEADD(month, -12, GETDATE())\r\n"
            		+ " GROUP by t.entcode, \r\n"
            		+ "	      t.idtamano_sii")
                .rowMapper(organismoRowMapper)
                .fetchSize(tamañoLote)
                .build();
    }

    // Writer
    @Bean
    public JdbcBatchItemWriter<OrganismoDTO> organismoByCodeWriter() {
        return new JdbcBatchItemWriterBuilder<OrganismoDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("UPDATE ORGANISMO\r\n"
                   + "   SET ID_ORGANISMOTAMANOSII = :idOrganismoTamanoSII \r\n"                  
                   + " WHERE CODIGO  = :codigo")
                .dataSource(targetDataSource)
                .build();
    }
 
    // Step
    @Bean
    public Step empresaStep(OrganismoListener listener, OrganismoRowMapper organismoRowMapper) {
        return new StepBuilder("empresaStep", jobRepository)
                .<OrganismoDTO, OrganismoDTO>chunk(tamañoLote, transactionManager)
                .reader(tamañoEmpresasReader(organismoRowMapper))
                .writer(organismoByCodeWriter())
                .listener((ItemReadListener<? super OrganismoDTO>) listener)
                .listener((ItemWriteListener<? super OrganismoDTO>) listener)
                .listener((StepExecutionListener) listener)                
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(tolerancia) 
                .retryLimit(reintentos)
                .retry(Exception.class)      
                .build();
    }  
    
}
