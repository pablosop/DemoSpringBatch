package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;

@Data
public class TipoDTO {


    private Long idTipo;
    private String tipo;
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;

}
