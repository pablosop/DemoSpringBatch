package cl.chilecompra.batch.processor.parametros;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;

import cl.chilecompra.batch.dto.UnidadDTO;

public class UnidadProcessor  implements ItemProcessor<UnidadDTO, UnidadDTO> {

    private final Map<Integer, String> userMap = new HashMap<>();

    
    /**
     * TODO
     * OJO aqui, esto carga todos los registros en memoria
     * */
    
    public UnidadProcessor(@Qualifier("destinoDataSource") DataSource targetDataSource) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(targetDataSource);
        String sql = "SELECT ID_INSTITUCION, CODIGO FROM INSTITUCION";
        jdbcTemplate.query(sql, rs -> {
            userMap.put(rs.getInt("CODIGO"), rs.getString("ID_INSTITUCION"));
        });
    }

    @Override
    public UnidadDTO process(UnidadDTO item) {
        String idInstitucion  = userMap.get(item.getCodigo());
        if (idInstitucion != null) {
            item.setIdInstitucion(idInstitucion);
            return item;
        }
        return null; // O manejar el caso donde no hay coincidencia
    }
}

