package cl.chilecompra.batch.steps.parametros;

import javax.sql.DataSource;

import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import cl.chilecompra.batch.dto.OrganismoTamanoSIIDTO;
import cl.chilecompra.batch.listener.parametros.OrganismoTamanoSIIListener;
import cl.chilecompra.batch.mapper.parametros.OrganismoTamanoSIIRowMapper;

@Configuration
public class OrganismoTamanoSIIStep {
    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;
    
    @Value("${step.reintentos}")
    private Integer reintentos;
    
    @Value("${step.cantidad.lote}")
    private Integer tamañoLote;
    
    public OrganismoTamanoSIIStep(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			            @Qualifier("origenDataSource") DataSource sourceDataSource,
			            @Qualifier("destinoDataSource") DataSource targetDataSource) {
		this.jobRepository = jobRepository;
		this.transactionManager = transactionManager;
		this.sourceDataSource = sourceDataSource;
		this.targetDataSource = targetDataSource;
	}
    

    // Reader
    @Bean
    public JdbcCursorItemReader<OrganismoTamanoSIIDTO> organismoTamanoSIIReader(OrganismoTamanoSIIRowMapper organismoTamanoSIIRowMapper) {
        return new JdbcCursorItemReaderBuilder<OrganismoTamanoSIIDTO>()
                .name("OrganismoTamanoSIIDTOReader")
                .dataSource(sourceDataSource)
                .sql("SELECT idtamano_sii, tamano_principal, tamano_subgrupo, tramo_ventas, glosa_completa_sii, fecha_registro, valido " +
                     "FROM DCCPProveedor.dbo.proveedor_tipo_tamano_sii"                    
                )
                .rowMapper(organismoTamanoSIIRowMapper)
                .fetchSize(tamañoLote)
                .build();
    }

    // Writer
    @Bean
    public JdbcBatchItemWriter<OrganismoTamanoSIIDTO> organismoTamanoSIIWriter() {
        return new JdbcBatchItemWriterBuilder<OrganismoTamanoSIIDTO>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO ORGANISMOTAMANOSII (ID_ORGANISMOTAMANOSII, TAMANO_PRINCIPAL, TAMANO_SUBGRP, TRAMO_VENTA, GLOSA_COMPLETA_SII, ID_ESTADOACTIVO, CREACION, CREACIONFECHA) " + 
                     "VALUES (:idOrganismoTamanoSII, :tamanoPrincipal, :tamanoSubgrupo, :tramoVenta, :glosaCompletaSII, :idEstadoActivo, :creacion,  :creacionFecha) " +                  
                      "ON DUPLICATE KEY UPDATE TAMANO_PRINCIPAL = VALUES(TAMANO_PRINCIPAL), TAMANO_SUBGRP = VALUES(TAMANO_SUBGRP), TRAMO_VENTA = VALUES(TRAMO_VENTA)," + 
                      " GLOSA_COMPLETA_SII = VALUES(GLOSA_COMPLETA_SII), ID_ESTADOACTIVO = VALUES(ID_ESTADOACTIVO), ACTUALIZACION = :actualizacion, ACTUALIZACIONFECHA = :actualizacionFecha")
                .dataSource(targetDataSource)
                .build();
    }

    // Step
    @Bean
    public Step organismoTamanoSII1Step(OrganismoTamanoSIIListener listener, OrganismoTamanoSIIRowMapper organismoTamanoSIIRowMapper) {
        return new StepBuilder("organismoTamanoSII1Step", jobRepository)
                .<OrganismoTamanoSIIDTO, OrganismoTamanoSIIDTO>chunk(tamañoLote, transactionManager)
                .reader(organismoTamanoSIIReader(organismoTamanoSIIRowMapper))
                .writer(organismoTamanoSIIWriter())
                .listener((ItemReadListener<? super OrganismoTamanoSIIDTO>) listener)
                .listener((ItemWriteListener<? super OrganismoTamanoSIIDTO>) listener)
                .listener((StepExecutionListener) listener)                
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(reintentos)
                .build();
    }

}



