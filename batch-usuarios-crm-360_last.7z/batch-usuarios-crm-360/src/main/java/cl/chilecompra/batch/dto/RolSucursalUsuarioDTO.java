package cl.chilecompra.batch.dto;

import java.util.Date;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Table(name = "ROL_SUCURSAL_USUARIO")
public class RolSucursalUsuarioDTO {

    private Integer uroRole;
	private Integer uroUser;
	private Integer uroOrganization;
	private Integer uroIsActive;

   @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String idRol;
    private String idSucursal;
    private Integer idRolSucursal;
    private String idUsuario;
    private int idEstadoActivo;
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;

}
