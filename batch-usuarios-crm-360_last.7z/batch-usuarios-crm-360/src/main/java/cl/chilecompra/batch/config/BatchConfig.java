package cl.chilecompra.batch.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BatchConfig {

    private final JobRepository jobRepository;
    
    //Parametros
    private final Step institucion1Step        ;
    private final Step unidad1Step             ;
    private final Step organismoParametroStep  ;
    private final Step sucursal1Step           ;
    private final Step rol1Step                ;
    private final Step tipo1Step               ;
    private final Step organismoTamanoSII1Step ;

    //usuarios
    private final Step usuarioStep;
    private final Step usuarioContactoStep;
    private final Step institucionUsuarioStep;
    private final Step organismoUsuarioStep;
    private final Step tipoUsuario1Step;

    //roles
    private final Step rolUnidad1Step;
    private final Step rolUnidadUsuario1Step;
    private final Step rolSucursal1Step;    
    private final Step rolSucursalUsuario1Step;  
    
    //empresa
    private final Step empresaStep;
    private final Step empresaVigenciaByRutStep;
    private final Step empresaVigenciaByRut2Step;
    
    //empresa acreditacion
    private final Step empresaAcreditacionHabilidadStep;

    public BatchConfig(JobRepository jobRepository,
    		//Parametros ETL
    		@Qualifier("institucion1Step")        Step institucion1Step  ,
		    @Qualifier("unidad1Step")             Step unidad1Step,
		    @Qualifier("organismoParametroStep")  Step organismoParametroStep              ,
		    @Qualifier("sucursal1Step")           Step sucursal1Step               ,
		    @Qualifier("rol1Step")                Step rol1Step          ,
		    @Qualifier("tipo1Step")               Step tipo1Step ,
		    @Qualifier("organismoTamanoSII1Step") Step organismoTamanoSII1Step            ,
    		//Usuarios
    		@Qualifier("usuarioStep") Step usuarioStep,
    		@Qualifier("usuarioContactoStep") Step usuarioContactoStep,
    		@Qualifier("institucionUsuarioStep") Step institucionUsuarioStep,
    		@Qualifier("organismoUsuarioStep") Step organismoUsuarioStep,
    		@Qualifier("tipoUsuario1Step") Step tipoUsuario1Step,
    		//roles
    		@Qualifier("rolUnidad1Step") Step rolUnidad1Step,
    		@Qualifier("rolUnidadUsuario1Step") Step rolUnidadUsuario1Step,
    		@Qualifier("rolSucursal1Step") Step rolSucursal1Step,
            @Qualifier("rolSucursalUsuario1Step") Step rolSucursalUsuario1Step,
    		//Empresas
    		@Qualifier("empresaStep") Step empresaStep,
    		@Qualifier("empresaVigenciaByRutStep") Step empresaVigenciaByRutStep,
    		@Qualifier("empresaVigenciaByRut2Step") Step empresaVigenciaByRut2Step,
    		//EmpresaAcreditacionHabilidad
    		@Qualifier("empresaAcreditacionHabilidadStep") Step empresaAcreditacionHabilidadStep
    		) {
        this.jobRepository               = jobRepository;
        //Parametros
	        this.institucion1Step        = institucion1Step        ;
	        this.unidad1Step             = unidad1Step             ;
	        this.organismoParametroStep  = organismoParametroStep  ;
	        this.sucursal1Step           = sucursal1Step           ;
	        this.rol1Step                = rol1Step                ;
	        this.tipo1Step               = tipo1Step               ;
	        this.organismoTamanoSII1Step = organismoTamanoSII1Step ;
	    //usuario
	        this.usuarioStep = usuarioStep;
	        this.usuarioContactoStep = usuarioContactoStep;
	        this.institucionUsuarioStep = institucionUsuarioStep;
	        this.organismoUsuarioStep = organismoUsuarioStep;
	        this.tipoUsuario1Step = tipoUsuario1Step;
	    //roles
	        this.rolUnidad1Step = rolUnidad1Step;
	        this.rolUnidadUsuario1Step = rolUnidadUsuario1Step;
	        this.rolSucursal1Step = rolSucursal1Step;
            this.rolSucursalUsuario1Step = rolSucursalUsuario1Step;
	    //empresas
	        this.empresaStep   = empresaStep;
	        this.empresaVigenciaByRutStep  = empresaVigenciaByRutStep;
	        this.empresaVigenciaByRut2Step  = empresaVigenciaByRut2Step;
	    //EmpresaAcreditacionHabilidad
	        this.empresaAcreditacionHabilidadStep = empresaAcreditacionHabilidadStep;

    }
    
    // 2.7: Job Configuration
    @Bean
    public Job usuariosETL() {
        return new JobBuilder("usuariosETL", jobRepository)
    		//Parametros        		
        		.start(institucion1Step)
                    .on("*").to(unidad1Step) // Siempre continúa al siguiente paso
                .from(unidad1Step)
                    .on("*").to(organismoParametroStep)
                .from(organismoParametroStep)
                    .on("*").to(sucursal1Step)//con detalle de string raro                    
                .from(sucursal1Step)
                    .on("*").to(rol1Step)
                .from(rol1Step)
                    .on("*").to(tipo1Step)
                .from(tipo1Step)
                    .on("*").to(organismoTamanoSII1Step)             
                .from(organismoTamanoSII1Step)
                    .on("*").to(usuarioStep)
            //Usuarios                    
                .from(usuarioStep)
                    .on("*").to(usuarioContactoStep)                
                .from(usuarioContactoStep)
                    .on("*").to(institucionUsuarioStep)
                .from(institucionUsuarioStep)
                    .on("*").to(organismoUsuarioStep)   
                .from(organismoUsuarioStep)
                    .on("*").to(tipoUsuario1Step)                 
            //roles            
            .from(tipoUsuario1Step)          
                    .on("*").to(rolUnidad1Step)        
                .from(rolUnidad1Step)
                    .on("*").to(rolUnidadUsuario1Step)
                .from(rolUnidadUsuario1Step)                
                    .on("*").to(rolSucursal1Step)                    
                .from(rolSucursal1Step)
                    .on("*").to(rolSucursalUsuario1Step)                    
            //empresas
               .from(rolSucursalUsuario1Step)
                    .on("*").to(empresaStep)
                .from(empresaStep)
                    .on("*").to(empresaVigenciaByRutStep)
                .from(empresaVigenciaByRutStep)
                    .on("*").to(empresaVigenciaByRut2Step)
                .from(empresaVigenciaByRut2Step)
                    .on("*").to(empresaAcreditacionHabilidadStep)
             //empresasAcreditacionHabilidad                    
                .from(empresaAcreditacionHabilidadStep)
                    .on("*").end() // Marca el fin del Job
                .end()
                .build();
    }
    
}
