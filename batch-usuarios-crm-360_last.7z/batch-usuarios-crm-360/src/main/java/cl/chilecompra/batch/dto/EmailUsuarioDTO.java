package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;

@Data
public class EmailUsuarioDTO {

    private Long id;
    private String idUsuario;
    private String emailUsuario;
    private int idEstadoActivo;
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;

}
