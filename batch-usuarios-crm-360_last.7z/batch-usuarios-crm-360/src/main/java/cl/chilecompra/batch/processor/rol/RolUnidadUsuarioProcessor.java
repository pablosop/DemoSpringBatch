package cl.chilecompra.batch.processor.rol;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.RolUnidadUsuarioDTO;


@Component
public class RolUnidadUsuarioProcessor implements ItemProcessor<RolUnidadUsuarioDTO, RolUnidadUsuarioDTO> {

    private Map<Integer, String> rolMap = new HashMap<>();
	private Map<Integer, String> unidadMap = new HashMap<>();
    private Map<Integer, String> userMap = new HashMap<>();
    private Map<String, Integer> rolUnidadMap = new HashMap<>();    

    @Override
    public RolUnidadUsuarioDTO process(RolUnidadUsuarioDTO item) {
        String idRol = rolMap.get(item.getUroRole());
        if (idRol != null) {
            item.setIdRol(idRol);
            String idUnidad = unidadMap.get(item.getUroOrganization());
            if (idUnidad != null) {
                item.setIdUnidad(idUnidad);
                int uroUser = item.getUroUser();
                String idUsuario = userMap.get(uroUser);
                if (idUsuario != null) {
                    item.setIdUsuario(idUsuario);
                    // Generar la clave combinada para buscar en el mapa
                    String key = item.getIdRol() + "-" + item.getIdUnidad();
                    Integer idRolUnidad = rolUnidadMap.get(key);
                    // Si se encuentra el ID, lo asigna al objeto; si no, filtra el registro
                    if (idRolUnidad != null) {
                        item.setIdRolUnidad(idRolUnidad);
                        return item;
                    }                   
                }               
            }
        }
        return null; 
    }

    @BeforeStep
    public void beforeStep(StepExecution stepExecution) {
       
        JobExecution jobExecution = stepExecution.getJobExecution();
        this.rolMap = (Map<Integer, String>) jobExecution.getExecutionContext().get("rolMap"); 
        this.unidadMap = (Map<Integer, String>) jobExecution.getExecutionContext().get("unidadMap"); 
        this.userMap = (Map<Integer, String>) jobExecution.getExecutionContext().get("userMap"); 
        this.rolUnidadMap = (Map<String, Integer>) jobExecution.getExecutionContext().get("rolUnidadMap"); 

    }


}
