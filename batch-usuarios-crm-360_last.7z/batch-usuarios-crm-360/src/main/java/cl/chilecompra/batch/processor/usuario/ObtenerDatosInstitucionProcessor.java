package cl.chilecompra.batch.processor.usuario;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.UsuarioInstitucionDTO;


@Component
public class ObtenerDatosInstitucionProcessor implements ItemProcessor<UsuarioInstitucionDTO, UsuarioInstitucionDTO> {

	private Map<Integer, String> institucionMap = new HashMap<>();
    private Map<Integer, String> userMap = new HashMap<>();
    
    @Override
    public UsuarioInstitucionDTO process(UsuarioInstitucionDTO item) {
        String idInstitucion = institucionMap.get(item.getEntID());
        if (idInstitucion != null) {
            item.setId_institucion(idInstitucion);
            String idUsuario = userMap.get(Integer.valueOf(item.getUroUser()));
            if (idUsuario != null) {
                item.setId_usuario(idUsuario);
                return item;
            }else{return null;}            
        }
        return null; // O manejar el caso donde no hay coincidencia
    }

    @BeforeStep
    public void beforeStep(StepExecution stepExecution) {                     
        JobExecution jobExecution = stepExecution.getJobExecution();
        this.userMap = (Map<Integer, String>) jobExecution.getExecutionContext().get("userMap"); 
        this.institucionMap = (Map<Integer, String>) jobExecution.getExecutionContext().get("institucionMap");       

    }

}
