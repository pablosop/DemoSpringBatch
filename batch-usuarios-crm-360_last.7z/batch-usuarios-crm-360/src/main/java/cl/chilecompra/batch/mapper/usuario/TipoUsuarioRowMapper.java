package cl.chilecompra.batch.mapper.usuario;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.TipoUsuarioDTO;
import cl.chilecompra.batch.utils.FechasUtils;

@Component
public class TipoUsuarioRowMapper implements RowMapper<TipoUsuarioDTO> {
	
    private final String nombreCreacion;

    public TipoUsuarioRowMapper(@Value("${batch.nombre.usuario6}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }
	
    @Override
    public TipoUsuarioDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	TipoUsuarioDTO tipoUsuario = new TipoUsuarioDTO();
		FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();
        
    	tipoUsuario.setUroUser(rs.getString("uroUser"));	
    	tipoUsuario.setOrgClass(rs.getInt   ("orgClass"));   
    	
    	tipoUsuario.setCreacion(nombreCreacion);
    	tipoUsuario.setCreacionFecha(fechaActual);
    	tipoUsuario.setActualizacion(nombreCreacion);
    	tipoUsuario.setActualizacionFecha(fechaActual);    	
    	
        return tipoUsuario;
    }
}

