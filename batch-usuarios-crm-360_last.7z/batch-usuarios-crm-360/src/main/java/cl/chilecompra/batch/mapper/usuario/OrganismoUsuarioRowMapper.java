package cl.chilecompra.batch.mapper.usuario;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.dto.OrganismoUsuarioDTO;
import cl.chilecompra.batch.utils.FechasUtils;

@Component
public class OrganismoUsuarioRowMapper implements RowMapper<OrganismoUsuarioDTO> {

    private final String nombreCreacion;

    public OrganismoUsuarioRowMapper(@Value("${batch.nombre.usuario5}") String nombreCreacion) {
        this.nombreCreacion = nombreCreacion;
    }
    
    @Override
    public OrganismoUsuarioDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
    	OrganismoUsuarioDTO organismoUsuario = new OrganismoUsuarioDTO();
    	
        FechasUtils fechasUtils = new FechasUtils();
        Date fechaActual = fechasUtils.obtenerFechaHoraMinutos();
        
    	organismoUsuario.setUroUser(rs.getString("uroUser"));	
    	organismoUsuario.setEntID	 (rs.getInt   ("entID"  ));
    	organismoUsuario.setOrgClas(rs.getInt   ("orgClass"));
    	
    	organismoUsuario.setEstado(1);
    	organismoUsuario.setCreacion(nombreCreacion);
    	organismoUsuario.setCreacionFecha(fechaActual);
    	organismoUsuario.setActualizacion(nombreCreacion);
    	organismoUsuario.setActualizacionFecha(fechaActual);    	
    	
        return organismoUsuario;
    }
}

