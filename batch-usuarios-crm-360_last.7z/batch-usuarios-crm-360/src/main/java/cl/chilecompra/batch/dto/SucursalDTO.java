package cl.chilecompra.batch.dto;

import java.util.Date;

import lombok.Data;

@Data
public class SucursalDTO {

    private String idSucursal;
    private Integer codigo;
    private String idOrganismo;
    private String sucursal;
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;
    

}
