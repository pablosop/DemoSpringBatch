package cl.chilecompra.batch.dto;

import java.util.Date;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Table(name = "TIPO_USUARIO")
public class TipoUsuarioDTO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String uroUser;//CODIGO para obtener usuario
    private Integer orgClass;
    
    private String id_usuario;
    private int    id_tipo;
    
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;
}
