package cl.chilecompra.batch.dto;

import java.util.Date;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Table(name = "ROL_UNIDAD_USUARIO")
public class RolUnidadUsuarioDTO {

	private Integer uroRole;
	private Integer uroUser;
	private Integer uroOrganization;
	private Integer uroIsActive;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    
    private String idRol;
    private String idUsuario;
    private String idUnidad;
    private Integer idRolUnidad;
    
    private String creacion;
    private Date creacionFecha;
    private String actualizacion;
    private Date actualizacionFecha;

}
