/*
select ID_USUARIO, count(*) cantidad
  from TELEFONO_USUARIO
 group by ID_USUARIO
 having count(*)>1
*/
--Al parecer existen varios telefonos por usuario, que hacer?

ALTER TABLE TELEFONO_USUARIO
ADD UNIQUE (ID_USUARIO);