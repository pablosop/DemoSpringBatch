--Evaluar, al parecer existen varias combinaciones 
ALTER TABLE ROL_UNIDAD_USUARIO
ADD UNIQUE (ID_ROL_UNIDAD, ID_USUARIO);