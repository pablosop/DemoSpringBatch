
--Evaluar, al parecer varios mail por usuario
ALTER TABLE EMAIL_USUARIO
ADD UNIQUE (ID_USUARIO);