package cl.chilecompra.api.shared.presentation.constants;

public final class Messages {

    public static final String OK                    = "Operacion Exitosa";
    public static final String FORBIDDEN_ERROR       = "No tiene los privilegios necesarios";
    public static final String INTERNAL_SERVER_ERROR = "Error interno no controlado";

    public static final class Usuarios {
        public static final String USUARIO_NOT_FOUND = "Usuario no encontrado";
    }
}
