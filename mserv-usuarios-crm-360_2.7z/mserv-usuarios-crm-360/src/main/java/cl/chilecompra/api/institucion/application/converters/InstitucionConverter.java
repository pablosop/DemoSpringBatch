package cl.chilecompra.api.institucion.application.converters;

import cl.chilecompra.api.institucion.application.DTO.Institucion;
import cl.chilecompra.api.institucion.presentation.controllers.FindAllInstitucionesController;
import cl.chilecompra.api.institucion.presentation.controllers.FindInstitucionByCodigoController;
import cl.chilecompra.api.institucion.presentation.controllers.FindInstitucionByIdController;
import cl.chilecompra.api.shared.application.exceptions.ConversionException;
import cl.chilecompra.api.shared.application.utils.StringUtils;
import cl.chilecompra.api.shared.domain.models.entities.Institution;
import cl.chilecompra.api.shared.domain.models.entities.Unity;
import cl.chilecompra.api.shared.domain.models.entities.UserRoleUnity;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Slf4j
@Component
public class InstitucionConverter {

    @Value("${hateoas.without.port}")
    private boolean WITHOUT_PORT;

    private final UnidadConverter unidadConverter;

    public InstitucionConverter(UnidadConverter unidadConverter) {
        this.unidadConverter = unidadConverter;
    }

    public Institucion convert(Institution institution, Set<UserRoleUnity> userRoleUnities) {
        log.debug(String.format("Convirtiendo objeto %s", institution));

        try {
            return Institucion.builder()
                    .id(institution.getId())
                    .nombre(institution.getInstitution())
                    .codigo(institution.getCode())
                    .creadoEn(institution.getCreatedAt())
                    .creadoPor(institution.getCreatedBy())
                    .actualizadoEn(institution.getUpdatedAt())
                    .actualizadoPor(institution.getUpdatedBy())
                    ._links(createLinks(institution))
                    ._embedded(createEmbeddedsObject(institution, userRoleUnities))
                    .build();
        } catch (Exception e) {
            throw new ConversionException("Error al convertir un institucion", e);
        }
    }

    private Map<String, Object> createEmbeddedsObject(Institution institution, Set<UserRoleUnity> userRoleUnities) {
        Map<String, Object> embeddeds = new LinkedHashMap<>();

        if (userRoleUnities.isEmpty()) {
            //Si userRoleUnities esta vacio se obtienen todas las unidades de la institucion
            embeddeds.put("unidades", institution.getUnities()
                    .stream()
                    .map(u -> unidadConverter.convert(u, Collections.emptySet()))
                    .collect(Collectors.toList()));
        } else {
            //Caso contrario, se obtienen las sucursales a las cuales el usuario esta relacionado
            List<Unity> userUnities = userRoleUnities.stream()
                    .filter(uru -> uru.getRoleUnity().getUnity().getInstitution().equals(institution))
                    .map(uru -> uru.getRoleUnity().getUnity())
                    .collect(Collectors.toList());

            embeddeds.put("unidades", userUnities.stream().map(u -> unidadConverter.convert(u, userRoleUnities)).collect(Collectors.toList()));
        }

        return embeddeds;
    }

    private Map<String, String> createLinks(Institution institution) {
        Link self       = linkTo(methodOn(FindInstitucionByIdController.class).buscarInstitucionPorId(institution.getId().toString())).withSelfRel();
        Link selfCodigo = linkTo(methodOn(FindInstitucionByCodigoController.class).buscarInstitucionPorCodigo(institution.getCode())).withRel("codigo");
        Link get        = linkTo(methodOn(FindAllInstitucionesController.class).obtenerInstituciones(PaginatedRepresentation.DEFAULT_PAGE, PaginatedRepresentation.DEFAULT_SIZE)).withRel("instituciones");

        Map<String, String> links = new LinkedHashMap<>();
        links.put(self.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(self.getHref()) : self.getHref());
        links.put(selfCodigo.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(selfCodigo.getHref()) : selfCodigo.getHref());
        links.put(get.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(get.getHref()) : get.getHref());

        return links;
    }
}
