package cl.chilecompra.api.shared.domain.models.entities;

import cl.chilecompra.api.shared.domain.converters.StatusAttributeConverter;
import cl.chilecompra.api.shared.domain.models.enums.Status;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "ROL_SUCURSAL")
public class RoleBranchOffice implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(columnDefinition = "bigint")
    private BigInteger id;

    @ManyToOne
    @JoinColumn(name = "ID_ROL", nullable = false)
    private Role role;

    @ManyToOne
    @JoinColumn(name = "ID_SUCURSAL", nullable = false)
    private BranchOffice branchOffice;

    @Convert(converter = StatusAttributeConverter.class)
    @Column(name = "ID_ESTADOACTIVO", nullable = false)
    private Status status;

    @Column(name = "CREACION", nullable = false)
    private String createdBy;

    @Column(name = "CREACIONFECHA", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "ACTUALIZACION")
    private String updatedBy;

    @Column(name = "ACTUALIZACIONFECHA")
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "roleBranchOffice")
    private Set<UserRoleBranchOffice> userRoleBranchOffices;

    @Override
    public String toString() {
        return "RoleBranchOffice{" +
                "id=" + id +
                ", role=" + role +
                ", branchOffice=" + branchOffice +
                ", status=" + status +
                ", createdBy='" + createdBy + '\'' +
                ", createdAt=" + createdAt +
                ", updatedBy='" + updatedBy + '\'' +
                ", updatedAt=" + updatedAt +
                '}';
    }

    private static final long serialVersionUID = -7212063658553354761L;
}
