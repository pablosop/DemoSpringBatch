package cl.chilecompra.api.usuario.application.DTO;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.time.LocalDateTime;

@Builder
@Getter
@ToString
@JsonPropertyOrder({"id", "codigo", "nombre", "nivel", "fechaCertificacion", "estado", "estadoAprobacion"})
@ApiModel(description = "Certificación de usuario entity")
public class Certificacion {

    @JsonProperty("id")
    @ApiModelProperty(notes = "Identificador único de la entidad.", position = 1)
    private Integer id;

    @JsonProperty("codigo")
    @ApiModelProperty(notes = "Código de la entidad en el legado.", position = 2)
    private String codigo;

    @JsonProperty("nombre")
    @ApiModelProperty(notes = "Nombre de certificación.", position = 3)
    private String nombre;

    @JsonProperty("nivel")
    @ApiModelProperty(notes = "Nivel de certificación.", position = 4)
    private String nivel;

    @JsonProperty("fechaCertificacion")
    @ApiModelProperty(notes = "Fecha de certificación.", position = 5)
    private LocalDateTime fechaCertificacion;

    @JsonProperty("estado")
    @ApiModelProperty(notes = "Estado de certificación.", position = 6)
    private String estado;

    @JsonProperty("estadoAprobacion")
    @ApiModelProperty(notes = "Estado de aprobación de certificación.", position = 7)
    private String estadoAprobacion;
}
