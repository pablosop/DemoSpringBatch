package cl.chilecompra.api.organismo.presentation.controllers;

import cl.chilecompra.api.organismo.application.DTO.Organismo;
import cl.chilecompra.api.organismo.domain.service.OrganismoServiceInterface;
import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.domain.VO.RutValueObject;
import cl.chilecompra.api.shared.domain.exceptions.DomainException;
import cl.chilecompra.api.shared.presentation.constants.MediaType;
import cl.chilecompra.api.shared.presentation.constants.Routes;
import cl.chilecompra.api.shared.presentation.controllers.AbstractController;
import cl.chilecompra.api.shared.presentation.responses.ErrorResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@Api(tags = {"Organismos"}, description = "Microservicio de organismos CRM 360")
@RestController
@EnableAutoConfiguration
public class FindOrganismoByRutController extends AbstractController {

    private final OrganismoServiceInterface organismoService;

    public FindOrganismoByRutController(OrganismoServiceInterface organismoService) {
        this.organismoService = organismoService;
    }

    @ApiOperation(value = "Obtener organismo por Rut", tags = "Organismos")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = Organismo.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = ErrorResponse.class),
            @ApiResponse(code = 403, message = "Forbidden", response = ErrorResponse.class),
            @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class)
    })
    @GetMapping(value = Routes.OrganismosController.GET_ORGANISM_BY_RUT, produces = MediaType.APPLICATION_HAL_JSON)
    @CrossOrigin(value = "*", methods = RequestMethod.GET)
    public ResponseEntity<?> buscarOrganismoPorRut(@PathVariable String rut) {
        log.info(String.format("Obteniendo informacion del organismo rut: [%s]", rut));

        try {
            return this.createOKResponse(organismoService.findOrganismByRutValueObject(new RutValueObject(rut)));
        } catch (DomainException de) {
            log.info(de.getMessage());
            return this.createBadRequestResponse(de.getMessage());
        } catch (EntityNotFoundException enfe) {
            log.info(enfe.getMessage());
            return this.createNotFoundResponse(enfe.getMessage());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return this.createInternalServerErrorResponse();
        }

    }
}
