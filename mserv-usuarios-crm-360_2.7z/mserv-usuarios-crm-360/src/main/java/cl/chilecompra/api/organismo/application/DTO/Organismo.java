package cl.chilecompra.api.organismo.application.DTO;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@Builder
@Getter
@ToString
@ApiModel(description = "Organismo entity")
@JsonPropertyOrder({"id", "codigo", "rut", "nombre", "acreditado", "habilidad", "vigencia", "creadoEn", "creadoPor", "actualizadoEn", "actualizadoPor", "_links", "_embedded"})
public class Organismo implements Serializable {

    private static final long serialVersionUID = -2691031434130644063L;

    @JsonProperty("id")
    @ApiModelProperty(notes = "Identificador único de la entidad.", position = 1)
    private UUID id;

    @JsonProperty("codigo")
    @ApiModelProperty(notes = "Código de la entidad en el legado.", position = 2)
    private BigInteger codigo;

    @JsonProperty("rut")
    @ApiModelProperty(notes = "Rut del organismo.", position = 3)
    private String rut;

    @JsonProperty("nombre")
    @ApiModelProperty(notes = "Nombre del organismo.", position = 4)
    private String nombre;

    @JsonProperty("acreditado")
    @ApiModelProperty(notes = "Acreditado", position = 5)
    private String acreditado;

    @JsonProperty("habilidad")
    @ApiModelProperty(notes = "Habilidad", position = 6)
    private String habilidad;

    @JsonProperty("vigencia")
    @ApiModelProperty(notes = "Vigencia", position = 7)
    private LocalDate vigencia;

    @JsonProperty("creadoEn")
    @ApiModelProperty(notes = "Fecha creación.", position = 8)
    private LocalDateTime creadoEn;

    @JsonProperty("creadoPor")
    @ApiModelProperty(notes = "Creado por.", position = 9)
    private String creadoPor;

    @JsonProperty("actualizadoEn")
    @ApiModelProperty(notes = "Fecha última actualización", position = 10)
    private LocalDateTime actualizadoEn;

    @JsonProperty("actualizadoPor")
    @ApiModelProperty(notes = "Actualizado por", position = 11)
    private String actualizadoPor;

    @JsonProperty("_links")
    @ApiModelProperty(notes = "Links", position = 12)
    private Map<String, String> _links;

    @JsonProperty("_embedded")
    @ApiModelProperty(notes = "Relaciones incorporadas del organismo.", position = 13)
    private Map<String, Object> _embedded;
}
