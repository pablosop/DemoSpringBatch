package cl.chilecompra.api.shared.domain.models.entities;

import cl.chilecompra.api.shared.domain.converters.CertificationLevelAttributeConverter;
import cl.chilecompra.api.shared.domain.converters.StatusAttributeConverter;
import cl.chilecompra.api.shared.domain.models.enums.CertificationLevel;
import cl.chilecompra.api.shared.domain.models.enums.Status;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "USUARIO_CERTIFICACION")
public class UserCertification implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(columnDefinition = "bigint")
    private BigInteger id;

    @ManyToOne
    @JoinColumn(name = "ID_USUARIO", columnDefinition = "varchar(36)")
    private User user;

    @ManyToOne
    @JoinColumn(name = "ID_CURSOCERTIFICADO")
    private CertifiedCourse certifiedCourse;

    @Convert(converter = CertificationLevelAttributeConverter.class)
    @Column(name = "ID_NIVELCERTIFICADO")
    private CertificationLevel certificationLevel;

    @ManyToOne
    @JoinColumn(name = "ID_ESTADOCERTIFICADO")
    private CertificateStatus certificateStatus;

    @Convert(converter = StatusAttributeConverter.class)
    @Column(name = "ID_ESTADOACTIVO")
    private Status status;

    @Column(name = "CREACION", nullable = false)
    private String createdBy;

    @Column(name = "CREACIONFECHA", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "ACTUALIZACION")
    private String updatedBy;

    @Column(name = "ACTUALIZACIONFECHA")
    private LocalDateTime updatedAt;
}
