package cl.chilecompra.api.organismo.application.services;

import cl.chilecompra.api.organismo.application.DTO.Organismo;
import cl.chilecompra.api.organismo.application.converters.OrganismoConverter;
import cl.chilecompra.api.organismo.domain.service.OrganismoServiceInterface;
import cl.chilecompra.api.organismo.infrastructure.repositories.OrganismJPARepository;
import cl.chilecompra.api.organismo.presentation.controllers.FindAllOrganismosController;
import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.application.services.AbstractServiceImpl;
import cl.chilecompra.api.shared.application.utils.StringUtils;
import cl.chilecompra.api.shared.domain.VO.RutValueObject;
import cl.chilecompra.api.shared.domain.VO.UUIDv4;
import cl.chilecompra.api.shared.domain.models.entities.Organism;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import cl.chilecompra.api.shared.presentation.constants.PaginationSwagger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Slf4j
@Service
public class OrganismoServiceImpl extends AbstractServiceImpl implements OrganismoServiceInterface {

    @Value("${hateoas.without.port}")
    private boolean WITHOUT_PORT;

    private final OrganismJPARepository organismJPARepository;
    private final OrganismoConverter    organismoConverter;

    public OrganismoServiceImpl(
            OrganismJPARepository organismJPARepository,
            OrganismoConverter organismoConverter
    ) {
        this.organismJPARepository = organismJPARepository;
        this.organismoConverter    = organismoConverter;
    }

    @Override
    @Transactional(readOnly = true)
    public PaginatedRepresentation findAllOrganisms(Integer page, Integer size) {
        log.info("Obteniendo listado de organismos");

        try {
            Page<Organism> organismosPaginados = organismJPARepository.findAll(PageRequest.of(page, size));
            Map<String, Object> organismos = new LinkedHashMap<>();
            organismos.put("organismos", organismosPaginados.get().map(o -> organismoConverter.convert(o, Collections.emptySet())).collect(Collectors.toList()));

            return PaginatedRepresentation
                    .builder()
                    .page(organismosPaginados.getNumber())
                    .limit(size)
                    .pages(PaginatedRepresentation.totalPages(organismosPaginados.getTotalPages()))
                    .total(organismosPaginados.getTotalElements())
                    ._links(createLinks(page, size, PaginatedRepresentation.totalPages(organismosPaginados.getTotalPages())))
                    ._embedded(organismos)
                    .build();
        } catch (Exception e) {
            log.error("Error al obtener los organismos", e);
        }

        return PaginatedRepresentation.builder().build();
    }

    protected Map<String, String> createLinks(Integer page, Integer size, Integer lastPage) {
        Link self = linkTo(methodOn(FindAllOrganismosController.class).obtenerOrganismos(page, size)).withSelfRel();
        Link first = linkTo(methodOn(FindAllOrganismosController.class).obtenerOrganismos(0, size)).withRel(PaginationSwagger.FIRST_ELEMENT);
        Link last = linkTo(methodOn(FindAllOrganismosController.class).obtenerOrganismos(lastPage, size)).withRel(PaginationSwagger.LAST_ELEMENT);

        Map<String, String> links = new LinkedHashMap<>();
        links.put(self.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(self.getHref()) : self.getHref());
        links.put(first.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(first.getHref()) : first.getHref());
        links.put(last.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(last.getHref()) : last.getHref());

        return links;
    }

    @Override
    @Transactional(readOnly = true)
    public Organismo findOrganismById(UUIDv4 id) throws EntityNotFoundException {
        Organism organism = organismJPARepository.findById(UUID.fromString(id.getValue()))
                .orElseThrow(() -> new EntityNotFoundException(String.format("No se ha encontrado una organismo con Id: %s", id.getValue())));

        return organismoConverter.convert(organism, Collections.emptySet());
    }

    @Override
    @Transactional(readOnly = true)
    public Organismo findOrganismByCode(BigInteger code) throws EntityNotFoundException {
        Organism organism = organismJPARepository.findByCode(code)
                .orElseThrow(() -> new EntityNotFoundException(String.format("No se ha encontrado un organismo con código: %s", code)));

        return organismoConverter.convert(organism, Collections.emptySet());
    }

    @Override
    @Transactional(readOnly = true)
    public Organismo findOrganismByRutValueObject(RutValueObject rutValueObject) throws EntityNotFoundException {
        Organism organism = organismJPARepository.findByRut(rutValueObject.toStringWithThousandSeparator())
                .orElseThrow(() -> new EntityNotFoundException(String.format("No se ha encontrado un organismo con rut: %s", rutValueObject)));


        return organismoConverter.convert(organism, Collections.emptySet());
    }
}
