package cl.chilecompra.api.usuario.application.DTO;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@Builder
@Getter
@ToString
@JsonPropertyOrder({
        "id",
        "codigo",
        "rut",
        "nombres",
        "apellidos",
        "activo",
        "tipo",
        "segmento",
        "antiguedad",
        "estado",
        "creadoEn",
        "creadoPor",
        "actualizadoEn",
        "actualizadoPor",
        "_links",
        "_embedded"
})
@ApiModel(description = "Usuario entity")
public class Usuario implements Serializable {

    private static final long serialVersionUID = 7023923562212758289L;

    @JsonProperty("id")
    @ApiModelProperty(notes = "Identificador único de la entidad.", position = 1)
    private UUID id;

    @JsonProperty("codigo")
    @ApiModelProperty(notes = "Código de la entidad en el legado.", position = 2)
    private BigInteger codigo;

    @JsonProperty("rut")
    @ApiModelProperty(notes = "Rut del usuario.", position = 3)
    private String rut;

    @JsonProperty("nombres")
    @ApiModelProperty(notes = "Nombres del usuario.", position = 4)
    private String nombres;

    @JsonProperty("apellidos")
    @ApiModelProperty(notes = "Apellidos del usuario.", position = 5)
    private String apellidos;

    @JsonProperty("activo")
    @ApiModelProperty(notes = "Usuario activo.", position = 6)
    private Boolean activo;

    @JsonProperty("tipo")
    @ApiModelProperty(notes = "Tipo de usuario.", position = 7)
    private String tipo;

    @JsonProperty("segmento")
    @ApiModelProperty(notes = "Segmento usuario.", position = 8)
    private String segmento;

    @JsonProperty("antiguedad")
    @ApiModelProperty(notes = "Antiguedad del usuario.", position = 9)
    private LocalDateTime antiguedad;

    @JsonProperty("estado")
    @ApiModelProperty(notes = "Estado de usuario.", position = 10)
    private String estado;

    @JsonProperty("creadoEn")
    @ApiModelProperty(notes = "Fecha creación.", position = 11)
    private LocalDateTime creadoEn;

    @JsonProperty("creadoPor")
    @ApiModelProperty(notes = "Creado por.", position = 12)
    private String creadoPor;

    @JsonProperty("actualizadoEn")
    @ApiModelProperty(notes = "Fecha última actualización", position = 13)
    private LocalDateTime actualizadoEn;

    @JsonProperty("actualizadoPor")
    @ApiModelProperty(notes = "Actualizado por", position = 14)
    private String actualizadoPor;

    @JsonProperty("_links")
    @ApiModelProperty(notes = "Links", position = 15)
    private Map<String, String> _links;

    @JsonProperty("_embedded")
    @ApiModelProperty(notes = "Relaciones incorporadas del usuario.", position = 16)
    private Map<String, Object> _embedded;
}
