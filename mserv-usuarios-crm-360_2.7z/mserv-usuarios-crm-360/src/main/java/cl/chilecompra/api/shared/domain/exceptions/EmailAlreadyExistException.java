package cl.chilecompra.api.shared.domain.exceptions;

public class EmailAlreadyExistException extends RuntimeException {

    private static final long serialVersionUID = -9152120379886838401L;

    public EmailAlreadyExistException(String message) {
        super (message);
    }

    public EmailAlreadyExistException(String message, Throwable cause) {
        super (message, cause);
    }
}
