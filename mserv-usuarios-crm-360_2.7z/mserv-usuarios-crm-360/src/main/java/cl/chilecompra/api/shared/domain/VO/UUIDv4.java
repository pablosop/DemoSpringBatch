package cl.chilecompra.api.shared.domain.VO;

import cl.chilecompra.api.shared.domain.exceptions.DomainException;
import lombok.Getter;
import lombok.ToString;

import java.util.regex.Pattern;

@Getter
@ToString
public class UUIDv4 {

    private static final Pattern UUID_PATTERN = Pattern.compile("[0-9A-Za-z]{8}-[0-9A-Za-z]{4}-4[0-9A-Za-z]{3}-[89ABab][0-9A-Za-z]{3}-[0-9A-Za-z]{12}");
    private final String value;

    public UUIDv4(String value) {
        if (value == null || value.isEmpty()) throw new DomainException("El UUID no deber ser nulo o vacío.");
        if (!UUID_PATTERN.matcher(value).matches())
            throw new DomainException("El valor ingresado no es un UUID válido.");

        this.value = value;
    }
}
