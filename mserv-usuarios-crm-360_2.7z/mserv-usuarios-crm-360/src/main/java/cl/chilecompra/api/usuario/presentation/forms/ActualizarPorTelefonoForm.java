package cl.chilecompra.api.usuario.presentation.forms;

import cl.chilecompra.api.shared.domain.models.entities.UserPhone;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.annotations.ApiModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Getter
@Setter
@ToString
@JsonPropertyOrder({"telefono"})
@ApiModel(description = "Actualizar por telefono form")
public class ActualizarPorTelefonoForm {

    @NotNull(message = "El teléfono no puede ser vacío.")
    @NotBlank
    @Size(max = UserPhone.LENGTH, message = "Teléfono debe poseer un máximo de " + UserPhone.LENGTH + " caracteres.")
    private String telefono;
}
