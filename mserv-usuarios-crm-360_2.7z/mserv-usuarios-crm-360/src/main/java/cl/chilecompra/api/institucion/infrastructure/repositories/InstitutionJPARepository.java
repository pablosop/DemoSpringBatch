package cl.chilecompra.api.institucion.infrastructure.repositories;

import cl.chilecompra.api.shared.domain.models.entities.Institution;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface InstitutionJPARepository extends JpaRepository<Institution, UUID> {

    Optional<Institution> findByCode(BigInteger code);
}
