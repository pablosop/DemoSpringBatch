package cl.chilecompra.api.usuario.application.DTO;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Builder
@Getter
@ToString
@JsonPropertyOrder({"email", "estado"})
@ApiModel(description = "Email de usuario entity")
public class EmailUsuario {

    @JsonProperty("email")
    @ApiModelProperty(notes = "Email de usuario.", position = 1)
    private String  email;

    @JsonProperty("estado")
    @ApiModelProperty(notes = "Estado del email.", position = 2)
    private String estado;
}
