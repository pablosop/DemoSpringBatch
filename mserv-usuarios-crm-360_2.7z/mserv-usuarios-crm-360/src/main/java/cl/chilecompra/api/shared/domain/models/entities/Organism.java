package cl.chilecompra.api.shared.domain.models.entities;

import cl.chilecompra.api.shared.domain.converters.AccreditationStatusAttributeConverter;
import cl.chilecompra.api.shared.domain.models.enums.AccreditationStatus;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "ORGANISMO")
public class Organism implements Serializable {

    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Type(type = "uuid-char")
    @Column(name = "ID_ORGANISMO", columnDefinition = "varchar(36)")
    private UUID id;

    @Column(name = "CODIGO", nullable = false, columnDefinition = "bigint")
    private BigInteger code;

    @Column(name = "RUT", nullable = false, length = 20)
    private String rut;

    @Column(name = "ORGANISMO", nullable = false)
    private String organism;

    @Column(name = "VIGENCIA")
    private LocalDate validity;

    @ManyToOne
    @JoinColumn(name = "ID_ORGANISMOTAMANOSII")
    private OrganismSizeSII organismSizeSII;

    @ManyToOne
    @JoinColumn(name = "ID_ORGANISMOHABILIDAD")
    private OrganismAbility organismAbility;

    @Convert(converter = AccreditationStatusAttributeConverter.class)
    @Column(name = "ID_ESTADOACREDITADO")
    private AccreditationStatus accreditationStatus;

    @Column(name = "CREACION", nullable = false)
    private String createdBy;

    @Column(name = "CREACIONFECHA", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "ACTUALIZACION")
    private String updatedBy;

    @Column(name = "ACTUALIZACIONFECHA")
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "organism", cascade = CascadeType.ALL)
    private Set<UserOrganism> userOrganisms;

    @OneToMany(mappedBy = "organism", cascade = CascadeType.ALL)
    private Set<BranchOffice> branchOffices;

    private static final long serialVersionUID = -1989182250276989524L;

    @Override
    public String toString() {
        return "Organism{" +
                "id=" + id +
                ", code=" + code +
                ", rut='" + rut + '\'' +
                ", organism='" + organism + '\'' +
                ", validity=" + validity +
                ", organismSizeSII=" + organismSizeSII +
                ", organismAbility=" + organismAbility +
                ", accreditationStatus=" + accreditationStatus +
                ", createdBy='" + createdBy + '\'' +
                ", createdAt=" + createdAt +
                ", updatedBy='" + updatedBy + '\'' +
                ", updatedAt=" + updatedAt +
                '}';
    }
}
