package cl.chilecompra.api.shared.domain.converters;

import cl.chilecompra.api.shared.domain.exceptions.EnumConversionException;
import cl.chilecompra.api.shared.domain.models.enums.AccreditationStatus;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class AccreditationStatusAttributeConverter implements AttributeConverter<AccreditationStatus, Integer> {

    @Override
    public Integer convertToDatabaseColumn(AccreditationStatus attribute) {
        return attribute == null ? null : attribute.getCode();
    }

    @Override
    public AccreditationStatus convertToEntityAttribute(Integer value) {
        if (value == null) return null;

        for (AccreditationStatus status : AccreditationStatus.values()) {
            if (status.getCode() == value) {
                return status;
            }
        }

        throw new EnumConversionException(String.format("Valor no permitido: [%s]", value));
    }
}
