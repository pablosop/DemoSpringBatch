package cl.chilecompra.api.usuario.application.command.actualizartelefonoporcodigo;

import cl.chilecompra.api.shared.application.command.CommandHandlerInterface;
import cl.chilecompra.api.shared.domain.models.entities.User;
import cl.chilecompra.api.shared.domain.repository.UniqueTelefonoSpecificationInterface;
import cl.chilecompra.api.usuario.application.DTO.Usuario;
import cl.chilecompra.api.usuario.application.command.shared.AbstractActualizarTelefonoHandler;
import cl.chilecompra.api.usuario.domain.service.UserPhoneServiceInterface;
import cl.chilecompra.api.usuario.domain.service.UsuarioServiceInterface;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public final class ActualizarTelefonoPorCodigoHandler extends AbstractActualizarTelefonoHandler implements CommandHandlerInterface {

    public ActualizarTelefonoPorCodigoHandler(
            UsuarioServiceInterface usuarioService,
            UserPhoneServiceInterface userPhoneService,
            UniqueTelefonoSpecificationInterface uniqueTelefonoSpecification
    ) {
        super(usuarioService, userPhoneService, uniqueTelefonoSpecification);
    }

    public Usuario handler(ActualizarTelefonoPorCodigoCommand command) {
        User user = this.usuarioService.findByCodeToUser(command.codigo());
        this.validarExistenciaYPersistirUsePhone(user, command.telefono());

        return usuarioService.findUserByCode(command.codigo().toBigInteger());
    }
}
