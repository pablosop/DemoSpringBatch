package cl.chilecompra.api.shared.domain.models.entities;

import cl.chilecompra.api.shared.domain.converters.StatusAttributeConverter;
import cl.chilecompra.api.shared.domain.models.enums.Status;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "USUARIO")
public class User implements Serializable {

    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Type(type = "uuid-char")
    @Column(name = "ID_USUARIO", columnDefinition = "varchar(36)")
    private UUID id;

    @Column(name = "CODIGO", nullable = false, columnDefinition = "bigint")
    private BigInteger code;

    @Column(name = "RUT_USUARIO", nullable = false)
    private Integer rut;

    @Column(name = "DV_USUARIO", nullable = false, length = 1, columnDefinition = "varchar(1)")
    private Character dv;

    @Column(name = "NOMBRES_USUARIO")
    private String names;

    @Column(name = "APELLIDOS_USUARIO")
    private String lastnames;

    @Column(name = "ANTIGUEDAD_USUARIO", nullable = false)
    private LocalDateTime antiquity;

    @Convert(converter = StatusAttributeConverter.class)
    @Column(name = "ID_ESTADOACTIVO", nullable = false)
    private Status status;

    @Column(name = "CREACION", nullable = false)
    private String createdBy;

    @Column(name = "CREACIONFECHA", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "ACTUALIZACION")
    private String updatedBy;

    @Column(name = "ACTUALIZACIONFECHA")
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "user")
    private Set<UserEmail> emails;

    @OneToMany(mappedBy = "user")
    private Set<UserPhone> phones;

    @OneToMany(mappedBy = "user")
    private Set<UserRoleUnity> userRoleUnities;

    @OneToMany(mappedBy = "user")
    private Set<UserRoleBranchOffice> userRoleBranchOffices;

    @OneToMany(mappedBy = "user")
    private Set<UserOrganism> userOrganisms;

    @OneToMany(mappedBy = "user")
    private Set<UserInstitution> userInstitutions;

    @OneToMany(mappedBy = "user")
    private Set<UserType> userTypes;

    @OneToMany(mappedBy = "user")
    private Set<UserCertification> userCertifications;

    public String tipo() {
        int    numberInstitutions = this.getUserInstitutions().size();
        int    numberOrganisms   = this.getUserOrganisms().size();
        String tipo              = "";

        if (numberInstitutions > 0) {
            tipo = Tipo.COMPRADOR.getNombre();
        } else if (numberOrganisms > 0) {
            tipo = Tipo.PRVEEDOR.getNombre();
        } else if (numberInstitutions > 0 && numberOrganisms > 0) {
            tipo = Tipo.COMPRADOR_Y_PROVEEDOR.getNombre();
        }

        return tipo;
    }

    private static final long serialVersionUID = -2295770925307624647L;

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", code=" + code +
                ", rut=" + rut +
                ", dv=" + dv +
                ", names='" + names + '\'' +
                ", lastnames='" + lastnames + '\'' +
                ", antiquity=" + antiquity +
                ", status=" + status +
                ", createdBy='" + createdBy + '\'' +
                ", createdAt=" + createdAt +
                ", updatedBy='" + updatedBy + '\'' +
                ", updatedAt=" + updatedAt +
                '}';
    }

    private enum Tipo {
        COMPRADOR("Comprador"),
        PRVEEDOR("Proveedor"),
        COMPRADOR_Y_PROVEEDOR("Comprador y Proveedor");

        private final String nombre;

        Tipo(String nombre) {
            this.nombre = nombre;
        }

        public String getNombre() {
            return nombre;
        }
    }
}

