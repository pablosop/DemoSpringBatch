package cl.chilecompra.api.usuario.presentation.controllers;

import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import cl.chilecompra.api.shared.presentation.constants.MediaType;
import cl.chilecompra.api.shared.presentation.constants.PaginationSwagger;
import cl.chilecompra.api.shared.presentation.constants.Routes;
import cl.chilecompra.api.shared.presentation.controllers.AbstractController;
import cl.chilecompra.api.shared.presentation.responses.ErrorResponse;
import cl.chilecompra.api.usuario.domain.service.UsuarioServiceInterface;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@Api(tags = {"Usuarios"}, description = "Microservicio de usuarios CRM 360")
@RestController()
@EnableAutoConfiguration
public class FindAllUsuariosController extends AbstractController {

    private final UsuarioServiceInterface usuarioService;

    public FindAllUsuariosController(UsuarioServiceInterface usuarioService) {
        this.usuarioService = usuarioService;
    }

    @ApiOperation(value = "Obtener listado paginado de usuarios", tags = "Usuarios")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = PaginatedRepresentation.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = ErrorResponse.class),
            @ApiResponse(code = 403, message = "Forbidden", response = ErrorResponse.class),
            @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class)
    })
    @GetMapping(value = Routes.UsuariosController.GET_ALL_USERS, produces = MediaType.APPLICATION_HAL_JSON)
    @CrossOrigin(value = "*", methods = RequestMethod.GET)
    public ResponseEntity<?> obtenerUsuarios(
            @RequestParam(required = false, defaultValue = PaginationSwagger.DEFAULT_PAGE) Integer page,
            @RequestParam(required = false, defaultValue = PaginationSwagger.DEFAULT_SIZE) Integer size
    ) {
        log.info("Obteniendo usuarios");

        try {
            return this.createOKResponse(usuarioService.findAllUser(page, size));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return this.createInternalServerErrorResponse();
        }
    }
}
