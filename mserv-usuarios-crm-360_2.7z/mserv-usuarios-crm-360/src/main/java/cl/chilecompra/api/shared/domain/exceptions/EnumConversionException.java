package cl.chilecompra.api.shared.domain.exceptions;

public class EnumConversionException extends RuntimeException {

    private static final long serialVersionUID = 7613560162244417222L;

    public EnumConversionException (String message) {
        super (message);
    }

    public EnumConversionException (String message, Throwable cause) {
        super (message, cause);
    }
}
