package cl.chilecompra.api.shared.application.services;

import java.util.Map;

public abstract class AbstractServiceImpl {

    abstract protected Map<String, String> createLinks(Integer page, Integer size, Integer lastPage);

}
