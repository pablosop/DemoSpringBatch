package cl.chilecompra.api.shared.domain.models.entities;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "SUCURSAL")
public class BranchOffice implements Serializable {

    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Type(type = "uuid-char")
    @Column(name = "ID_SUCURSAL", columnDefinition = "varchar(36)")
    private UUID id;

    @Column(name = "CODIGO", nullable = false, columnDefinition = "bigint")
    private BigInteger code;

    @ManyToOne
    @JoinColumn(name = "ID_ORGANISMO", nullable = false)
    private Organism organism;

    @Column(name = "SUCURSAL", nullable = false)
    private String branchOffice;

    @Column(name = "CREACION", nullable = false)
    private String createdBy;

    @Column(name = "CREACIONFECHA", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "ACTUALIZACION")
    private String updatedBy;

    @Column(name = "ACTUALIZACIONFECHA")
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "branchOffice", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Set<RoleBranchOffice> roleBranchOffices;

    @Override
    public String toString() {
        return "BranchOffice{" +
                "id=" + id +
                ", code=" + code +
                ", organism=" + organism +
                ", branchOffice='" + branchOffice + '\'' +
                ", createdBy='" + createdBy + '\'' +
                ", createdAt=" + createdAt +
                ", updatedBy='" + updatedBy + '\'' +
                ", updatedAt=" + updatedAt +
                '}';
    }

    private static final long serialVersionUID = -1881407504491024576L;
}
