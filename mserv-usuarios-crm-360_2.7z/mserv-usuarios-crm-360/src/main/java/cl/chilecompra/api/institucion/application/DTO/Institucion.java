package cl.chilecompra.api.institucion.application.DTO;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@Builder
@Getter
@ToString
@JsonPropertyOrder({"id", "codigo", "nombre", "creadoEn", "creadoPor", "actualizadoEn", "actualizadoPor", "_links", "_embedded"})
@ApiModel(description = "Institución entity")
public class Institucion implements Serializable {

    private static final long serialVersionUID = 5202669402472669561L;

    @JsonProperty("id")
    @ApiModelProperty(notes = "Identificador único de la entidad.", position = 1)
    private UUID id;

    @JsonProperty("codigo")
    @ApiModelProperty(notes = "Código de la entidad en el legado.", position = 2)
    private BigInteger codigo;

    @JsonProperty("nombre")
    @ApiModelProperty(notes = "Nombre de la institución.", position = 3)
    private String nombre;

    @JsonProperty("creadoEn")
    @ApiModelProperty(notes = "Fecha creación.", position = 4)
    private LocalDateTime creadoEn;

    @JsonProperty("creadoPor")
    @ApiModelProperty(notes = "Creado por.", position = 5)
    private String creadoPor;

    @JsonProperty("actualizadoEn")
    @ApiModelProperty(notes = "Fecha última actualización", position = 6)
    private LocalDateTime actualizadoEn;

    @JsonProperty("actualizadoPor")
    @ApiModelProperty(notes = "Actualizado por", position = 7)
    private String actualizadoPor;

    @JsonProperty("_links")
    @ApiModelProperty(notes = "Links", position = 8)
    private Map<String, String> _links;

    @JsonProperty("_embedded")
    @ApiModelProperty(notes = "Relaciones incorporadas de la institución.", position = 9)
    private Map<String, Object> _embedded;
}
