package cl.chilecompra.api.shared.domain.models.enums;

import lombok.Getter;

@Getter
public enum Status {
    INACTIVE(0, "Inactivo", false),
    ACTIVE(1, "Activo", true),
    PENDIENTE_POR_VALIDAR(2, "Pendiente Por Validar", true);

    private final int     code;
    private final String  name;
    private final Boolean value;

    Status(int code, String name, Boolean value) {
        this.code  = code;
        this.name  = name;
        this.value = value;
    }
}
