package cl.chilecompra.api.usuario.application.converters;

import cl.chilecompra.api.institucion.application.converters.InstitucionConverter;
import cl.chilecompra.api.organismo.application.converters.OrganismoConverter;
import cl.chilecompra.api.shared.application.exceptions.ConversionException;
import cl.chilecompra.api.shared.application.utils.StringUtils;
import cl.chilecompra.api.shared.domain.VO.RutValueObject;
import cl.chilecompra.api.shared.domain.models.entities.User;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import cl.chilecompra.api.usuario.application.DTO.Usuario;
import cl.chilecompra.api.usuario.presentation.controllers.FindAllUsuariosController;
import cl.chilecompra.api.usuario.presentation.controllers.FindUsuarioByCodigoController;
import cl.chilecompra.api.usuario.presentation.controllers.FindUsuarioByIdController;
import cl.chilecompra.api.usuario.presentation.controllers.FindUsuarioByRutController;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.convert.converter.Converter;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Component;

import java.text.DecimalFormat;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Slf4j
@Component
public class UsuarioConverter implements Converter<User, Usuario> {

    @Value("${hateoas.without.port}")
    private boolean WITHOUT_PORT;

    private final EmailUsuarioConverter    emailUsuarioConverter;
    private final TelefonoUsuarioConverter telefonoUsuarioConverter;
    private final CertificacionConverter   certificacionConverter;
    private final InstitucionConverter     institucionConverter;
    private final OrganismoConverter       organismoConverter;

    public UsuarioConverter(
            EmailUsuarioConverter emailUsuarioConverter,
            TelefonoUsuarioConverter telefonoUsuarioConverter,
            CertificacionConverter certificacionConverter,
            InstitucionConverter institucionConverter,
            OrganismoConverter organismoConverter
    ) {
        this.emailUsuarioConverter    = emailUsuarioConverter;
        this.telefonoUsuarioConverter = telefonoUsuarioConverter;
        this.certificacionConverter   = certificacionConverter;
        this.institucionConverter     = institucionConverter;
        this.organismoConverter       = organismoConverter;
    }

    @Override
    public Usuario convert(User user) {
        log.debug(String.format("Convirtiendo objeto %s", user.toString()));

        try {
            RutValueObject rut = new RutValueObject(String.format("%s-%s", user.getRut(), user.getDv()));            
            return Usuario.builder()
                    .id(user.getId())
                    .codigo(user.getCode())
                    .rut(rut.toStringWithThousandSeparator())
                    .nombres(user.getNames().trim())
                    .apellidos(user.getLastnames().trim())
                    .activo(user.getStatus().getValue())
                    .estado(user.getStatus().getName())
                    .antiguedad(user.getAntiquity())
                    .tipo(user.tipo())
                    .creadoEn(user.getCreatedAt())
                    .creadoPor(user.getCreatedBy())
                    .actualizadoEn(user.getUpdatedAt())
                    .actualizadoPor(user.getUpdatedBy())
                    ._links(createLinks(user))
                    ._embedded(createEmbeddedsObject(user))
                    .build();
        } catch (Exception e) {
            throw new ConversionException("Error al convertir un usuario", e);
        }
    }

    private Map<String, String> createLinks(User user) {
        Link self       = linkTo(methodOn(FindUsuarioByIdController.class).buscarUsuarioPorId(user.getId().toString())).withSelfRel();
        Link selfCodigo = linkTo(methodOn(FindUsuarioByCodigoController.class).buscarUsuarioPorCodigo(user.getCode())).withRel("codigo");
        Link selfRut    = linkTo(methodOn(FindUsuarioByRutController.class).buscarUsuarioPorRut(String.format("%s-%s", user.getRut(), user.getDv()))).withRel("rut");
        Link get        = linkTo(methodOn(FindAllUsuariosController.class).obtenerUsuarios(PaginatedRepresentation.DEFAULT_PAGE, PaginatedRepresentation.DEFAULT_SIZE)).withRel("usuarios");

        Map<String, String> links = new LinkedHashMap<>();
        links.put(self.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(self.getHref()) : self.getHref());
        links.put(selfCodigo.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(selfCodigo.getHref()) : selfCodigo.getHref());
        links.put(selfRut.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(selfRut.getHref()) : selfRut.getHref());
        links.put(get.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(get.getHref()) : get.getHref());

        return links;
    }

    private Map<String, Object> createEmbeddedsObject(User user) {
        Map<String, Object> embeddeds = new LinkedHashMap<>();
        embeddeds.put("telefonos", user.getPhones().stream().map(telefonoUsuarioConverter::convert).collect(Collectors.toList()));
        embeddeds.put("emails", user.getEmails().stream().map(emailUsuarioConverter::convert).collect(Collectors.toList()));
        embeddeds.put("certificaciones", user.getUserCertifications().stream().map(certificacionConverter::convert).collect(Collectors.toList()));
        embeddeds.put("instituciones", user.getUserInstitutions().stream().map(ui -> institucionConverter.convert(ui.getInstitution(), user.getUserRoleUnities())).collect(Collectors.toList()));
        embeddeds.put("organismos", user.getUserOrganisms().stream().map(uo -> organismoConverter.convert(uo.getOrganism(), user.getUserRoleBranchOffices())).collect(Collectors.toList()));
        return embeddeds;
    }

}
