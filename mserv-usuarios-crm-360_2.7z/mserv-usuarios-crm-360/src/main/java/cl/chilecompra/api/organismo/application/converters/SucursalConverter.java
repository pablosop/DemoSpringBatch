package cl.chilecompra.api.organismo.application.converters;

import cl.chilecompra.api.institucion.application.converters.RolConverter;
import cl.chilecompra.api.organismo.application.DTO.Sucursal;
import cl.chilecompra.api.organismo.presentation.controllers.FindAllSucursalesController;
import cl.chilecompra.api.organismo.presentation.controllers.FindSucursalByCodigoController;
import cl.chilecompra.api.organismo.presentation.controllers.FindSucursalByIdController;
import cl.chilecompra.api.shared.application.exceptions.ConversionException;
import cl.chilecompra.api.shared.application.utils.StringUtils;
import cl.chilecompra.api.shared.domain.models.entities.BranchOffice;
import cl.chilecompra.api.shared.domain.models.entities.UserRoleBranchOffice;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Component;

import java.util.*;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Slf4j
@Component
public class SucursalConverter {

    @Value("${hateoas.without.port}")
    private boolean WITHOUT_PORT;

    private final RolConverter rolConverter;

    public SucursalConverter(RolConverter rolConverter) {
        this.rolConverter = rolConverter;
    }

    public Sucursal convert(BranchOffice branchOffice, Set<UserRoleBranchOffice> userRoleBranchOffices) {
        log.debug(String.format("Convirtiendo objeto %s", branchOffice));

        try {
            return Sucursal.builder()
                    .id(branchOffice.getId())
                    .nombre(branchOffice.getBranchOffice())
                    .codigo(branchOffice.getCode())
                    .creadoEn(branchOffice.getCreatedAt())
                    .creadoPor(branchOffice.getCreatedBy())
                    .actualizadoEn(branchOffice.getUpdatedAt())
                    .actualizadoPor(branchOffice.getUpdatedBy())
                    ._links(createLinks(branchOffice))
                    ._embedded(branchOffice, rolConverter, userRoleBranchOffices)
                    .build();
        } catch (Exception e) {
            throw new ConversionException("Error al convertir una sucursal", e);
        }
    }

    private Map<String, String> createLinks(BranchOffice branchOffice) {
        Link self       = linkTo(methodOn(FindSucursalByIdController.class).buscarSucursalPorId(branchOffice.getId().toString())).withSelfRel();
        Link selfCodigo = linkTo(methodOn(FindSucursalByCodigoController.class).buscarSucursalPorCodigo(branchOffice.getCode())).withRel("codigo");
        Link get        = linkTo(methodOn(FindAllSucursalesController.class).obtenerSucursales(PaginatedRepresentation.DEFAULT_PAGE, PaginatedRepresentation.DEFAULT_SIZE)).withRel("sucursales");

        Map<String, String> links = new LinkedHashMap<>();
        links.put(self.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(self.getHref()) : self.getHref());
        links.put(selfCodigo.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(selfCodigo.getHref()) : selfCodigo.getHref());
        links.put(get.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(get.getHref()) : get.getHref());

        return links;
    }
}
