package cl.chilecompra.api.usuario.application.command.actualizaremailporcodigo;

import cl.chilecompra.api.shared.application.command.CommandInterface;
import cl.chilecompra.api.shared.domain.VO.CodigoValueObject;
import cl.chilecompra.api.shared.domain.VO.EmailValueObject;

import java.math.BigInteger;

public final class ActualizarEmailPorCodigoCommand implements CommandInterface {

    private final CodigoValueObject codigo;
    private final EmailValueObject email;

    public ActualizarEmailPorCodigoCommand(BigInteger codigo, String email) {
        this.codigo = new CodigoValueObject(codigo);
        this.email = new EmailValueObject(email);
    }

    public CodigoValueObject codigo() {
        return codigo;
    }

    public EmailValueObject email() {
        return email;
    }
}
