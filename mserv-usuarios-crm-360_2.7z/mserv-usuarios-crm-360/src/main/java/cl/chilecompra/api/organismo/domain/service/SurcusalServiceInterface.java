package cl.chilecompra.api.organismo.domain.service;

import cl.chilecompra.api.organismo.application.DTO.Sucursal;
import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.domain.VO.UUIDv4;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;

import java.math.BigInteger;

public interface SurcusalServiceInterface {

    PaginatedRepresentation findAllBranchOffices(Integer page, Integer size);

    Sucursal findBranchOfficeById(UUIDv4 id) throws EntityNotFoundException;

    Sucursal findBranchOfficeByCode(BigInteger code) throws EntityNotFoundException;
}
