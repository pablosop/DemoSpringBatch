package cl.chilecompra.api.shared.presentation.DTO;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import org.springframework.hateoas.Link;

import java.time.LocalDateTime;
import java.util.List;

@Getter
public abstract class BaseDTO {

    @JsonProperty("creadoEn")
    @ApiModelProperty(notes = "Fecha creación.", position = 51)
    private LocalDateTime creadoEn;

    @JsonProperty("creadoPor")
    @ApiModelProperty(notes = "Creado por.", position = 52)
    private String creadoPor;

    @JsonProperty("actualizadoEn")
    @ApiModelProperty(notes = "Fecha última actualización", position = 53)
    private LocalDateTime actualizadoEn;

    @JsonProperty("actualizadoPor")
    @ApiModelProperty(notes = "Actualizado por", position = 54)
    private String actualizadoPor;

    @JsonProperty("_links")
    @ApiModelProperty(notes = "Links", position = 55)
    private List<Link> _links;

    public BaseDTO(LocalDateTime creadoEn, String creadoPor, LocalDateTime actualizadoEn, String actualizadoPor, List<Link> _links) {
        this.creadoEn       = creadoEn;
        this.creadoPor      = creadoPor;
        this.actualizadoEn  = actualizadoEn;
        this.actualizadoPor = actualizadoPor;
        this._links         = _links;
    }
}
