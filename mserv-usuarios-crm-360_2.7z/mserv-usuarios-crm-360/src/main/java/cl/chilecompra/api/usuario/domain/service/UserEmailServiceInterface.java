package cl.chilecompra.api.usuario.domain.service;

import cl.chilecompra.api.shared.domain.VO.EmailValueObject;
import cl.chilecompra.api.shared.domain.models.entities.User;
import cl.chilecompra.api.shared.domain.models.entities.UserEmail;

import java.util.List;

public interface UserEmailServiceInterface {

    List<UserEmail> findAllByUserAndEmail(User user, EmailValueObject email);

    void save(UserEmail userEmail);
}
