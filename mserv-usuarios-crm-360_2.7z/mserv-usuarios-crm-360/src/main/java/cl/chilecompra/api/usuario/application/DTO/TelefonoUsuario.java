package cl.chilecompra.api.usuario.application.DTO;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Builder
@Getter
@ToString
@JsonPropertyOrder({"telefono", "estado"})
@ApiModel(description = "Teléfono de usuario entity")
public class TelefonoUsuario {

    @JsonProperty("telefono")
    @ApiModelProperty(notes = "Teléfono de usuario.", position = 1)
    private String telefono;

    @JsonProperty("estado")
    @ApiModelProperty(notes = "Estado del teléfono.", position = 2)
    private String estado;
}
