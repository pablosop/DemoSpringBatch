package cl.chilecompra.api.shared.domain.VO;

import cl.chilecompra.api.shared.domain.exceptions.InvalidEmailException;
import cl.chilecompra.api.shared.domain.models.entities.UserEmail;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class EmailValueObject implements ValueObject {

    public static final Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

    @Size(max = UserEmail.LENGTH, message = "Email debe poseer un máximo de " + UserEmail.LENGTH + " caracteres.")
    private final String email;

    public EmailValueObject(@NotNull String email) {
        if (!isValid(email)) {
            throw new InvalidEmailException(String.format("El email %s, es inválido.", email));
        }

        this.email = email;
    }

    @Override
    public String toString() {
        return email;
    }

    @Override
    public boolean equals(Object otro) {
        if (otro == null || getClass() != otro.getClass()) return false;
        EmailValueObject evo = (EmailValueObject) otro;
        return Objects.equals(email, evo.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(email);
    }

    private boolean isValid(String email) {
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(email);
        return matcher.find();
    }
}
