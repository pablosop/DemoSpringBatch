package cl.chilecompra.api.organismo.application.services;

import cl.chilecompra.api.organismo.application.DTO.Sucursal;
import cl.chilecompra.api.organismo.application.converters.SucursalConverter;
import cl.chilecompra.api.organismo.domain.service.SurcusalServiceInterface;
import cl.chilecompra.api.organismo.infrastructure.repositories.BranchOfficeJPARepository;
import cl.chilecompra.api.organismo.presentation.controllers.FindAllSucursalesController;
import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.application.services.AbstractServiceImpl;
import cl.chilecompra.api.shared.application.utils.StringUtils;
import cl.chilecompra.api.shared.domain.VO.UUIDv4;
import cl.chilecompra.api.shared.domain.models.entities.BranchOffice;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import cl.chilecompra.api.shared.presentation.constants.PaginationSwagger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Slf4j
@Service
public class SucursalServiceImpl extends AbstractServiceImpl implements SurcusalServiceInterface {

    @Value("${hateoas.without.port}")
    private boolean WITHOUT_PORT;

    private final BranchOfficeJPARepository branchOfficeJPARepository;
    private final SucursalConverter sucursalConverter;

    public SucursalServiceImpl(
            BranchOfficeJPARepository branchOfficeJPARepository,
            SucursalConverter sucursalConverter
    ) {
        this.branchOfficeJPARepository = branchOfficeJPARepository;
        this.sucursalConverter = sucursalConverter;
    }

    @Override
    @Transactional(readOnly = true)
    public PaginatedRepresentation findAllBranchOffices(Integer page, Integer size) {
        log.info("Obteniendo listado de sucursales");

        try {
            Page<BranchOffice> sucursalesPaginadas = branchOfficeJPARepository.findAll(PageRequest.of(page, size));
            Map<String, Object> sucursales = new LinkedHashMap<>();
            sucursales.put("sucursales", sucursalesPaginadas.get().map(s -> sucursalConverter.convert(s, Collections.emptySet())).collect(Collectors.toList()));

            return PaginatedRepresentation
                    .builder()
                    .page(sucursalesPaginadas.getNumber())
                    .limit(size)
                    .pages(PaginatedRepresentation.totalPages(sucursalesPaginadas.getTotalPages()))
                    .total(sucursalesPaginadas.getTotalElements())
                    ._links(createLinks(page, size, PaginatedRepresentation.totalPages(sucursalesPaginadas.getTotalPages())))
                    ._embedded(sucursales)
                    .build();
        } catch (Exception e) {
            log.error("Error al obtener las sucursales", e);
        }

        return PaginatedRepresentation.builder().build();
    }

    protected Map<String, String> createLinks(Integer page, Integer size, Integer lastPage) {
        Link self = linkTo(methodOn(FindAllSucursalesController.class).obtenerSucursales(page, size)).withSelfRel();
        Link first = linkTo(methodOn(FindAllSucursalesController.class).obtenerSucursales(0, size)).withRel(PaginationSwagger.FIRST_ELEMENT);
        Link last = linkTo(methodOn(FindAllSucursalesController.class).obtenerSucursales(lastPage, size)).withRel(PaginationSwagger.LAST_ELEMENT);

        Map<String, String> links = new LinkedHashMap<>();
        links.put(self.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(self.getHref()) : self.getHref());
        links.put(first.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(first.getHref()) : first.getHref());
        links.put(last.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(last.getHref()) : last.getHref());

        return links;
    }

    @Override
    @Transactional(readOnly = true)
    public Sucursal findBranchOfficeById(UUIDv4 id) throws EntityNotFoundException {
        BranchOffice branchOffice = branchOfficeJPARepository.findById(UUID.fromString(id.getValue()))
                .orElseThrow(() -> new EntityNotFoundException(String.format("No se ha encontrado una sucursal con Id: %s", id.getValue())));

        return sucursalConverter.convert(branchOffice, Collections.emptySet());
    }

    @Override
    @Transactional(readOnly = true)
    public Sucursal findBranchOfficeByCode(BigInteger code) throws EntityNotFoundException {
        BranchOffice branchOffice = branchOfficeJPARepository.findByCode(code)
                .orElseThrow(() -> new EntityNotFoundException(String.format("No se ha encontrado una sucursal con código: %s", code)));

        return sucursalConverter.convert(branchOffice, Collections.emptySet());
    }
}
