package cl.chilecompra.api.shared.domain.models.enums;

import lombok.Getter;

@Getter
public enum AccreditationStatus {
    SIN_CONTRATO_VIGENTE(0, "Sin Contrato Vigente"),
    CONTRATO_VIGENTE(1, "Contrato Vigente");

    private final int    code;
    private final String name;

    AccreditationStatus(int code, String name) {
        this.code = code;
        this.name = name;
    }
}
