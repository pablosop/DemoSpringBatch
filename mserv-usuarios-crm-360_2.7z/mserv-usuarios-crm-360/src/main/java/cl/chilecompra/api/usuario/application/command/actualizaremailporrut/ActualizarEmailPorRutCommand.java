package cl.chilecompra.api.usuario.application.command.actualizaremailporrut;

import cl.chilecompra.api.shared.application.command.CommandInterface;
import cl.chilecompra.api.shared.domain.VO.EmailValueObject;
import cl.chilecompra.api.shared.domain.VO.RutValueObject;

public final class ActualizarEmailPorRutCommand implements CommandInterface {

    private final RutValueObject rut;
    private final EmailValueObject email;

    public ActualizarEmailPorRutCommand(String rut, String email) {
        this.rut = new RutValueObject(rut);
        this.email = new EmailValueObject(email);
    }

    public RutValueObject rut() {
        return rut;
    }

    public EmailValueObject email() {
        return email;
    }
}
