package cl.chilecompra.api.usuario.presentation.controllers;

import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.domain.exceptions.DomainException;
import cl.chilecompra.api.shared.presentation.constants.MediaType;
import cl.chilecompra.api.shared.presentation.constants.Routes;
import cl.chilecompra.api.shared.presentation.controllers.AbstractController;
import cl.chilecompra.api.shared.presentation.responses.ErrorResponse;
import cl.chilecompra.api.usuario.application.DTO.Usuario;
import cl.chilecompra.api.usuario.domain.service.UsuarioServiceInterface;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;

@Slf4j
@Api(tags = {"Usuarios"}, description = "Microservicio de usuarios CRM 360")
@RestController
@EnableAutoConfiguration
public class FindUsuarioByCodigoController extends AbstractController {

    private final UsuarioServiceInterface usuarioService;

    public FindUsuarioByCodigoController(UsuarioServiceInterface usuarioService) {
        this.usuarioService = usuarioService;
    }

    @ApiOperation(value = "Obtener usuario por codigo", tags = "Usuarios")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = Usuario.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = ErrorResponse.class),
            @ApiResponse(code = 403, message = "Forbidden", response = ErrorResponse.class),
            @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class)
    })
    @GetMapping(value = Routes.UsuariosController.GET_USER_BY_CODE, produces = MediaType.APPLICATION_HAL_JSON)
    @CrossOrigin(value = "*", methods = RequestMethod.GET)
    public ResponseEntity<?> buscarUsuarioPorCodigo(@PathVariable BigInteger codigo) {
        log.info(String.format("Obteniendo informacion del usuario codigo: [%s]", codigo));

        try {
            return this.createOKResponse(usuarioService.findUserByCode(codigo));
        } catch (DomainException de) {
            log.info(de.getMessage());
            return this.createBadRequestResponse(de.getMessage());
        } catch (EntityNotFoundException enfe) {
            log.info(enfe.getMessage());
            return this.createNotFoundResponse(enfe.getMessage());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return this.createInternalServerErrorResponse();
        }

    }
}
