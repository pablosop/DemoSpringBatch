package cl.chilecompra.api.organismo.application.DTO;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Getter;

import java.io.Serializable;

@Builder
@Getter
public class TamanioOrganismo implements Serializable {

    private static final long serialVersionUID = 7403298958255944949L;

    @JsonProperty("id")
    @ApiModelProperty(notes = "Identificador único del tamaño del organismo.", position = 1)
    private Integer id;

    @JsonProperty("tamanioPrincipal")
    @ApiModelProperty(notes = "Tamaño principal del organismo", position = 2)
    private String  tamanioPrincipal;

    @JsonProperty("tamanioSubGrupo")
    @ApiModelProperty(notes = "Subgrupo del tamaño del organismo", position = 3)
    private String  tamanioSubGrupo;

    @JsonProperty("tramoVenta")
    @ApiModelProperty(notes = "Tramo de venta del organismo", position = 4)
    private String  tramoVenta;

    @JsonProperty("Glosa")
    @ApiModelProperty(notes = "Glosa completa SII", position = 5)
    private String glosa;

}
