package cl.chilecompra.api.organismo.presentation.controllers;

import cl.chilecompra.api.organismo.domain.service.OrganismoServiceInterface;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import cl.chilecompra.api.shared.presentation.constants.MediaType;
import cl.chilecompra.api.shared.presentation.constants.PaginationSwagger;
import cl.chilecompra.api.shared.presentation.constants.Routes;
import cl.chilecompra.api.shared.presentation.controllers.AbstractController;
import cl.chilecompra.api.shared.presentation.responses.ErrorResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@Api(tags = {"Organismos"}, description = "Microservicio de organismos CRM 360")
@RestController()
@EnableAutoConfiguration
public class FindAllOrganismosController extends AbstractController {

    private final OrganismoServiceInterface organismoService;

    public FindAllOrganismosController(OrganismoServiceInterface organismoService) {
        this.organismoService = organismoService;
    }

    @ApiOperation(value = "Obtener listado paginado de organismos", tags = "Organismos")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = PaginatedRepresentation.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = ErrorResponse.class),
            @ApiResponse(code = 403, message = "Forbidden", response = ErrorResponse.class),
            @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class)
    })
    @GetMapping(value = Routes.OrganismosController.GET_ALL_ORGANISMS, produces = MediaType.APPLICATION_HAL_JSON)
    @CrossOrigin(value = "*", methods = RequestMethod.GET)
    public ResponseEntity<?> obtenerOrganismos(
            @RequestParam(required = false, defaultValue = PaginationSwagger.DEFAULT_PAGE) Integer page,
            @RequestParam(required = false, defaultValue = PaginationSwagger.DEFAULT_SIZE) Integer size
    ) {
        log.info("Obteniendo organismos");

        try {
            return this.createOKResponse(organismoService.findAllOrganisms(page, size));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return this.createInternalServerErrorResponse();
        }
    }
}
