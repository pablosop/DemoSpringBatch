package cl.chilecompra.api.usuario.application.command.shared;

import cl.chilecompra.api.shared.domain.VO.EmailValueObject;
import cl.chilecompra.api.shared.domain.models.entities.User;
import cl.chilecompra.api.shared.domain.models.entities.UserEmail;
import cl.chilecompra.api.shared.domain.repository.UniqueEmailSpecificationInterface;
import cl.chilecompra.api.usuario.domain.service.UserEmailServiceInterface;
import cl.chilecompra.api.usuario.domain.service.UsuarioServiceInterface;
import org.springframework.stereotype.Service;

@Service
public abstract class AbstractActualizarEmailHandler {

    protected final UsuarioServiceInterface usuarioService;
    protected final UserEmailServiceInterface userEmailService;
    protected final UniqueEmailSpecificationInterface uniqueEmailSpecification;

    public AbstractActualizarEmailHandler(
            UsuarioServiceInterface usuarioService,
            UserEmailServiceInterface userEmailService,
            UniqueEmailSpecificationInterface uniqueEmailSpecification
    ) {
        this.usuarioService = usuarioService;
        this.userEmailService = userEmailService;
        this.uniqueEmailSpecification = uniqueEmailSpecification;
    }

    protected void validarExistenciaYPersistirUserEmail(User user, EmailValueObject email) {
        this.userEmailService.save(
                new UserEmail(user, email, "MSERV CRM 360", this.uniqueEmailSpecification)
        );
    }
}
