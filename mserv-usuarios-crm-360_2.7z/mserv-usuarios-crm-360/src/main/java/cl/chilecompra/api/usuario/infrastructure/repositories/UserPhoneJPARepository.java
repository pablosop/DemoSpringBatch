package cl.chilecompra.api.usuario.infrastructure.repositories;

import cl.chilecompra.api.shared.domain.models.entities.User;
import cl.chilecompra.api.shared.domain.models.entities.UserPhone;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.List;

@Repository
public interface UserPhoneJPARepository extends JpaRepository<UserPhone, BigInteger> {

    List<UserPhone> findAllByUserAndPhone(User user, String phone);
}
