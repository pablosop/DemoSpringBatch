package cl.chilecompra.api.shared.presentation.constants;

public final class Routes {

    private static final String VERSION = "/v1";
    private static final String PREFIJO = "/crm";

    public static class UsuariosController {
        private static final String PREFIJO_USUARIO = "/usuarios";

        public static final String GET_ALL_USERS    = VERSION + PREFIJO + PREFIJO_USUARIO;
        public static final String GET_USER_BY_ID   = VERSION + PREFIJO + PREFIJO_USUARIO + "/{id}";
        public static final String GET_USER_BY_CODE = VERSION + PREFIJO + PREFIJO_USUARIO + "/codigo/{codigo}";
        public static final String GET_USER_BY_RUT  = VERSION + PREFIJO + PREFIJO_USUARIO + "/rut/{rut}";

        public static final String POST_EMAIL_USER_BY_ID = VERSION + PREFIJO + PREFIJO_USUARIO + "/{id}/email";
        public static final String POST_EMAIL_USER_BY_CODE = VERSION + PREFIJO + PREFIJO_USUARIO + "/codigo/{codigo}/email";
        public static final String POST_EMAIL_USER_BY_RUT = VERSION + PREFIJO + PREFIJO_USUARIO + "/rut/{rut}/email";

        public static final String POST_PHONE_USER_BY_ID = VERSION + PREFIJO + PREFIJO_USUARIO + "/{id}/telefono";
        public static final String POST_PHONE_USER_BY_CODE = VERSION + PREFIJO + PREFIJO_USUARIO + "/codigo/{codigo}/telefono";
        public static final String POST_PHONE_USER_BY_RUT = VERSION + PREFIJO + PREFIJO_USUARIO + "/rut/{rut}/telefono";

    }

    public static class InstitucionesController {
        private static final String PREFIJO_INSTITUTION = "/instituciones";

        public static final String GET_ALL_INSTITUTIONS    = VERSION + PREFIJO + PREFIJO_INSTITUTION;
        public static final String GET_INSTITUTION_BY_ID   = VERSION + PREFIJO + PREFIJO_INSTITUTION + "/{id}";
        public static final String GET_INSTITUTION_BY_CODE = VERSION + PREFIJO + PREFIJO_INSTITUTION + "/codigo/{codigo}";
    }

    public static class UnidadesController {
        private static final String PREFIJO_UNITIES = "/unidades";

        public static final String GET_ALL_UNITIES   = VERSION + PREFIJO + PREFIJO_UNITIES;
        public static final String GET_UNITY_BY_ID   = VERSION + PREFIJO + PREFIJO_UNITIES + "/{id}";
        public static final String GET_UNITY_BY_CODE = VERSION + PREFIJO + PREFIJO_UNITIES + "/codigo/{codigo}";
    }

    public static class OrganismosController {
        private static final String PREFIJO_ORGANISMS = "/organismos";

        public static final String GET_ALL_ORGANISMS    = VERSION + PREFIJO + PREFIJO_ORGANISMS;
        public static final String GET_ORGANISM_BY_ID   = VERSION + PREFIJO + PREFIJO_ORGANISMS + "/{id}";
        public static final String GET_ORGANISM_BY_CODE = VERSION + PREFIJO + PREFIJO_ORGANISMS + "/codigo/{codigo}";
        public static final String GET_ORGANISM_BY_RUT = VERSION + PREFIJO + PREFIJO_ORGANISMS + "/rut/{rut}";
    }

    public static class SucursalesController {
        private static final String PREFIJO_BRANCH_OFFICES = "/sucursales";

        public static final String GET_ALL_BRANCH_OFFICES    = VERSION + PREFIJO + PREFIJO_BRANCH_OFFICES;
        public static final String GET_BRANCH_OFFICE_BY_ID   = VERSION + PREFIJO + PREFIJO_BRANCH_OFFICES + "/{id}";
        public static final String GET_BRANCH_OFFICE_BY_CODE = VERSION + PREFIJO + PREFIJO_BRANCH_OFFICES + "/codigo/{codigo}";
    }

    public static class RolesController {
        private static final String PREFIJO_ROLES = "/roles";

        public static final String GET_ALL_ROLES    = VERSION + PREFIJO + PREFIJO_ROLES;
        public static final String GET_ROLE_BY_ID   = VERSION + PREFIJO + PREFIJO_ROLES + "/{id}";
        public static final String GET_ROLE_BY_CODE = VERSION + PREFIJO + PREFIJO_ROLES + "/codigo/{codigo}";
    }
}
