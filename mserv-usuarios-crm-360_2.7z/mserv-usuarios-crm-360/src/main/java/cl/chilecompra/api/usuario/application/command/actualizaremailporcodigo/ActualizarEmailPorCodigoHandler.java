package cl.chilecompra.api.usuario.application.command.actualizaremailporcodigo;

import cl.chilecompra.api.shared.application.command.CommandHandlerInterface;
import cl.chilecompra.api.shared.domain.models.entities.User;
import cl.chilecompra.api.shared.domain.repository.UniqueEmailSpecificationInterface;
import cl.chilecompra.api.usuario.application.DTO.Usuario;
import cl.chilecompra.api.usuario.application.command.shared.AbstractActualizarEmailHandler;
import cl.chilecompra.api.usuario.domain.service.UserEmailServiceInterface;
import cl.chilecompra.api.usuario.domain.service.UsuarioServiceInterface;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public final class ActualizarEmailPorCodigoHandler extends AbstractActualizarEmailHandler implements CommandHandlerInterface {

    public ActualizarEmailPorCodigoHandler(
            UsuarioServiceInterface usuarioService, 
            UserEmailServiceInterface userEmailService,
            UniqueEmailSpecificationInterface uniqueEmailSpecification
    ) {
        super(usuarioService, userEmailService, uniqueEmailSpecification);
    }

    public Usuario handler(ActualizarEmailPorCodigoCommand command) {
        User user = this.usuarioService.findByCodeToUser(command.codigo());
        this.validarExistenciaYPersistirUserEmail(user, command.email());

        return usuarioService.findUserByCode(command.codigo().toBigInteger());
    }    
}
