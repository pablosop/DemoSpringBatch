package cl.chilecompra.api.institucion.presentation.controllers;

import cl.chilecompra.api.institucion.domain.service.UnidadServiceInterface;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import cl.chilecompra.api.shared.presentation.constants.MediaType;
import cl.chilecompra.api.shared.presentation.constants.PaginationSwagger;
import cl.chilecompra.api.shared.presentation.constants.Routes;
import cl.chilecompra.api.shared.presentation.controllers.AbstractController;
import cl.chilecompra.api.shared.presentation.responses.ErrorResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@Api(tags = {"Unidades"}, description = "Microservicio de unidades CRM 360")
@RestController
@EnableAutoConfiguration
public class FindAllUnidadesController extends AbstractController {

    private final UnidadServiceInterface unidadService;

    public FindAllUnidadesController(UnidadServiceInterface unidadService) {
        this.unidadService = unidadService;
    }

    @ApiOperation(value = "Obtener listado paginado de unidades", tags = "Unidades")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = PaginatedRepresentation.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = ErrorResponse.class),
            @ApiResponse(code = 403, message = "Forbidden", response = ErrorResponse.class),
            @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class)
    })
    @GetMapping(value = Routes.UnidadesController.GET_ALL_UNITIES, produces = MediaType.APPLICATION_HAL_JSON)
    @CrossOrigin(value = "*", methods = RequestMethod.GET)
    public ResponseEntity<?> obtenerUnidades(
            @RequestParam(required = false, defaultValue = PaginationSwagger.DEFAULT_PAGE) Integer page,
            @RequestParam(required = false, defaultValue = PaginationSwagger.DEFAULT_SIZE) Integer size) {
        log.info("Obteniendo unidades");

        try {
            return this.createOKResponse(unidadService.findAllUnities(page, size));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return this.createInternalServerErrorResponse();
        }
    }
}
