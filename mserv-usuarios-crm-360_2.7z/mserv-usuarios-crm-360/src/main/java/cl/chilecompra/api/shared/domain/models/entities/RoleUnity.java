package cl.chilecompra.api.shared.domain.models.entities;

import cl.chilecompra.api.shared.domain.converters.StatusAttributeConverter;
import cl.chilecompra.api.shared.domain.models.enums.Status;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "ROL_UNIDAD")
public class RoleUnity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(columnDefinition = "bigint")
    private BigInteger id;

    @ManyToOne
    @JoinColumn(name = "ID_ROL", nullable = false)
    private Role role;

    @ManyToOne
    @JoinColumn(name = "ID_UNIDAD", nullable = false)
    private Unity unity;

    @Convert(converter = StatusAttributeConverter.class)
    @Column(name = "ID_ESTADOACTIVO", nullable = false)
    private Status status;

    @Column(name = "CREACION", nullable = false)
    private String createdBy;

    @Column(name = "CREACIONFECHA", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "ACTUALIZACION")
    private String updatedBy;

    @Column(name = "ACTUALIZACIONFECHA")
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "roleUnity")
    private Set<UserRoleUnity> userRoleUnities;

    @Override
    public String toString() {
        return "RoleUnity{" +
                "id=" + id +
                ", role=" + role +
                ", unity=" + unity +
                ", status=" + status +
                ", createdBy='" + createdBy + '\'' +
                ", createdAt=" + createdAt +
                ", updatedBy='" + updatedBy + '\'' +
                ", updatedAt=" + updatedAt +
                '}';
    }

    private static final long serialVersionUID = 5650063257989919868L;
}
