package cl.chilecompra.api.institucion.domain.service;

import cl.chilecompra.api.institucion.application.DTO.Unidad;
import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.domain.VO.UUIDv4;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;

import java.math.BigInteger;

public interface UnidadServiceInterface {

    PaginatedRepresentation findAllUnities(Integer page, Integer size);

    Unidad findUnidadById(UUIDv4 id) throws EntityNotFoundException;

    Unidad findUnidadByCode(BigInteger code) throws EntityNotFoundException;
}
