package cl.chilecompra.api.usuario.infrastructure.repositories;

import cl.chilecompra.api.shared.domain.models.entities.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface UserJPARepository extends JpaRepository<User, UUID> {

    Page<User> findAll(Pageable pageable);

    Optional<User> findByCode(BigInteger code);

    Optional<User> findByRutAndDv(Integer rut, Character dv);
}
