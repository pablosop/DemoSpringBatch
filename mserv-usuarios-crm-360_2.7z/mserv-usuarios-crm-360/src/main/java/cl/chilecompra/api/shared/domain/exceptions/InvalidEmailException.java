package cl.chilecompra.api.shared.domain.exceptions;

public class InvalidEmailException extends RuntimeException {

    private static final long serialVersionUID = -3003903130717313551L;

    public InvalidEmailException (String message) {
        super (message);
    }

    public InvalidEmailException (String message, Throwable cause) {
        super (message, cause);
    }
}
