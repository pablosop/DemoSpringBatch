package cl.chilecompra.api.usuario.infrastructure.repositories;

import cl.chilecompra.api.shared.domain.VO.TelefonoValueObject;
import cl.chilecompra.api.shared.domain.models.entities.User;
import cl.chilecompra.api.shared.domain.models.entities.UserPhone;
import cl.chilecompra.api.shared.domain.repository.UniqueTelefonoSpecificationInterface;
import cl.chilecompra.api.usuario.domain.service.UserPhoneServiceInterface;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public final class UniqueTelefonoSpecificationJPAImpl implements UniqueTelefonoSpecificationInterface {

    private final UserPhoneServiceInterface userPhoneService;

    public UniqueTelefonoSpecificationJPAImpl(UserPhoneServiceInterface userPhoneService) {
        this.userPhoneService = userPhoneService;
    }

    @Override
    public boolean isSatisfiedBy(User user, TelefonoValueObject telefono) {
        List<UserPhone> userPhones = this.userPhoneService.findAllByUserAndPhone(user, telefono);
        return (userPhones.size() >= 1);
    }
}
