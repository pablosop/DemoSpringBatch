package cl.chilecompra.api.usuario.domain.service;

import cl.chilecompra.api.shared.domain.VO.TelefonoValueObject;
import cl.chilecompra.api.shared.domain.models.entities.User;
import cl.chilecompra.api.shared.domain.models.entities.UserPhone;

import java.util.List;

public interface UserPhoneServiceInterface {

    List<UserPhone> findAllByUserAndPhone(User user, TelefonoValueObject telefono);

    void save(UserPhone userPhone);
}
