package cl.chilecompra.api.shared.domain.models.entities;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "CURSOCERTIFICADO")
public class CertifiedCourse implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_CURSOCERTIFICADO")
    private Integer id;

    @Column(name = "CURSOCERTIFICADO", nullable = false)
    private String certifiedCourse;

    @Column(name = "CURSOCORTOCERTIFICADO", nullable = false)
    private String shortCertifiedCourse;

    @Column(name = "FECHACERTIFICADO", nullable = false)
    private LocalDateTime certifiedDate;

    @OneToMany(mappedBy = "certifiedCourse")
    private Set<UserCertification> userCertifications;

    @Override
    public String toString() {
        return "CertifiedCourse{" +
                "id=" + id +
                ", certifiedCourse='" + certifiedCourse + '\'' +
                ", shortCertifiedCourse='" + shortCertifiedCourse + '\'' +
                ", certifiedDate=" + certifiedDate +
                '}';
    }

    private static final long serialVersionUID = -5825135707336448106L;
}
