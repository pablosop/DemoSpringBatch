package cl.chilecompra.api.usuario.application.converters;

import cl.chilecompra.api.usuario.application.DTO.Certificacion;
import cl.chilecompra.api.shared.domain.models.entities.UserCertification;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class CertificacionConverter implements Converter<UserCertification, Certificacion> {

    @Override
    public Certificacion convert(UserCertification certification) {
        try {
            return Certificacion.builder()
                    .id(certification.getCertifiedCourse().getId())
                    .codigo(certification.getCertifiedCourse().getShortCertifiedCourse())
                    .nombre(certification.getCertifiedCourse().getCertifiedCourse())
                    .nivel(certification.getCertificationLevel().getName())
                    .fechaCertificacion(certification.getCertifiedCourse().getCertifiedDate())
                    .estado(certification.getStatus().getName())
                    .estadoAprobacion(certification.getCertificateStatus().getCertificateStatus())
                    .build();
        } catch (Exception e) {
            log.warn(String.format("Error al convertir el certificacion: %s", certification));
        }

        return null;
    }
}
