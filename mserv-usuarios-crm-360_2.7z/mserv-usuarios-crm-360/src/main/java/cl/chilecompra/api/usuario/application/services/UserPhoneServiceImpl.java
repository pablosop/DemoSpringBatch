package cl.chilecompra.api.usuario.application.services;

import cl.chilecompra.api.shared.domain.VO.TelefonoValueObject;
import cl.chilecompra.api.shared.domain.models.entities.User;
import cl.chilecompra.api.shared.domain.models.entities.UserPhone;
import cl.chilecompra.api.usuario.domain.service.UserPhoneServiceInterface;
import cl.chilecompra.api.usuario.infrastructure.repositories.UserPhoneJPARepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
public class UserPhoneServiceImpl implements UserPhoneServiceInterface {

    private final UserPhoneJPARepository userPhoneRepository;

    public UserPhoneServiceImpl(UserPhoneJPARepository userPhoneRepository) {
        this.userPhoneRepository = userPhoneRepository;
    }

    @Transactional(readOnly = true)
    public List<UserPhone> findAllByUserAndPhone(User user, TelefonoValueObject telefono) {
        return this.userPhoneRepository.findAllByUserAndPhone(user, telefono.toString());
    }

    @Override
    public void save(UserPhone userPhone) {
        this.userPhoneRepository.saveAndFlush(userPhone);
    }
}
