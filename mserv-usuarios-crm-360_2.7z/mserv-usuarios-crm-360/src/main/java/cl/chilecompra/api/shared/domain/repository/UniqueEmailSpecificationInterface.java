package cl.chilecompra.api.shared.domain.repository;

import cl.chilecompra.api.shared.domain.VO.EmailValueObject;
import cl.chilecompra.api.shared.domain.models.entities.User;

public interface UniqueEmailSpecificationInterface {

    public boolean isSatisfiedBy(User user, EmailValueObject email);

}
