package cl.chilecompra.api.shared.domain.models.enums;

import lombok.Getter;

@Getter
public enum CertificationLevel {
    NO_CERTIFICADO(1, "No Certificado"),
    BASICO(2, "Basico"),
    INTERMEDIO(3, "Intermedio"),
    AVANZADO(4, "Avanzado"),
    EXPERTO(5, "Experto");

    private final int    code;
    private final String name;

    CertificationLevel(int code, String name) {
        this.code = code;
        this.name = name;
    }
}
