package cl.chilecompra.api.institucion.application.services;

import cl.chilecompra.api.institucion.application.DTO.Institucion;
import cl.chilecompra.api.institucion.application.converters.InstitucionConverter;
import cl.chilecompra.api.institucion.domain.service.InstitucionServiceInterface;
import cl.chilecompra.api.institucion.infrastructure.repositories.InstitutionJPARepository;
import cl.chilecompra.api.institucion.presentation.controllers.FindAllInstitucionesController;
import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.application.services.AbstractServiceImpl;
import cl.chilecompra.api.shared.application.utils.StringUtils;
import cl.chilecompra.api.shared.domain.VO.UUIDv4;
import cl.chilecompra.api.shared.domain.models.entities.Institution;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import cl.chilecompra.api.shared.presentation.constants.PaginationSwagger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Slf4j
@Service
public class InstitucionServiceImpl extends AbstractServiceImpl implements InstitucionServiceInterface {

    @Value("${hateoas.without.port}")
    private boolean WITHOUT_PORT;

    private final InstitutionJPARepository institutionJPARepository;
    private final InstitucionConverter     institucionConverter;

    public InstitucionServiceImpl(InstitutionJPARepository institutionJPARepository, InstitucionConverter institucionConverter) {
        this.institutionJPARepository = institutionJPARepository;
        this.institucionConverter     = institucionConverter;
    }

    @Override
    @Transactional(readOnly = true)
    public PaginatedRepresentation findAllInstitutions(Integer page, Integer size) {
        log.info("Obteniendo listado de instituciones");

        try {
            Page<Institution>   institutionPage = institutionJPARepository.findAll(PageRequest.of(page, size));
            Map<String, Object> instituciones   = new HashMap<>();
            instituciones.put("instituciones", institutionPage.get().map(i -> institucionConverter.convert(i, Collections.emptySet())).collect(Collectors.toList()));

            return PaginatedRepresentation
                    .builder()
                    .page(institutionPage.getNumber())
                    .limit(size)
                    .pages(PaginatedRepresentation.totalPages(institutionPage.getTotalPages()))
                    .total(institutionPage.getTotalElements())
                    ._links(createLinks(page, size, PaginatedRepresentation.totalPages(institutionPage.getTotalPages())))
                    ._embedded(instituciones)
                    .build();
        } catch (Exception e) {
            log.error("Error al obtener las instituciones", e);
        }

        return PaginatedRepresentation.builder().build();
    }

    protected Map<String, String> createLinks(Integer page, Integer size, Integer lastPage) {
        Link self  = linkTo(methodOn(FindAllInstitucionesController.class).obtenerInstituciones(page, size)).withSelfRel();
        Link first = linkTo(methodOn(FindAllInstitucionesController.class).obtenerInstituciones(PaginatedRepresentation.DEFAULT_PAGE, size)).withRel(PaginationSwagger.FIRST_ELEMENT);
        Link last  = linkTo(methodOn(FindAllInstitucionesController.class).obtenerInstituciones(lastPage, size)).withRel(PaginationSwagger.LAST_ELEMENT);

        Map<String, String> links = new LinkedHashMap<>();
        links.put(self.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(self.getHref()) : self.getHref());
        links.put(first.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(first.getHref()) : first.getHref());
        links.put(last.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(last.getHref()) : last.getHref());

        return links;
    }

    @Override
    @Transactional(readOnly = true)
    public Institucion findInstitutionById(UUIDv4 id) throws EntityNotFoundException {
        Institution institution = institutionJPARepository.findById(UUID.fromString(id.getValue()))
                .orElseThrow(() -> new EntityNotFoundException(String.format("No se ha encontrado una institucion con Id: %s", id.getValue())));

        return institucionConverter.convert(institution, Collections.emptySet());
    }

    @Override
    @Transactional(readOnly = true)
    public Institucion findInstitutionByCode(BigInteger code) throws EntityNotFoundException {
        Institution institution = institutionJPARepository.findByCode(code)
                .orElseThrow(() -> new EntityNotFoundException(String.format("No se ha encontrado una institucion con código: %s", code)));

        return institucionConverter.convert(institution, Collections.emptySet());
    }
}
