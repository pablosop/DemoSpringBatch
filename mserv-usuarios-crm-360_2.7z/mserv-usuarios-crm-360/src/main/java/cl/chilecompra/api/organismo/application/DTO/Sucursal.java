package cl.chilecompra.api.organismo.application.DTO;

import cl.chilecompra.api.institucion.application.converters.RolConverter;
import cl.chilecompra.api.shared.domain.models.entities.BranchOffice;
import cl.chilecompra.api.shared.domain.models.entities.UserRoleBranchOffice;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.ToString;

import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

@Getter
@ToString
@ApiModel(description = "Sucursal entity")
@JsonPropertyOrder({"id", "codigo", "nombre", "creadoEn", "creadoPor", "actualizadoEn", "actualizadoPor", "_links", "_embedded"})
public class Sucursal implements Serializable {

    private static final long serialVersionUID = 5375098943879175801L;

    @JsonProperty("id")
    @ApiModelProperty(notes = "Identificador único de la entidad.", position = 1)
    private UUID id;

    @JsonProperty("codigo")
    @ApiModelProperty(notes = "Código de la entidad en el legado.", position = 2)
    private BigInteger codigo;

    @JsonProperty("nombre")
    @ApiModelProperty(notes = "Nombre de la sucursal.", position = 3)
    private String nombre;

    @JsonProperty("creadoEn")
    @ApiModelProperty(notes = "Fecha creación.", position = 4)
    private LocalDateTime creadoEn;

    @JsonProperty("creadoPor")
    @ApiModelProperty(notes = "Creado por.", position = 5)
    private String creadoPor;

    @JsonProperty("actualizadoEn")
    @ApiModelProperty(notes = "Fecha última actualización", position = 6)
    private LocalDateTime actualizadoEn;

    @JsonProperty("actualizadoPor")
    @ApiModelProperty(notes = "Actualizado por", position = 7)
    private String actualizadoPor;

    @JsonProperty("_links")
    @ApiModelProperty(notes = "Links", position = 8)
    private Map<String, String> _links;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("_embedded")
    @ApiModelProperty(notes = "Relaciones incorporadas de la sucursal.", position = 9)
    private Map<String, Object> _embedded;

    private Sucursal(
            UUID id,
            BigInteger codigo,
            String nombre,
            LocalDateTime creadoEn,
            String creadoPor,
            LocalDateTime actualizadoEn,
            String actualizadoPor,
            Map<String, String> _links,
            Map<String, Object> _embedded) {
        this.id             = id;
        this.codigo         = codigo;
        this.nombre         = nombre;
        this.creadoEn       = creadoEn;
        this.creadoPor      = creadoPor;
        this.actualizadoEn  = actualizadoEn;
        this.actualizadoPor = actualizadoPor;
        this._links         = _links;
        this._embedded      = _embedded;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private UUID                id;
        private BigInteger          codigo;
        private String              nombre;
        private LocalDateTime       creadoEn;
        private String              creadoPor;
        private LocalDateTime       actualizadoEn;
        private String              actualizadoPor;
        private Map<String, String> _links;
        private Map<String, Object> _embedded;

        public Builder id(UUID id) {
            this.id = id;
            return this;
        }

        public Builder codigo(BigInteger codigo) {
            this.codigo = codigo;
            return this;
        }

        public Builder nombre(String nombre) {
            this.nombre = nombre;
            return this;
        }

        public Builder creadoEn(LocalDateTime creadoEn) {
            this.creadoEn = creadoEn;
            return this;
        }

        public Builder creadoPor(String creadoPor) {
            this.creadoPor = creadoPor;
            return this;
        }

        public Builder actualizadoEn(LocalDateTime actualizadoEn) {
            this.actualizadoEn = actualizadoEn;
            return this;
        }

        public Builder actualizadoPor(String actualizadoPor) {
            this.actualizadoPor = actualizadoPor;
            return this;
        }

        public Builder _links(Map<String, String> _links) {
            this._links = _links;
            return this;
        }

        public Builder _embedded(BranchOffice branchOffice, RolConverter rolConverter, Set<UserRoleBranchOffice> userRoleBranchOffices) {
            if (userRoleBranchOffices.isEmpty()) {
                this._embedded = null;
            } else {
                _embedded = new HashMap<>();
                _embedded.put("roles", userRoleBranchOffices.stream()
                        .filter(urb -> urb.getRoleBranchOffice().getBranchOffice().equals(branchOffice))
                        .map(urb -> rolConverter.convert(urb.getRoleBranchOffice().getRole())));
            }

            return this;
        }

        public Sucursal build() {
            return new Sucursal(id, codigo, nombre, creadoEn, creadoPor, actualizadoEn, actualizadoPor, _links, _embedded);
        }

    }

}
