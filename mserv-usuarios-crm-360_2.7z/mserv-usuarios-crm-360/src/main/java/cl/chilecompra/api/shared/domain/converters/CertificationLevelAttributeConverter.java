package cl.chilecompra.api.shared.domain.converters;

import cl.chilecompra.api.shared.domain.exceptions.EnumConversionException;
import cl.chilecompra.api.shared.domain.models.enums.CertificationLevel;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class CertificationLevelAttributeConverter implements AttributeConverter<CertificationLevel, Integer> {

    @Override
    public Integer convertToDatabaseColumn(CertificationLevel level) {
        return level == null ? null : level.getCode();
    }

    @Override
    public CertificationLevel convertToEntityAttribute(Integer code) {
        for (CertificationLevel level : CertificationLevel.values()) {
            if (level.getCode() == code) {
                return level;
            }
        }

        throw new EnumConversionException(String.format("Valor no permitido: [%s]", code));
    }
}
