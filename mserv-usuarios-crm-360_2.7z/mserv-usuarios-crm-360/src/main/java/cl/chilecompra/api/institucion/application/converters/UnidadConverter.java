package cl.chilecompra.api.institucion.application.converters;

import cl.chilecompra.api.institucion.application.DTO.Unidad;
import cl.chilecompra.api.institucion.presentation.controllers.FindAllUnidadesController;
import cl.chilecompra.api.institucion.presentation.controllers.FindUnidadByCodigoController;
import cl.chilecompra.api.institucion.presentation.controllers.FindUnidadByIdController;
import cl.chilecompra.api.shared.application.exceptions.ConversionException;
import cl.chilecompra.api.shared.application.utils.StringUtils;
import cl.chilecompra.api.shared.domain.models.entities.Unity;
import cl.chilecompra.api.shared.domain.models.entities.UserRoleUnity;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Component;

import java.util.*;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Slf4j
@Component
public class UnidadConverter {

    @Value("${hateoas.without.port}")
    private boolean WITHOUT_PORT;

    private final RolConverter rolConverter;

    public UnidadConverter(RolConverter rolConverter) {
        this.rolConverter = rolConverter;
    }

    public Unidad convert(Unity unity, Set<UserRoleUnity> userRoleUnities) {
        log.debug(String.format("Convirtiendo objeto %s", unity.toString()));

        try {
            return Unidad.builder()
                    .id(unity.getId())
                    .nombre(unity.getUnity())
                    .codigo(unity.getCode())
                    .creadoEn(unity.getCreatedAt())
                    .creadoPor(unity.getCreatedBy())
                    .actualizadoEn(unity.getUpdatedAt())
                    .actualizadoPor(unity.getUpdatedBy())
                    ._links(createLinks(unity))
                    ._embedded(unity, rolConverter, userRoleUnities)
                    .build();
        } catch (Exception e) {
            throw new ConversionException("Error al convertir una unidad", e);
        }
    }

    private Map<String, String> createLinks(Unity unity) {
        Link self       = linkTo(methodOn(FindUnidadByIdController.class).buscarUnidadPorId(unity.getId().toString())).withSelfRel();
        Link selfCodigo = linkTo(methodOn(FindUnidadByCodigoController.class).buscarUnidadPorCodigo(unity.getCode())).withRel("codigo");
        Link get        = linkTo(methodOn(FindAllUnidadesController.class).obtenerUnidades(PaginatedRepresentation.DEFAULT_PAGE, PaginatedRepresentation.DEFAULT_SIZE)).withRel("unidades");

        Map<String, String> links = new LinkedHashMap<>();
        links.put(self.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(self.getHref()) : self.getHref());
        links.put(selfCodigo.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(selfCodigo.getHref()) : selfCodigo.getHref());
        links.put(get.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(get.getHref()) : get.getHref());

        return links;
    }

}
