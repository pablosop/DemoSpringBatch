package cl.chilecompra.api.shared.domain.VO;

import cl.chilecompra.api.shared.domain.exceptions.DomainException;

import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RutValueObject {

    private static final String PATTERN        = "^[0-9]+-[0-9kK]$";
    private static final String FORMAT_DECIMAL = "###,###.##";
    private static final String POINT          = ".";
    private static final String COMMA          = ",";

    private final Integer rut;
    private final String  digitoVerficador;

    public RutValueObject(String value) {
        if (value == null || value.isEmpty()) {
            throw new DomainException("El Rut no puede ser vacío.");
        }

        value = value.replace(".", "");

        if (!this.validaRut(value)) {
            throw new DomainException(String.format("El Rut %s tiene formato inválido", value));
        }

        String[] exploded = value.split("-");

        this.rut              = Integer.parseInt(exploded[0]);
        this.digitoVerficador = exploded[1].toLowerCase();
    }

    public Integer rut() {
        return rut;
    }

    public String digitoVerficador() {
        return digitoVerficador;
    }

    @Override
    public String toString() {
        DecimalFormat decimalFormat = new DecimalFormat(RutValueObject.FORMAT_DECIMAL);
        return String.format("%s-%s", decimalFormat.format(rut), digitoVerficador);
    }

    public String toStringWithThousandSeparator() {
        return toString().replace(COMMA, POINT);
    }

    private Boolean validaRut(String rut) {
        Pattern pattern = Pattern.compile(RutValueObject.PATTERN);
        Matcher matcher = pattern.matcher(rut);
        if (!matcher.matches()) return false;
        String[] exploded = rut.split("-");
        return exploded[1].toLowerCase().equals(this.digitoVerificador(exploded[0]));
    }

    private String digitoVerificador(String rut) {
        int M = 0, S = 1, T = Integer.parseInt(rut);
        for (; T != 0; T = (int) Math.floor(T / 10))
             S = (S + T % 10 * (9 - M++ % 6)) % 11;
        return (S > 0) ? String.valueOf(S - 1) : "k";
    }
}
