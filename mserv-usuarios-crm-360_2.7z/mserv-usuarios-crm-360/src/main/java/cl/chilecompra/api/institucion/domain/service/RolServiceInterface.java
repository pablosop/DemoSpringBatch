package cl.chilecompra.api.institucion.domain.service;

import cl.chilecompra.api.institucion.application.DTO.Rol;
import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.domain.VO.UUIDv4;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;

import java.math.BigInteger;

public interface RolServiceInterface {

    PaginatedRepresentation findAllRoles(Integer page, Integer size);

    Rol findRoleById(UUIDv4 id) throws EntityNotFoundException;

    Rol findRoleByCode(BigInteger code) throws EntityNotFoundException;
}
