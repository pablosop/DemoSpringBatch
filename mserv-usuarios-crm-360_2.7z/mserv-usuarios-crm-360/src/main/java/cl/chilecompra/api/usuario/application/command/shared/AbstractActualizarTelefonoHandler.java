package cl.chilecompra.api.usuario.application.command.shared;

import cl.chilecompra.api.shared.domain.VO.TelefonoValueObject;
import cl.chilecompra.api.shared.domain.models.entities.User;
import cl.chilecompra.api.shared.domain.models.entities.UserPhone;
import cl.chilecompra.api.shared.domain.repository.UniqueTelefonoSpecificationInterface;
import cl.chilecompra.api.usuario.domain.service.UserPhoneServiceInterface;
import cl.chilecompra.api.usuario.domain.service.UsuarioServiceInterface;
import org.springframework.stereotype.Service;

@Service
public abstract class AbstractActualizarTelefonoHandler {

    protected final UsuarioServiceInterface usuarioService;
    protected final UserPhoneServiceInterface userPhoneService;
    protected final UniqueTelefonoSpecificationInterface uniqueTelefonoSpecification;

    public AbstractActualizarTelefonoHandler(
            UsuarioServiceInterface usuarioService,
            UserPhoneServiceInterface userPhoneService,
            UniqueTelefonoSpecificationInterface uniqueTelefonoSpecification
    ) {
        this.usuarioService = usuarioService;
        this.userPhoneService = userPhoneService;
        this.uniqueTelefonoSpecification = uniqueTelefonoSpecification;
    }

    protected void validarExistenciaYPersistirUsePhone(User user, TelefonoValueObject telefono) {
        this.userPhoneService.save(
                new UserPhone(user, telefono, "MSERV CRM 360", this.uniqueTelefonoSpecification)
        );
    }
}
