package cl.chilecompra.api.organismo.infrastructure.repositories;

import cl.chilecompra.api.shared.domain.models.entities.BranchOffice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface BranchOfficeJPARepository extends JpaRepository<BranchOffice, UUID> {

    Optional<BranchOffice> findByCode(BigInteger code);
}
