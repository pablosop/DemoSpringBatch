package cl.chilecompra.api.organismo.application.converters;

import cl.chilecompra.api.organismo.application.DTO.Organismo;
import cl.chilecompra.api.organismo.application.DTO.TamanioOrganismo;
import cl.chilecompra.api.organismo.presentation.controllers.FindAllOrganismosController;
import cl.chilecompra.api.organismo.presentation.controllers.FindOrganismoByCodigoController;
import cl.chilecompra.api.organismo.presentation.controllers.FindOrganismoByIdController;
import cl.chilecompra.api.organismo.presentation.controllers.FindOrganismoByRutController;
import cl.chilecompra.api.shared.application.exceptions.ConversionException;
import cl.chilecompra.api.shared.application.utils.StringUtils;
import cl.chilecompra.api.shared.domain.models.entities.BranchOffice;
import cl.chilecompra.api.shared.domain.models.entities.Organism;
import cl.chilecompra.api.shared.domain.models.entities.OrganismSizeSII;
import cl.chilecompra.api.shared.domain.models.entities.UserRoleBranchOffice;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Slf4j
@Component
public class OrganismoConverter {

    @Value("${hateoas.without.port}")
    private boolean WITHOUT_PORT;

    private final SucursalConverter sucursalConverter;

    public OrganismoConverter(SucursalConverter sucursalConverter) {
        this.sucursalConverter = sucursalConverter;
    }

    public Organismo convert(Organism organism, Set<UserRoleBranchOffice> userRoleBranchOffices) {
        log.debug(String.format("Convirtiendo objeto %s", organism));

        try {
            return Organismo.builder()
                    .id(organism.getId())
                    .nombre(organism.getOrganism())
                    .codigo(organism.getCode())
                    .rut(organism.getRut())
                    .acreditado(organism.getAccreditationStatus() == null ? null : organism.getAccreditationStatus().getName())
                    .habilidad(organism.getOrganismAbility() == null ? null : organism.getOrganismAbility().getOrganismAbility())
                    .vigencia(organism.getValidity())
                    .creadoEn(organism.getCreatedAt())
                    .creadoPor(organism.getCreatedBy())
                    .actualizadoEn(organism.getUpdatedAt())
                    .actualizadoPor(organism.getUpdatedBy())
                    ._links(createLinks(organism))
                    ._embedded(createEmbeddedsObject(organism, userRoleBranchOffices))
                    .build();
        } catch (Exception e) {
            throw new ConversionException("Error al convertir un organismo", e);
        }
    }

    private Map<String, String> createLinks(Organism organism) {
        Link self       = linkTo(methodOn(FindOrganismoByIdController.class).buscarOrganismoPorId(organism.getId().toString())).withSelfRel();
        Link selfCodigo = linkTo(methodOn(FindOrganismoByCodigoController.class).buscarOrganismoPorCodigo(organism.getCode())).withRel("codigo");
        Link selfRut    = linkTo(methodOn(FindOrganismoByRutController.class).buscarOrganismoPorRut(String.format("%s", organism.getRut()))).withRel("rut");
        Link get        = linkTo(methodOn(FindAllOrganismosController.class).obtenerOrganismos(PaginatedRepresentation.DEFAULT_PAGE, PaginatedRepresentation.DEFAULT_SIZE)).withRel("organismos");

        Map<String, String> links = new LinkedHashMap<>();
        links.put(self.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(self.getHref()) : self.getHref());
        links.put(selfCodigo.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(selfCodigo.getHref()) : selfCodigo.getHref());
        links.put(selfRut.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(selfRut.getHref()) : selfRut.getHref());
        links.put(get.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(get.getHref()) : get.getHref());

        return links;
    }

    private Map<String, Object> createEmbeddedsObject(Organism organism, Set<UserRoleBranchOffice> userRoleBranchOffices) {
        Map<String, Object> embeddeds = new LinkedHashMap<>();
        embeddeds.put("tamanio", organism.getOrganismSizeSII() == null ? null : createTamanioOrganismo(organism.getOrganismSizeSII()));

        if (userRoleBranchOffices.isEmpty()) {
            //Si userRoleBranchOffices esta vacio, se obtienen todas las sucursales del organismo
            embeddeds.put("sucursales", organism.getBranchOffices()
                    .stream()
                    .map(bo -> sucursalConverter.convert(bo, Collections.emptySet()))
                    .collect(Collectors.toList()));
        } else {
            //Caso contrario, se obtienen solo las sucursales relacionadas con el usuario
            List<BranchOffice> branchOffices = userRoleBranchOffices.stream()
                    .filter(urb -> urb.getRoleBranchOffice().getBranchOffice().getOrganism().equals(organism))
                    .map(urb -> urb.getRoleBranchOffice().getBranchOffice())
                    .collect(Collectors.toList());

            embeddeds.put("sucursales", branchOffices
                    .stream()
                    .map(s -> sucursalConverter.convert(s, userRoleBranchOffices))
                    .collect(Collectors.toList()));
        }

        return embeddeds;
    }

    private TamanioOrganismo createTamanioOrganismo(OrganismSizeSII organismSizeSII) {
        return TamanioOrganismo.builder()
                .id(organismSizeSII.getId())
                .tamanioPrincipal(organismSizeSII.getPrincipalSize())
                .tamanioSubGrupo(organismSizeSII.getSubGrpSize())
                .tramoVenta(organismSizeSII.getSaleLeg())
                .glosa(organismSizeSII.getCompleteGlossSII())
                .build();
    }
}
