package cl.chilecompra.api.organismo.domain.service;

import cl.chilecompra.api.organismo.application.DTO.Organismo;
import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.domain.VO.RutValueObject;
import cl.chilecompra.api.shared.domain.VO.UUIDv4;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;

import java.math.BigInteger;

public interface OrganismoServiceInterface {

    PaginatedRepresentation findAllOrganisms(Integer page, Integer size);

    Organismo findOrganismById(UUIDv4 id) throws EntityNotFoundException;

    Organismo findOrganismByCode(BigInteger code) throws EntityNotFoundException;

    Organismo findOrganismByRutValueObject(RutValueObject rutValueObject) throws EntityNotFoundException;
}
