package cl.chilecompra.api.shared.domain.VO;

import javax.validation.constraints.NotNull;
import java.util.Objects;

public final class TelefonoValueObject implements ValueObject {

    private final String telefono;

    public TelefonoValueObject(@NotNull String telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return telefono;
    }

    @Override
    public boolean equals(Object otro) {
        if (otro == null || getClass() != otro.getClass()) return false;
        TelefonoValueObject tvo = (TelefonoValueObject) otro;
        return Objects.equals(telefono, tvo.telefono);
    }

    @Override
    public int hashCode() {
        return Objects.hash(telefono);
    }
}
