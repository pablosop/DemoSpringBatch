package cl.chilecompra.api.shared.domain.models.entities;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@Getter
@Setter
@Entity
@Table(name = "UNIDAD")
public class Unity implements Serializable {

    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Type(type = "uuid-char")
    @Column(name = "ID_UNIDAD", columnDefinition = "varchar(36)")
    private UUID id;

    @Column(name = "CODIGO", nullable = false, columnDefinition = "bigint")
    private BigInteger code;

    @ManyToOne
    @JoinColumn(name = "ID_INSTITUCION", nullable = false)
    private Institution institution;

    @Column(name = "UNIDAD", nullable = false)
    private String unity;

    @Column(name = "CREACION", nullable = false)
    private String createdBy;

    @Column(name = "CREACIONFECHA", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "ACTUALIZACION")
    private String updatedBy;

    @Column(name = "ACTUALIZACIONFECHA")
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "unity", cascade = CascadeType.ALL)
    private Set<RoleUnity> roleUnities;

    @Override
    public String toString() {
        return "Unity{" +
                "id=" + id +
                ", code=" + code +
                ", institution=" + institution +
                ", unity='" + unity + '\'' +
                ", createdBy='" + createdBy + '\'' +
                ", createdAt=" + createdAt +
                ", updatedBy='" + updatedBy + '\'' +
                ", updatedAt=" + updatedAt +
                '}';
    }

    private static final long serialVersionUID = -7591010764406572703L;
}
