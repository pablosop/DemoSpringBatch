package cl.chilecompra.api.usuario.infrastructure.repositories;

import cl.chilecompra.api.shared.domain.VO.EmailValueObject;
import cl.chilecompra.api.shared.domain.models.entities.User;
import cl.chilecompra.api.shared.domain.models.entities.UserEmail;
import cl.chilecompra.api.shared.domain.repository.UniqueEmailSpecificationInterface;
import cl.chilecompra.api.usuario.domain.service.UserEmailServiceInterface;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public final class UniqueEmailSpecificationJPAImpl implements UniqueEmailSpecificationInterface {

    private final UserEmailServiceInterface userEmailService;

    public UniqueEmailSpecificationJPAImpl(UserEmailServiceInterface userEmailService) {
        this.userEmailService = userEmailService;
    }

    @Override
    public boolean isSatisfiedBy(User user, EmailValueObject email) {
        List<UserEmail> userEmails = this.userEmailService.findAllByUserAndEmail(user, email);
        return (userEmails.size() >= 1);
    }
}
