package cl.chilecompra.api.shared.domain.converters;

import cl.chilecompra.api.shared.domain.exceptions.EnumConversionException;
import cl.chilecompra.api.shared.domain.models.enums.Status;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class StatusAttributeConverter implements AttributeConverter<Status, Integer> {

    @Override
    public Integer convertToDatabaseColumn (Status status) {
        return status.getCode ();
    }

    @Override
    public Status convertToEntityAttribute (Integer integer) {
        for (Status value : Status.values ()) {
            if(value.getCode () == integer) return value;
        }

        throw new EnumConversionException (String.format ("Valor no permitido: [%s]", integer));
    }
}
