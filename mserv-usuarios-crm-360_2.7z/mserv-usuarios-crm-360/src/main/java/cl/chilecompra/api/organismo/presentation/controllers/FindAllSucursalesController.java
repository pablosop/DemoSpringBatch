package cl.chilecompra.api.organismo.presentation.controllers;

import cl.chilecompra.api.organismo.domain.service.SurcusalServiceInterface;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import cl.chilecompra.api.shared.presentation.constants.MediaType;
import cl.chilecompra.api.shared.presentation.constants.PaginationSwagger;
import cl.chilecompra.api.shared.presentation.constants.Routes;
import cl.chilecompra.api.shared.presentation.controllers.AbstractController;
import cl.chilecompra.api.shared.presentation.responses.ErrorResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@Api(tags = {"Sucursales"}, description = "Microservicio de sucursales CRM 360")
@RestController()
@EnableAutoConfiguration
public class FindAllSucursalesController extends AbstractController {

    private final SurcusalServiceInterface sucursalService;

    public FindAllSucursalesController(SurcusalServiceInterface sucursalService) {
        this.sucursalService = sucursalService;
    }

    @ApiOperation(value = "Obtener listado paginado de sucursales", tags = "Sucursales")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = PaginatedRepresentation.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = ErrorResponse.class),
            @ApiResponse(code = 403, message = "Forbidden", response = ErrorResponse.class),
            @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class)
    })
    @GetMapping(value = Routes.SucursalesController.GET_ALL_BRANCH_OFFICES, produces = MediaType.APPLICATION_HAL_JSON)
    @CrossOrigin(value = "*", methods = RequestMethod.GET)
    public ResponseEntity<?> obtenerSucursales(
            @RequestParam(required = false, defaultValue = PaginationSwagger.DEFAULT_PAGE) Integer page,
            @RequestParam(required = false, defaultValue = PaginationSwagger.DEFAULT_SIZE) Integer size
    ) {
        log.info("Obteniendo sucursales");

        try {
            return this.createOKResponse(sucursalService.findAllBranchOffices(page, size));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return this.createInternalServerErrorResponse();
        }
    }
}
