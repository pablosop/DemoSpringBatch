package cl.chilecompra.api.shared.domain.models.entities;

import cl.chilecompra.api.shared.domain.converters.StatusAttributeConverter;
import cl.chilecompra.api.shared.domain.models.enums.Status;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "ROL_SUCURSAL_USUARIO")
public class UserRoleBranchOffice implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(columnDefinition = "bigint")
    private BigInteger id;

    @ManyToOne
    @JoinColumn(name = "ID_ROL_SUCURSAL", nullable = false)
    private RoleBranchOffice roleBranchOffice;

    @ManyToOne
    @JoinColumn(name = "ID_USUARIO", columnDefinition = "varchar(36)", nullable = false)
    private User user;

    @Column(name = "ID_ESTADOACTIVO", nullable = false)
    @Convert(converter = StatusAttributeConverter.class)
    private Status status;

    @Column(name = "CREACION", nullable = false)
    private String createdBy;

    @Column(name = "CREACIONFECHA", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "ACTUALIZACION")
    private String updatedBy;

    @Column(name = "ACTUALIZACIONFECHA")
    private LocalDateTime updatedAt;
}
