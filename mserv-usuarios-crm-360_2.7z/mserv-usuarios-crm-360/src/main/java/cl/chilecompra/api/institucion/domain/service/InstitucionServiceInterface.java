package cl.chilecompra.api.institucion.domain.service;

import cl.chilecompra.api.institucion.application.DTO.Institucion;
import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.domain.VO.UUIDv4;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;

import java.math.BigInteger;

public interface InstitucionServiceInterface {

    PaginatedRepresentation findAllInstitutions(Integer page, Integer size);

    Institucion findInstitutionById(UUIDv4 id) throws EntityNotFoundException;

    Institucion findInstitutionByCode(BigInteger code) throws EntityNotFoundException;
}
