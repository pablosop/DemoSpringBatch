package cl.chilecompra.api.usuario.application.converters;

import cl.chilecompra.api.usuario.application.DTO.EmailUsuario;
import cl.chilecompra.api.shared.domain.models.entities.UserEmail;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class EmailUsuarioConverter implements Converter<UserEmail, EmailUsuario> {

    @Override
    public EmailUsuario convert(UserEmail email) {
        try {
            return EmailUsuario.builder()
                    .email(email.getEmail())
                    .estado(email.getStatus().getName())
                    .build();
        } catch (Exception e) {
            log.warn(String.format("Error al convertir el Email: %s", email));
        }

        return null;
    }
}
