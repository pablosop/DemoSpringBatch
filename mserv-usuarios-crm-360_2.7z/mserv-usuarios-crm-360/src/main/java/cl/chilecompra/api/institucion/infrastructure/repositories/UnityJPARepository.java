package cl.chilecompra.api.institucion.infrastructure.repositories;

import cl.chilecompra.api.shared.domain.models.entities.Unity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface UnityJPARepository extends JpaRepository<Unity, UUID> {

    Optional<Unity> findByCode(BigInteger code);
}
