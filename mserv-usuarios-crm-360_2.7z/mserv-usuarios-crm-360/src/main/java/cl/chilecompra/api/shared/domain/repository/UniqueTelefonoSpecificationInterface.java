package cl.chilecompra.api.shared.domain.repository;

import cl.chilecompra.api.shared.domain.VO.TelefonoValueObject;
import cl.chilecompra.api.shared.domain.models.entities.User;

public interface UniqueTelefonoSpecificationInterface {

    public boolean isSatisfiedBy(User user, TelefonoValueObject telefono);
}
