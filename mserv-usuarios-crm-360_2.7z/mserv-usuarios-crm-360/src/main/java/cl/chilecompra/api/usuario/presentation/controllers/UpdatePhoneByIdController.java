package cl.chilecompra.api.usuario.presentation.controllers;

import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.domain.exceptions.DomainException;
import cl.chilecompra.api.shared.domain.exceptions.TelefonoAlreadyExistException;
import cl.chilecompra.api.shared.presentation.constants.MediaType;
import cl.chilecompra.api.shared.presentation.constants.Routes;
import cl.chilecompra.api.shared.presentation.controllers.AbstractController;
import cl.chilecompra.api.shared.presentation.responses.ErrorResponse;
import cl.chilecompra.api.usuario.application.DTO.Usuario;
import cl.chilecompra.api.usuario.application.command.actualizartelefonoporid.ActualizarTelefonoPorIdCommand;
import cl.chilecompra.api.usuario.application.command.actualizartelefonoporid.ActualizarTelefonoPorIdHandler;
import cl.chilecompra.api.usuario.presentation.forms.ActualizarPorTelefonoForm;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Slf4j
@Api(tags = {"Usuarios"}, description = "Microservicio de usuarios CRM 360")
@RestController
@EnableAutoConfiguration
public class UpdatePhoneByIdController extends AbstractController {

    private final ActualizarTelefonoPorIdHandler commandHandler;

    public UpdatePhoneByIdController(ActualizarTelefonoPorIdHandler commandHandler) {
        this.commandHandler = commandHandler;
    }

    @ApiOperation(value = "Actualizar teléfono de usuario por id", tags = "Usuarios")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = Usuario.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = ErrorResponse.class),
            @ApiResponse(code = 400, message = "Bad Request", response = ErrorResponse.class),
            @ApiResponse(code = 403, message = "Forbidden", response = ErrorResponse.class),
            @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class)
    })
    @PostMapping(value = Routes.UsuariosController.POST_PHONE_USER_BY_ID, produces = MediaType.APPLICATION_HAL_JSON)
    @CrossOrigin(value = "*", methods = RequestMethod.POST)
    public ResponseEntity<?> actualizarTelefonoUsuarioPorId(
            @PathVariable String id,
            @Valid @RequestBody ActualizarPorTelefonoForm form
    ) {
        log.info(String.format("Obteniendo informacion del usuario por id: [%s]", id));

        try {
            return this.createOKResponse(this.commandHandler.handler(
                    new ActualizarTelefonoPorIdCommand(id, form.getTelefono())
            ));
        } catch (DomainException | TelefonoAlreadyExistException de) {
            log.info(de.getMessage());
            return this.createBadRequestResponse(de.getMessage());
        } catch (EntityNotFoundException enfe) {
            log.info(enfe.getMessage());
            return this.createNotFoundResponse(enfe.getMessage());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return this.createInternalServerErrorResponse();
        }
    }
}
