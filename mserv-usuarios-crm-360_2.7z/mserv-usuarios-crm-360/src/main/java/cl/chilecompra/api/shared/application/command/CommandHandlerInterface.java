package cl.chilecompra.api.shared.application.command;

public interface CommandHandlerInterface {
}
