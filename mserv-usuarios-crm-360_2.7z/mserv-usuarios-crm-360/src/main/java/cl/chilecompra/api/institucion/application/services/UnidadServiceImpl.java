package cl.chilecompra.api.institucion.application.services;

import cl.chilecompra.api.institucion.application.DTO.Unidad;
import cl.chilecompra.api.institucion.application.converters.UnidadConverter;
import cl.chilecompra.api.institucion.domain.service.UnidadServiceInterface;
import cl.chilecompra.api.institucion.infrastructure.repositories.UnityJPARepository;
import cl.chilecompra.api.institucion.presentation.controllers.FindAllUnidadesController;
import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.application.services.AbstractServiceImpl;
import cl.chilecompra.api.shared.application.utils.StringUtils;
import cl.chilecompra.api.shared.domain.VO.UUIDv4;
import cl.chilecompra.api.shared.domain.models.entities.Unity;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import cl.chilecompra.api.shared.presentation.constants.PaginationSwagger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Slf4j
@Service
public class UnidadServiceImpl extends AbstractServiceImpl implements UnidadServiceInterface {

    @Value("${hateoas.without.port}")
    private boolean WITHOUT_PORT;

    private final UnityJPARepository unityJPARepository;
    private final UnidadConverter    unidadConverter;

    public UnidadServiceImpl(UnityJPARepository unityJPARepository, UnidadConverter unidadConverter) {
        this.unityJPARepository = unityJPARepository;
        this.unidadConverter    = unidadConverter;
    }

    @Override
    @Transactional(readOnly = true)
    public PaginatedRepresentation findAllUnities(Integer page, Integer size) {
        log.info("Obteniendo listado de unidades");

        try {
            Page<Unity>         unityPage = unityJPARepository.findAll(PageRequest.of(page, size));
            Map<String, Object> unidades  = new HashMap<>();
            unidades.put("unidades", unityPage.get().map(u -> unidadConverter.convert(u, Collections.emptySet())).collect(Collectors.toList()));

            return PaginatedRepresentation
                    .builder()
                    .page(unityPage.getNumber())
                    .limit(size)
                    .pages(PaginatedRepresentation.totalPages(unityPage.getTotalPages()))
                    .total(unityPage.getTotalElements())
                    ._links(createLinks(page, size, PaginatedRepresentation.totalPages(unityPage.getTotalPages())))
                    ._embedded(unidades)
                    .build();
        } catch (Exception e) {
            log.error("Error al obtener las unidades", e);
        }

        return PaginatedRepresentation.builder().build();
    }

    protected Map<String, String> createLinks(Integer page, Integer size, Integer lastPage) {
        Link self  = linkTo(methodOn(FindAllUnidadesController.class).obtenerUnidades(page, size)).withSelfRel();
        Link first = linkTo(methodOn(FindAllUnidadesController.class).obtenerUnidades(PaginatedRepresentation.DEFAULT_PAGE, size)).withRel(PaginationSwagger.FIRST_ELEMENT);
        Link last  = linkTo(methodOn(FindAllUnidadesController.class).obtenerUnidades(lastPage, size)).withRel(PaginationSwagger.LAST_ELEMENT);

        Map<String, String> links = new LinkedHashMap<>();
        links.put(self.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(self.getHref()) : self.getHref());
        links.put(first.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(first.getHref()) : first.getHref());
        links.put(last.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(last.getHref()) : last.getHref());

        return links;
    }

    @Override
    @Transactional(readOnly = true)
    public Unidad findUnidadById(UUIDv4 id) throws EntityNotFoundException {
        Unity unity = unityJPARepository.findById(UUID.fromString(id.getValue()))
                .orElseThrow(() -> new EntityNotFoundException(String.format("No se ha encontrado una unidad con Id: %s", id.getValue())));

        return unidadConverter.convert(unity, Collections.emptySet());
    }

    @Override
    @Transactional(readOnly = true)
    public Unidad findUnidadByCode(BigInteger code) throws EntityNotFoundException {
        Unity unity = unityJPARepository.findByCode(code)
                .orElseThrow(() -> new EntityNotFoundException(String.format("No se ha encontrado una unidad con código: %s", code)));

        return unidadConverter.convert(unity, Collections.emptySet());
    }
}
