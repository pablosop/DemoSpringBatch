package cl.chilecompra.api.shared.domain.models.entities;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "ESTADOCERTIFICADO")
public class CertificateStatus implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_ESTADOCERTIFICADO")
    private Integer id;

    @Column(name = "ESTADOCERTIFICADO", length = 50)
    private String certificateStatus;

    @Column(name = "CREACION", nullable = false)
    private String createdBy;

    @Column(name = "CREACIONFECHA", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "ACTUALIZACION")
    private String updatedBy;

    @Column(name = "ACTUALIZACIONFECHA")
    private LocalDateTime updatedAt;

    private static final long serialVersionUID = 7279689837040832651L;
}
