package cl.chilecompra.api.usuario.domain.service;

import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.domain.VO.CodigoValueObject;
import cl.chilecompra.api.shared.domain.VO.RutValueObject;
import cl.chilecompra.api.shared.domain.VO.UUIDv4;
import cl.chilecompra.api.shared.domain.models.entities.User;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import cl.chilecompra.api.usuario.application.DTO.Usuario;

import java.math.BigInteger;

public interface UsuarioServiceInterface {

    PaginatedRepresentation findAllUser(Integer page, Integer size);

    Usuario findById(UUIDv4 id) throws EntityNotFoundException;

    Usuario findUserByCode(BigInteger code) throws EntityNotFoundException;

    Usuario findUserByRutValueObject(RutValueObject rutValueObject) throws EntityNotFoundException;

    User findByCodeToUser(CodigoValueObject codigo) throws EntityNotFoundException;
    
    User findByIdToUser(UUIDv4 id) throws EntityNotFoundException;

    User findUserByRutValueObjectToUser(RutValueObject rutValueObject) throws EntityNotFoundException;
}
