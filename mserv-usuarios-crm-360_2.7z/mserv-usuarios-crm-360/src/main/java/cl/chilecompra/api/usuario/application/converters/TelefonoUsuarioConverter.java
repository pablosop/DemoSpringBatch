package cl.chilecompra.api.usuario.application.converters;

import cl.chilecompra.api.usuario.application.DTO.TelefonoUsuario;
import cl.chilecompra.api.shared.domain.models.entities.UserPhone;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class TelefonoUsuarioConverter implements Converter<UserPhone, TelefonoUsuario> {

    @Override
    public TelefonoUsuario convert(UserPhone phone) {
        try {
            return TelefonoUsuario.builder()
                    .telefono(phone.getPhone())
                    .estado(phone.getStatus().getName())
                    .build();
        } catch (Exception e) {
            log.warn(String.format("Error al convertir el Telefono: %s", phone));
        }

        return null;
    }
}
