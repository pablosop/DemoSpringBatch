package cl.chilecompra.api.shared.domain.exceptions;

public class DomainException extends RuntimeException {

    private static final long serialVersionUID = 9051027752788791492L;

    public DomainException (String message) {
        super (message);
    }

    public DomainException (String message, Throwable cause) {
        super (message, cause);
    }
}
