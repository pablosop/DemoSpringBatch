package cl.chilecompra.api.usuario.infrastructure.repositories;

import cl.chilecompra.api.shared.domain.models.entities.User;
import cl.chilecompra.api.shared.domain.models.entities.UserEmail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.List;

@Repository
public interface UserEmailJPARepository extends JpaRepository<UserEmail, BigInteger> {

    List<UserEmail> findAllByUserAndEmail(User user, String email);
}
