package cl.chilecompra.api.institucion.infrastructure.repositories;

import cl.chilecompra.api.shared.domain.models.entities.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface RoleJPARepository extends JpaRepository<Role, UUID> {

    Optional<Role> findByCode(BigInteger code);
}
