package cl.chilecompra.api.shared.domain.VO;

import java.util.Objects;

public interface ValueObject {

    public boolean equals(Object otro);

    public int hashCode();
}
