package cl.chilecompra.api.shared.presentation.constants;

public class PaginationSwagger {
    public static final String DEFAULT_PAGE = "0";
    public static final String DEFAULT_SIZE = "10";

    public static final String FIRST_ELEMENT = "first";
    public static final String LAST_ELEMENT  = "last";
}
