package cl.chilecompra.api.usuario.application.services;

import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.application.services.AbstractServiceImpl;
import cl.chilecompra.api.shared.application.utils.StringUtils;
import cl.chilecompra.api.shared.domain.VO.CodigoValueObject;
import cl.chilecompra.api.shared.domain.VO.RutValueObject;
import cl.chilecompra.api.shared.domain.VO.UUIDv4;
import cl.chilecompra.api.shared.domain.models.entities.User;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import cl.chilecompra.api.shared.presentation.constants.PaginationSwagger;
import cl.chilecompra.api.usuario.application.DTO.Usuario;
import cl.chilecompra.api.usuario.application.converters.UsuarioConverter;
import cl.chilecompra.api.usuario.domain.service.UsuarioServiceInterface;
import cl.chilecompra.api.usuario.infrastructure.repositories.UserJPARepository;
import cl.chilecompra.api.usuario.presentation.controllers.FindAllUsuariosController;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Slf4j
@Service
public class UsuarioServiceImpl extends AbstractServiceImpl implements UsuarioServiceInterface {

    @Value("${hateoas.without.port}")
    private boolean WITHOUT_PORT;

    private final UserJPARepository usuarioJPARepository;
    private final UsuarioConverter  usuarioConverter;

    public UsuarioServiceImpl(
            UserJPARepository usuarioJPARepository,
            UsuarioConverter usuarioConverter
    ) {
        this.usuarioJPARepository = usuarioJPARepository;
        this.usuarioConverter     = usuarioConverter;
    }

    @Override
    @Transactional(readOnly = true)
    public PaginatedRepresentation findAllUser(Integer page, Integer size) {
        log.info("Obteniendo listado de usuarios");

        try {
            Page<User>          usuariosPaginados = usuarioJPARepository.findAll(PageRequest.of(page, size));
            Map<String, Object> usuarios          = new LinkedHashMap<>();
            usuarios.put("usuarios", usuariosPaginados.get().map(usuarioConverter::convert).collect(Collectors.toList()));

            return PaginatedRepresentation
                    .builder()
                    .page(usuariosPaginados.getNumber())
                    .limit(size)
                    .pages(PaginatedRepresentation.totalPages(usuariosPaginados.getTotalPages()))
                    .total(usuariosPaginados.getTotalElements())
                    ._links(createLinks(page, size, PaginatedRepresentation.totalPages(usuariosPaginados.getTotalPages())))
                    ._embedded(usuarios)
                    .build();
        } catch (Exception e) {
            log.error("Error al obtener los usuarios", e);
        }

        return PaginatedRepresentation.builder().build();
    }

    protected Map<String, String> createLinks(Integer page, Integer size, Integer lastPage) {
        Link self  = linkTo(methodOn(FindAllUsuariosController.class).obtenerUsuarios(page, size)).withSelfRel();
        Link first = linkTo(methodOn(FindAllUsuariosController.class).obtenerUsuarios(PaginatedRepresentation.DEFAULT_PAGE, size)).withRel(PaginationSwagger.FIRST_ELEMENT);
        Link last  = linkTo(methodOn(FindAllUsuariosController.class).obtenerUsuarios(lastPage, size)).withRel(PaginationSwagger.LAST_ELEMENT);

        Map<String, String> links = new LinkedHashMap<>();
        links.put(self.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(self.getHref()) : self.getHref());
        links.put(first.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(first.getHref()) : first.getHref());
        links.put(last.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(last.getHref()) : last.getHref());

        return links;
    }

    @Override
    @Transactional(readOnly = true)
    public Usuario findById(UUIDv4 id) throws EntityNotFoundException {
        User user = usuarioJPARepository.findById(UUID.fromString(id.getValue()))
                .orElseThrow(() -> new EntityNotFoundException(String.format("No se ha encontrado un usuario con Id: %s", id.getValue())));

        return usuarioConverter.convert(user);
    }

    @Override
    @Transactional(readOnly = true)
    public Usuario findUserByCode(BigInteger code) throws EntityNotFoundException {
        User user = usuarioJPARepository.findByCode(code)
                .orElseThrow(() -> new EntityNotFoundException(String.format("No se ha encontrado un usuario con código: %s", code)));

        return usuarioConverter.convert(user);
    }

    @Override
    @Transactional(readOnly = true)
    public Usuario findUserByRutValueObject(RutValueObject rutValueObject) throws EntityNotFoundException {
        User user = usuarioJPARepository.findByRutAndDv(rutValueObject.rut(), rutValueObject.digitoVerficador().charAt(0))
                .orElseThrow(() -> new EntityNotFoundException(String.format("No se ha encontrado un usuario con rut: %s", rutValueObject)));

        return usuarioConverter.convert(user);
    }
    
    @Transactional(readOnly = true)
    public User findByIdToUser(UUIDv4 id) throws EntityNotFoundException {
        return this.usuarioJPARepository.findById(UUID.fromString(id.getValue())).orElseThrow(
                () -> new EntityNotFoundException(String.format("No se ha encontrado un usuario con Id: %s", id.getValue()))
        );
    }
    
    @Transactional(readOnly = true)
    public User findByCodeToUser(CodigoValueObject codigo) throws EntityNotFoundException {
        return this.usuarioJPARepository.findByCode(codigo.toBigInteger()).orElseThrow(
                () -> new EntityNotFoundException(String.format("No se ha encontrado un usuario por código: %s", codigo.toBigInteger()))
        );
    }

    @Transactional(readOnly = true)
    public User findUserByRutValueObjectToUser(RutValueObject rutValueObject) throws EntityNotFoundException {
        return this.usuarioJPARepository.findByRutAndDv(rutValueObject.rut(), rutValueObject.digitoVerficador().charAt(0)).orElseThrow(
                () -> new EntityNotFoundException(String.format("No se ha encontrado un usuario con rut: %s", rutValueObject))
        );
    }
}
