package cl.chilecompra.api.shared.domain.exceptions;

public class TelefonoAlreadyExistException extends RuntimeException {

    private static final long serialVersionUID = 4256469948645572491L;

    public TelefonoAlreadyExistException (String message) {
        super (message);
    }

    public TelefonoAlreadyExistException (String message, Throwable cause) {
        super (message, cause);
    }
}
