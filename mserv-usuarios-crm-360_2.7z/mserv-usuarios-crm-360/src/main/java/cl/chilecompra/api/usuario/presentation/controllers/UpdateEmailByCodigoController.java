package cl.chilecompra.api.usuario.presentation.controllers;

import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.domain.exceptions.DomainException;
import cl.chilecompra.api.shared.domain.exceptions.EmailAlreadyExistException;
import cl.chilecompra.api.shared.domain.exceptions.InvalidEmailException;
import cl.chilecompra.api.shared.presentation.constants.MediaType;
import cl.chilecompra.api.shared.presentation.constants.Routes;
import cl.chilecompra.api.shared.presentation.controllers.AbstractController;
import cl.chilecompra.api.shared.presentation.responses.ErrorResponse;
import cl.chilecompra.api.usuario.application.DTO.Usuario;
import cl.chilecompra.api.usuario.application.command.actualizaremailporcodigo.ActualizarEmailPorCodigoCommand;
import cl.chilecompra.api.usuario.application.command.actualizaremailporcodigo.ActualizarEmailPorCodigoHandler;
import cl.chilecompra.api.usuario.presentation.forms.ActualizarPorEmailForm;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigInteger;

@Slf4j
@Api(tags = {"Usuarios"}, description = "Microservicio de usuarios CRM 360")
@RestController
@EnableAutoConfiguration
public class UpdateEmailByCodigoController extends AbstractController {

    private final ActualizarEmailPorCodigoHandler commandHandler;

    public UpdateEmailByCodigoController(ActualizarEmailPorCodigoHandler commandHanlder) {
        this.commandHandler = commandHanlder;
    }

    @ApiOperation(value = "Actualizar email de usuario por código", tags = "Usuarios")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = Usuario.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = ErrorResponse.class),
            @ApiResponse(code = 400, message = "Bad Request", response = ErrorResponse.class),
            @ApiResponse(code = 403, message = "Forbidden", response = ErrorResponse.class),
            @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class)
    })
    @PostMapping(value = Routes.UsuariosController.POST_EMAIL_USER_BY_CODE, produces = MediaType.APPLICATION_HAL_JSON)
    @CrossOrigin(value = "*", methods = RequestMethod.POST)
    public ResponseEntity<?> actualizarEmailUsuarioPorCodigo(
            @PathVariable BigInteger codigo,
            @Valid @RequestBody ActualizarPorEmailForm form
    ) {
        log.info(String.format("Obteniendo informacion del usuario por codigo: [%s]", codigo));

        try {
            return this.createOKResponse(this.commandHandler.handler(
                    new ActualizarEmailPorCodigoCommand(codigo, form.getEmail())
            ));
        } catch (DomainException | InvalidEmailException | EmailAlreadyExistException de) {
            log.info(de.getMessage());
            return this.createBadRequestResponse(de.getMessage());
        } catch (EntityNotFoundException enfe) {
            log.info(enfe.getMessage());
            return this.createNotFoundResponse(enfe.getMessage());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return this.createInternalServerErrorResponse();
        }
    }
}
