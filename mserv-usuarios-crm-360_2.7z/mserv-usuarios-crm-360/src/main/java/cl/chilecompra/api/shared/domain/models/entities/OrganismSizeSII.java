package cl.chilecompra.api.shared.domain.models.entities;

import cl.chilecompra.api.shared.domain.converters.StatusAttributeConverter;
import cl.chilecompra.api.shared.domain.models.enums.Status;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "ORGANISMOTAMANOSII")
public class OrganismSizeSII implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_ORGANISMOTAMANOSII")
    private Integer id;

    @Column(name = "TAMANO_PRINCIPAL")
    private String principalSize;

    @Column(name = "TAMANO_SUBGRP")
    private String SubGrpSize;

    @Column(name = "TRAMO_VENTA")
    private String saleLeg;

    @Column(name = "GLOSA_COMPLETA_SII")
    private String completeGlossSII;

    @Column(name = "ID_ESTADOACTIVO")
    @Convert(converter = StatusAttributeConverter.class)
    private Status status;

    @Column(name = "CREACION", nullable = false)
    private String createdBy;

    @Column(name = "CREACIONFECHA", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "ACTUALIZACION")
    private String updatedBy;

    @Column(name = "ACTUALIZACIONFECHA")
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "organismSizeSII", cascade = CascadeType.ALL)
    private Set<Organism> organisms;

    @Override
    public String toString() {
        return "OrganismSizeSII{" +
                "id=" + id +
                ", principalSize='" + principalSize + '\'' +
                ", SubGrpSize='" + SubGrpSize + '\'' +
                ", saleLeg='" + saleLeg + '\'' +
                ", completeGlossSII='" + completeGlossSII + '\'' +
                ", status=" + status +
                ", createdBy='" + createdBy + '\'' +
                ", createdAt=" + createdAt +
                ", updatedBy='" + updatedBy + '\'' +
                ", updatedAt=" + updatedAt +
                '}';
    }

    private static final long serialVersionUID = -8555356341715490446L;

}
