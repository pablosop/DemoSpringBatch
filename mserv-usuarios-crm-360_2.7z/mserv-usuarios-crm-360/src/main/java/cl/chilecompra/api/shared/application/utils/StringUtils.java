package cl.chilecompra.api.shared.application.utils;

public class StringUtils {

    public static String removePort(String input){
        return input.replaceFirst(":\\d+", "");
    }
}
