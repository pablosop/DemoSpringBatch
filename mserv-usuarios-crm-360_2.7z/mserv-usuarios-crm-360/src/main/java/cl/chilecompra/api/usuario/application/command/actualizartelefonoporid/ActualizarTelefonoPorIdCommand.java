package cl.chilecompra.api.usuario.application.command.actualizartelefonoporid;

import cl.chilecompra.api.shared.application.command.CommandInterface;
import cl.chilecompra.api.shared.domain.VO.TelefonoValueObject;
import cl.chilecompra.api.shared.domain.VO.UUIDv4;

public final class ActualizarTelefonoPorIdCommand implements CommandInterface {

    private final UUIDv4 id;
    private final TelefonoValueObject telefono;

    public ActualizarTelefonoPorIdCommand(String id, String telefono) {
        this.id = new UUIDv4(id);
        this.telefono = new TelefonoValueObject(telefono);
    }

    public UUIDv4 id() {
        return id;
    }

    public TelefonoValueObject telefono() {
        return telefono;
    }
}
