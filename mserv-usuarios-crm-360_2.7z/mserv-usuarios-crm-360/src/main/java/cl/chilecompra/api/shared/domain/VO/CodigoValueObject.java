package cl.chilecompra.api.shared.domain.VO;

import java.math.BigInteger;
import java.util.Objects;

public final class CodigoValueObject implements ValueObject {

    private final BigInteger codigo;

    public CodigoValueObject(BigInteger codigo) {
        this.codigo = codigo;
    }

    public BigInteger toBigInteger() {
        return codigo;
    }

    @Override
    public boolean equals(Object otro) {
        if (otro == null || getClass() != otro.getClass()) return false;
        CodigoValueObject cvo = (CodigoValueObject) otro;
        return Objects.equals(codigo, cvo.codigo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo);
    }
}
