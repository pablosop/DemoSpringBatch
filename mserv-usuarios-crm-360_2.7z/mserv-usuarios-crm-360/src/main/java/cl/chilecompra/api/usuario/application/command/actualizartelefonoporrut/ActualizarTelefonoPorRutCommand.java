package cl.chilecompra.api.usuario.application.command.actualizartelefonoporrut;

import cl.chilecompra.api.shared.application.command.CommandInterface;
import cl.chilecompra.api.shared.domain.VO.RutValueObject;
import cl.chilecompra.api.shared.domain.VO.TelefonoValueObject;

public final class ActualizarTelefonoPorRutCommand implements CommandInterface {

    private final RutValueObject rut;
    private final TelefonoValueObject telefono;

    public ActualizarTelefonoPorRutCommand(String rut, String telefono) {
        this.rut = new RutValueObject(rut);
        this.telefono = new TelefonoValueObject(telefono);
    }

    public RutValueObject rut() {
        return rut;
    }

    public TelefonoValueObject telefono() {
        return telefono;
    }
}
