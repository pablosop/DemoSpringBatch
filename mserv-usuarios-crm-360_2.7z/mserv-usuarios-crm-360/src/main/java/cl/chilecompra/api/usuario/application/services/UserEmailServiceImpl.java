package cl.chilecompra.api.usuario.application.services;

import cl.chilecompra.api.shared.domain.VO.EmailValueObject;
import cl.chilecompra.api.shared.domain.models.entities.User;
import cl.chilecompra.api.shared.domain.models.entities.UserEmail;
import cl.chilecompra.api.usuario.domain.service.UserEmailServiceInterface;
import cl.chilecompra.api.usuario.infrastructure.repositories.UserEmailJPARepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
public class UserEmailServiceImpl implements UserEmailServiceInterface {

    private final UserEmailJPARepository userEmailRepository;

    public UserEmailServiceImpl(UserEmailJPARepository userEmailRepository) {
        this.userEmailRepository = userEmailRepository;
    }

    @Transactional(readOnly = true)
    public List<UserEmail> findAllByUserAndEmail(User user, EmailValueObject email) {
        return this.userEmailRepository.findAllByUserAndEmail(user, email.toString());
    }

    @Override
    public void save(UserEmail userEmail) {
        this.userEmailRepository.saveAndFlush(userEmail);
    }
}
