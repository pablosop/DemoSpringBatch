package cl.chilecompra.api.usuario.application.command.actualizaremailporid;

import cl.chilecompra.api.shared.application.command.CommandInterface;
import cl.chilecompra.api.shared.domain.VO.EmailValueObject;
import cl.chilecompra.api.shared.domain.VO.UUIDv4;

public final class ActualizarEmailPorIdCommand implements CommandInterface {
    
    private final UUIDv4 id;
    private final EmailValueObject email;

    public ActualizarEmailPorIdCommand(String id, String email) {
        this.id = new UUIDv4(id);
        this.email = new EmailValueObject(email);
    }

    public UUIDv4 id() {
        return id;
    }

    public EmailValueObject email() {
        return email;
    }
}
