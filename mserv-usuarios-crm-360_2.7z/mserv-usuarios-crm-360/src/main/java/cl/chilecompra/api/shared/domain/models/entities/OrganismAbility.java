package cl.chilecompra.api.shared.domain.models.entities;

import cl.chilecompra.api.shared.domain.converters.StatusAttributeConverter;
import cl.chilecompra.api.shared.domain.models.enums.Status;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "ORGANISMOHABILIDAD")
public class OrganismAbility implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_ORGANISMOHABILIDAD")
    private Integer id;

    @Column(name = "ORGANISMOHABILIDAD", nullable = false)
    private String organismAbility;

    @Convert(converter = StatusAttributeConverter.class)
    @Column(name = "ID_ESTADOACTIVO", nullable = false)
    private Status status;

    @Column(name = "CREACION", nullable = false)
    private String createdBy;

    @Column(name = "CREACIONFECHA", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "ACTUALIZACION")
    private String updatedBy;

    @Column(name = "ACTUALIZACIONFECHA")
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "organismAbility", cascade = CascadeType.ALL)
    private Set<Organism> organisms;

    @Override
    public String toString() {
        return "OrganismAbility{" +
                "id=" + id +
                ", organismAbility='" + organismAbility + '\'' +
                ", status=" + status +
                ", createdBy='" + createdBy + '\'' +
                ", createdAt=" + createdAt +
                ", updatedBy='" + updatedBy + '\'' +
                ", updatedAt=" + updatedAt +
                '}';
    }

    private static final long serialVersionUID = -7432207471492174737L;

}
