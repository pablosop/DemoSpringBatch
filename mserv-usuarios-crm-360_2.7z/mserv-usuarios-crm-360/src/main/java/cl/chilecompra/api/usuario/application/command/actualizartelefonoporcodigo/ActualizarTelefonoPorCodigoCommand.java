package cl.chilecompra.api.usuario.application.command.actualizartelefonoporcodigo;

import cl.chilecompra.api.shared.application.command.CommandInterface;
import cl.chilecompra.api.shared.domain.VO.CodigoValueObject;
import cl.chilecompra.api.shared.domain.VO.TelefonoValueObject;

import java.math.BigInteger;

public final class ActualizarTelefonoPorCodigoCommand implements CommandInterface {

    private final CodigoValueObject codigo;
    private final TelefonoValueObject telefono;

    public ActualizarTelefonoPorCodigoCommand(BigInteger codigo, String telefono) {
        this.codigo = new CodigoValueObject(codigo);
        this.telefono = new TelefonoValueObject(telefono);
    }

    public CodigoValueObject codigo() {
        return codigo;
    }

    public TelefonoValueObject telefono() {
        return telefono;
    }
}
