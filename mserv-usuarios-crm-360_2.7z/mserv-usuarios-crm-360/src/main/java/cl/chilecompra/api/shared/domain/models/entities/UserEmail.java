package cl.chilecompra.api.shared.domain.models.entities;

import cl.chilecompra.api.shared.domain.VO.EmailValueObject;
import cl.chilecompra.api.shared.domain.converters.StatusAttributeConverter;
import cl.chilecompra.api.shared.domain.exceptions.EmailAlreadyExistException;
import cl.chilecompra.api.shared.domain.models.enums.Status;
import cl.chilecompra.api.shared.domain.repository.UniqueEmailSpecificationInterface;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "EMAIL_USUARIO")
public class UserEmail implements Serializable {

    public static final int LENGTH = 320;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(columnDefinition = "bigint")
    private BigInteger id;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "ID_USUARIO", nullable = false)
    private User user;

    @Column(name = "EMAIL_USUARIO", nullable = false, length = LENGTH)
    private String email;

    @Column(name = "ID_ESTADOACTIVO", nullable = false)
    @Convert(converter = StatusAttributeConverter.class)
    private Status status;

    @Column(name = "CREACION", nullable = false)
    private String createdBy;

    @Column(name = "CREACIONFECHA", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "ACTUALIZACION")
    private String updatedBy;

    @Column(name = "ACTUALIZACIONFECHA")
    private LocalDateTime updatedAt;

    private static final long serialVersionUID = -3247098458168507855L;

    public UserEmail() {

    }

    public UserEmail(
            User user,
            EmailValueObject email,
            String creadoPor,
            UniqueEmailSpecificationInterface uniqueEmailSpecification
    ) {

        if (uniqueEmailSpecification.isSatisfiedBy(user, email)) {
            throw new EmailAlreadyExistException(
                    String.format("El email %s, ya existe para este usuario.", email.toString())
            );
        }

        this.setUser(user);
        this.setEmail(email.toString());
        this.setCreatedAt(java.time.LocalDateTime.now());
        this.setCreatedBy(creadoPor);
        this.setStatus(Status.PENDIENTE_POR_VALIDAR);
    }
}
