package cl.chilecompra.api.institucion.application.converters;

import cl.chilecompra.api.institucion.application.DTO.Rol;
import cl.chilecompra.api.institucion.presentation.controllers.FindAllRolesController;
import cl.chilecompra.api.institucion.presentation.controllers.FindRolByCodigoController;
import cl.chilecompra.api.institucion.presentation.controllers.FindRolByIdController;
import cl.chilecompra.api.shared.application.exceptions.ConversionException;
import cl.chilecompra.api.shared.application.utils.StringUtils;
import cl.chilecompra.api.shared.domain.models.entities.Role;
import cl.chilecompra.api.shared.presentation.DTO.PaginatedRepresentation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.convert.converter.Converter;
import org.springframework.hateoas.Link;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Slf4j
@Component
public class RolConverter implements Converter<Role, Rol> {

    @Value("${hateoas.without.port}")
    private boolean WITHOUT_PORT;

    @Override
    public Rol convert(Role role) {
        log.debug(String.format("Convirtiendo objeto %s", role.toString()));

        try {
            return Rol.builder()
                    .id(role.getId())
                    .rol(role.getRole())
                    .codigo(role.getCode())
                    .creadoEn(role.getCreatedAt())
                    .creadoPor(role.getCreatedBy())
                    .actualizadoEn(role.getUpdatedAt())
                    .actualizadoPor(role.getUpdatedBy())
                    ._links(createLinks(role))
                    .build();
        } catch (Exception e) {
            throw new ConversionException("Error al convertir un rol", e);
        }
    }

    private Map<String, String> createLinks(Role role) {
        Link self       = linkTo(methodOn(FindRolByIdController.class).buscarRolPorId(role.getId().toString())).withSelfRel();
        Link selfCodigo = linkTo(methodOn(FindRolByCodigoController.class).buscarRolPorCodigo(role.getCode())).withRel("codigo");
        Link get        = linkTo(methodOn(FindAllRolesController.class).obtenerRoles(PaginatedRepresentation.DEFAULT_PAGE, PaginatedRepresentation.DEFAULT_SIZE)).withRel("roles");

        Map<String, String> links = new LinkedHashMap<>();
        links.put(self.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(self.getHref()) : self.getHref());
        links.put(selfCodigo.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(selfCodigo.getHref()) : selfCodigo.getHref());
        links.put(get.getRel().value(), WITHOUT_PORT ? StringUtils.removePort(get.getHref()) : get.getHref());

        return links;
    }
}
