package cl.chilecompra.api.institucion.presentation.controllers;

import cl.chilecompra.api.institucion.application.DTO.Rol;
import cl.chilecompra.api.institucion.domain.service.RolServiceInterface;
import cl.chilecompra.api.shared.application.exceptions.EntityNotFoundException;
import cl.chilecompra.api.shared.domain.exceptions.DomainException;
import cl.chilecompra.api.shared.presentation.constants.MediaType;
import cl.chilecompra.api.shared.presentation.constants.Routes;
import cl.chilecompra.api.shared.presentation.controllers.AbstractController;
import cl.chilecompra.api.shared.presentation.responses.ErrorResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;

@Slf4j
@Api(tags = {"Roles"}, description = "Microservicio de roles CRM 360")
@RestController
@EnableAutoConfiguration
public class FindRolByCodigoController extends AbstractController {

    private final RolServiceInterface rolService;

    public FindRolByCodigoController(RolServiceInterface rolService) {
        this.rolService = rolService;
    }

    @ApiOperation(value = "Obtener rol por codigo", tags = "Roles")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = Rol.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = ErrorResponse.class),
            @ApiResponse(code = 403, message = "Forbidden", response = ErrorResponse.class),
            @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class)
    })
    @GetMapping(value = Routes.RolesController.GET_ROLE_BY_CODE, produces = MediaType.APPLICATION_HAL_JSON)
    @CrossOrigin(value = "*", methods = RequestMethod.GET)
    public ResponseEntity<?> buscarRolPorCodigo(@PathVariable BigInteger codigo) {
        log.info(String.format("Obteniendo informacion del rol codigo: [%s]", codigo));

        try {
            return this.createOKResponse(rolService.findRoleByCode(codigo));
        } catch (DomainException de) {
            log.info(de.getMessage());
            return this.createBadRequestResponse(de.getMessage());
        } catch (EntityNotFoundException enfe) {
            log.info(enfe.getMessage());
            return this.createNotFoundResponse(enfe.getMessage());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return this.createInternalServerErrorResponse();
        }

    }
}
