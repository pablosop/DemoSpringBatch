package cl.chilecompra.api.shared.domain.models.entities;

import cl.chilecompra.api.shared.domain.VO.TelefonoValueObject;
import cl.chilecompra.api.shared.domain.converters.StatusAttributeConverter;
import cl.chilecompra.api.shared.domain.exceptions.TelefonoAlreadyExistException;
import cl.chilecompra.api.shared.domain.models.enums.Status;
import cl.chilecompra.api.shared.domain.repository.UniqueTelefonoSpecificationInterface;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "TELEFONO_USUARIO")
public class UserPhone implements Serializable {

    public static final int LENGTH = 15;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(columnDefinition = "bigint")
    private BigInteger id;

    @ManyToOne
    @JoinColumn(name = "ID_USUARIO", nullable = false)
    private User user;

    @Column(name = "TELEFONO", nullable = false, length = LENGTH)
    private String phone;

    @Column(name = "ID_ESTADOACTIVO", nullable = false)
    @Convert(converter = StatusAttributeConverter.class)
    private Status status;

    @Column(name = "CREACION", nullable = false)
    private String createdBy;

    @Column(name = "CREACIONFECHA", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "ACTUALIZACION")
    private String updatedBy;

    @Column(name = "ACTUALIZACIONFECHA")
    private LocalDateTime updatedAt;

    private static final long serialVersionUID = -7927783185362333571L;

    public UserPhone() {
    }

    public UserPhone(
            User user,
            TelefonoValueObject telefono,
            String creadoPor,
            UniqueTelefonoSpecificationInterface uniqueTelefonoSpecification
    ) {
        if (uniqueTelefonoSpecification.isSatisfiedBy(user, telefono)) {
            throw new TelefonoAlreadyExistException(
                    String.format("El teléfono %s, ya existe para este usuario.", telefono.toString())
            );
        }

        this.setUser(user);
        this.setPhone(telefono.toString());
        this.setCreatedAt(java.time.LocalDateTime.now());
        this.setCreatedBy(creadoPor);
        this.setStatus(Status.PENDIENTE_POR_VALIDAR);
    }
}
