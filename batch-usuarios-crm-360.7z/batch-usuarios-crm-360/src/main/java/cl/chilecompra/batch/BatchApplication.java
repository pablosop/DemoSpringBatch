package cl.chilecompra.batch;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;

@EnableBatchProcessing
@SpringBootApplication()
//		exclude = {
//		    org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration.class,
//		    org.springframework.boot.autoconfigure.sql.init.SqlInitializationAutoConfiguration.class
//	})
@PropertySource("classpath:values.properties")
public class BatchApplication {
    public static void main(String[] args) {
        SpringApplication.run(BatchApplication.class, args);
    }
}
