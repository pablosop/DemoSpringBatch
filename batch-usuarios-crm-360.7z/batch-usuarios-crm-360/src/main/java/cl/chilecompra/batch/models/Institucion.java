package cl.chilecompra.batch.models;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Data;


public class Institucion {


    private String id_institucion;

    @Column(name = "CODIGO", nullable = false, unique = true)
    private Long codigo;

    @Column(name = "INSTITUCION", nullable = false, length = 255)
    private String institucion;

    @Column(name = "CREACION", nullable = false, length = 255)
    private String creacion;

    @Column(name = "CREACIONFECHA", nullable = false)
    private LocalDateTime creacionFecha;

    @Column(name = "ACTUALIZACION", length = 255)
    private String actualizacion;

    @Column(name = "ACTUALIZACIONFECHA")
    private LocalDateTime actualizacionFecha;


// Campos de tabla de origen

    private long entID;

    private String entName;
    

    // Getters y setters


    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getInstitucion() {
        return institucion;
    }

    public void setInstitucion(String institucion) {
        this.institucion = institucion;
    }

    public String getCreacion() {
        return creacion;
    }

    public void setCreacion(String creacion) {
        this.creacion = creacion;
    }

    public LocalDateTime getCreacionFecha() {
        return creacionFecha;
    }

    public void setCreacionFecha(LocalDateTime creacionFecha) {
        this.creacionFecha = creacionFecha;
    }

    public String getActualizacion() {
        return actualizacion;
    }

    public void setActualizacion(String actualizacion) {
        this.actualizacion = actualizacion;
    }

    public LocalDateTime getActualizacionFecha() {
        return actualizacionFecha;
    }

    public void setActualizacionFecha(LocalDateTime actualizacionFecha) {
        this.actualizacionFecha = actualizacionFecha;
    }

    public void setId_institucion(String id_institucion){
        this.id_institucion = id_institucion;

    }

    public String getId_institucion(){
        return id_institucion;
    }

    public long getEntID() {
        return entID;
    }

    public void setEntID(long entID) {
        this.entID = entID;
    }

    public String getEntName() {
        return entName;
    }

    public void setEntName(String entName) {
        this.entName = entName;
    }
    

}

