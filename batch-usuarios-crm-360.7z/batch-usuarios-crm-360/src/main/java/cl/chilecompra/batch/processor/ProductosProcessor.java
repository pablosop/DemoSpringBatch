package cl.chilecompra.batch.processor;


import java.util.UUID;

import cl.chilecompra.batch.models.Producto;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ProductosProcessor implements org.springframework.batch.item.ItemProcessor<Producto, Producto> {
    @Override
    public Producto process(Producto item) throws Exception {
        //log.info("Pasa por el procesor:" + item);
        item.setCodigoNegocio(item.getCodigo());
        UUID uuid = UUID.randomUUID();
        item.setCodigoGenerado(uuid.toString());
        return item;
    }
}	
	


