package cl.chilecompra.batch.models;

import lombok.Data;

@Data
public class RubrosProv {

	private Integer OrgCode;
    private String Nivel3;
    
}
