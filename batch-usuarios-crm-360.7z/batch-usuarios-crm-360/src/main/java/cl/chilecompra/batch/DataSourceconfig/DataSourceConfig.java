package cl.chilecompra.batch.DataSourceconfig;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class})
public class DataSourceConfig {

    @Value("${spring.datasource.url}")
    private String datasourceURLSQL;


	@Primary
    @Bean(name = "dataSource")
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        dataSource.setUrl(datasourceURLSQL);
        dataSource.setUsername("sa");
        dataSource.setPassword("123qwe");
        return dataSource;
    }

    @Bean(name = "origenDataSource")
    public DataSource origenDataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        dataSource.setUrl("jdbc:sqlserver://10.34.71.146\\\\Aquiles_Consulta:1433;databaseName=DCCPPlatform;encrypt=false;trustServerCertificate=true");
        dataSource.setUsername("crm360");
        dataSource.setPassword("Chilecompra.2024!");
        return dataSource;
    }

    
    @Bean(name = "destinoDataSource")
    public DataSource targetDataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.mariadb.jdbc.Driver");
        dataSource.setUrl("jdbc:mariadb://localhost:3307/dccpusuarioscrm360");
        dataSource.setUsername("root");
        dataSource.setPassword("123qwe");
        return dataSource;
    }

    @Bean(name = "jobControlDataSourceDesa")
    public DataSource jobControlDataSourceDesa() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        dataSource.setUrl("jdbc:sqlserver://10.34.75.198\\\\MP_SQL_DESA:1433;databaseName=batchjobs;encrypt=false;trustServerCertificate=true");
        dataSource.setUsername("user_batch_jobs");
        dataSource.setPassword("mBjJzv2bnkzA8QwC3JZe");
        return dataSource;
    }

    
	
}
