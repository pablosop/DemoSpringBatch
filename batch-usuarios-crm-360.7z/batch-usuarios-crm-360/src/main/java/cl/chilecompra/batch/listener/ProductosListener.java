package cl.chilecompra.batch.listener;


import org.springframework.batch.core.ItemReadListener;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import cl.chilecompra.batch.models.Producto;

@Component
@ConditionalOnProperty(name = "listener.productosItemRead.enabled", havingValue = "true", matchIfMissing = false)
public class ProductosListener implements ItemReadListener<Producto> {

    @Override
    public void beforeRead() {
        System.out.println("Iniciando lectura de un registro...");
    }

    @Override
    public void afterRead(Producto item) {
        System.out.println("Registro leído: " + item);
    }

    @Override
    public void onReadError(Exception ex) {
        System.err.println("Error al leer registro: " + ex.getMessage());
    }
}
