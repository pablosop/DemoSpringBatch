package cl.chilecompra.batch.config;

import javax.sql.DataSource;


import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.transaction.PlatformTransactionManager;

import cl.chilecompra.batch.listener.RubrosItemReadListener;
import cl.chilecompra.batch.models.RubrosProv;
import cl.chilecompra.batch.processor.RubrosProvProcessor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
//@Configuration
public class BatchConfig {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;
    private final DataSource jobControlDataSourceDesa;
    
    private final RubrosItemReadListener rubrosItemReadListener;
    
    public BatchConfig(JobRepository jobRepository, PlatformTransactionManager transactionManager,
                       @Qualifier("jobControlDataSourceDesa") DataSource jobControlDataSourceDesa,
                       @Qualifier("destinoDataSource") DataSource targetDataSource,
                       @Qualifier("sourceDataSource") DataSource sourceDataSource,
                       @Autowired(required = false) RubrosItemReadListener rubrosItemReadListener){
                        this.jobRepository = jobRepository;
                        this.transactionManager = transactionManager;
                        this.jobControlDataSourceDesa = jobControlDataSourceDesa;
                        this.targetDataSource = targetDataSource;
                        this.rubrosItemReadListener = rubrosItemReadListener;
                        this.sourceDataSource = sourceDataSource;
                    }

    // 2.3: Item Reader - Reads data from SQL Server
    @Bean
    public JdbcCursorItemReader<RubrosProv> reader() {
    	log.info("Leyendo datos");
    	JdbcCursorItemReader<RubrosProv> listado = new JdbcCursorItemReaderBuilder<RubrosProv>()
                .name("RubrosProvReader")
                .dataSource(sourceDataSource)
                .sql("select top 1000000 orgCode, nivel3 from dbo.Rubros_Prov")
                .rowMapper(new BeanPropertyRowMapper<>(RubrosProv.class))
                .build();
    	return listado;
    }
    
    
    public void testReader() throws Exception {
    	log.info("Testing");
        JdbcCursorItemReader<RubrosProv> reader = reader();
        reader.open(new ExecutionContext());
        RubrosProv item;
        while ((item = reader.read()) != null) {
            System.out.println("Item leído: " + item);
        }
        reader.close();
    }
    
    // 2.4: Item Processor - Optional data transformation
    @Bean
    public RubrosProvProcessor processor() {
        return new RubrosProvProcessor();
    }

    // 2.5: Item Writer - Writes data to MariaDB
    @Bean
    public JdbcBatchItemWriter<RubrosProv> writer() {
    	log.info("Insertando");
        return new JdbcBatchItemWriterBuilder<RubrosProv>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO Rubros_Prov (orgCode, nivel3) VALUES (:orgCode, :nivel3)")
                .dataSource(targetDataSource)
                .build();
    }

    // 2.6: Step Configuration
    @Bean
    public Step step1() {
        return new StepBuilder("step1", jobRepository)
                .<RubrosProv, RubrosProv>chunk(10, transactionManager)
                .reader(reader())
                .listener(rubrosItemReadListener)
                .processor(processor())
                .writer(writer())            
                .build();
    }

    // 2.7: Job Configuration
    @Bean
    public Job importJob() {
        return new JobBuilder("importJob", jobRepository)
                .start(step1())
                .build();
    }
}
