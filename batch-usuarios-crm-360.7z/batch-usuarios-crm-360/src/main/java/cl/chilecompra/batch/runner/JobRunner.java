package cl.chilecompra.batch.runner;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class JobRunner implements CommandLineRunner {

    private final JobLauncher jobLauncher;
    private final Job importJob;

    public JobRunner(JobLauncher jobLauncher, @Qualifier("importJob") Job importJob) {
        this.jobLauncher = jobLauncher;
        this.importJob = importJob;
    }

    @Override
    public void run(String... args) throws Exception {
        JobParameters jobParameters = new JobParametersBuilder()
                .addLong("time", System.currentTimeMillis()) // Para asegurar un Job ID único
                .toJobParameters();

        JobExecution execution = jobLauncher.run(importJob, jobParameters);
        System.out.println("Estado del Job: " + execution.getStatus());
    }
}
