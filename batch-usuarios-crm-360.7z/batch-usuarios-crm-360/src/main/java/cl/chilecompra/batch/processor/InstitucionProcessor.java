package cl.chilecompra.batch.processor;


import java.util.UUID;

import cl.chilecompra.batch.models.Institucion;
import cl.chilecompra.batch.models.RubrosProv;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class InstitucionProcessor implements org.springframework.batch.item.ItemProcessor<Institucion, Institucion> {
    @Override
    public Institucion process(Institucion item) throws Exception {
        //log.info("Pasa por el procesor:" + item);        
        UUID uuid = UUID.randomUUID();
        item.setId_institucion(uuid.toString());
        item.setCodigo(item.getEntID());
        item.setInstitucion(item.getEntName());
        item.setCreacion("ETLSpringBatch");
        item.setCreacionFecha(item.getCreacionFecha());
        item.setActualizacionFecha(item.getActualizacionFecha());
        return item;
    }
}	
