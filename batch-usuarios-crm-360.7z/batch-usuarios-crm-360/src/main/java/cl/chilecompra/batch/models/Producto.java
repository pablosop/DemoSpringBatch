package cl.chilecompra.batch.models;

import lombok.Data;

@Data
public class Producto {

    private Integer codigo;
    private String descripcion;
    private Integer codigoNegocio;
    private String codigoGenerado;


}
