package cl.chilecompra.batch.config;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.transaction.PlatformTransactionManager;

import cl.chilecompra.batch.listener.RubrosItemReadListener;
import cl.chilecompra.batch.models.Institucion;
import cl.chilecompra.batch.processor.InstitucionProcessor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
//@Configuration
public class InstitucionBatchConfig {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource sourceDataSource;
    private final DataSource targetDataSource;
    
    private final RubrosItemReadListener rubrosItemReadListener;
    
    public InstitucionBatchConfig(JobRepository jobRepository, PlatformTransactionManager transactionManager,
                       @Qualifier("origenDataSource") DataSource sourceDataSource,
                       @Qualifier("destinoDataSource") DataSource targetDataSource,
                       @Autowired(required = false) RubrosItemReadListener rubrosItemReadListener) {
        this.jobRepository = jobRepository;
        this.transactionManager = transactionManager;
        this.sourceDataSource = sourceDataSource;
        this.targetDataSource = targetDataSource;
        this.rubrosItemReadListener = rubrosItemReadListener;
    }

    // 2.3: Item Reader - Reads data from SQL Server
    @Bean
    public JdbcCursorItemReader<Institucion> reader() {
    	log.info("Leyendo datos");
    	JdbcCursorItemReader<Institucion> listado = new JdbcCursorItemReaderBuilder<Institucion>()
                .name("InstitucionReader")
                .dataSource(sourceDataSource)
                .sql("select e.entID, e.entName from dbo.gblenterprise e JOIN  dbo.gblOrganization o on e.entcode = o.orgenterprise" + 
                 "WHERE e.entIsActive = 1 AND and o.orgIsActive = 1 AND and o.orgClass = 2 group by e.entID, e.entName")
                .rowMapper(new BeanPropertyRowMapper<>(Institucion.class))
                .build();
    	return listado;
    }
    
    
    public void testReader() throws Exception {
    	log.info("Testing");
        JdbcCursorItemReader<Institucion> reader = reader();
        reader.open(new ExecutionContext());
        Institucion item;
        while ((item = reader.read()) != null) {
            System.out.println("Item leído: " + item);
        }
        reader.close();
    }
    
    // 2.4: Item Processor - Optional data transformation
    @Bean
    public InstitucionProcessor processor() {
        return new InstitucionProcessor();
    }

    // 2.5: Item Writer - Writes data to MariaDB
    @Bean
    public JdbcBatchItemWriter<Institucion> writer() {
    	log.info("Insertando");
        return new JdbcBatchItemWriterBuilder<Institucion>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO INSTITUCION (ID_INSTITUCION, CODIGO, INSTITUCION, CREACION, CREACIONFECHA, ACTUALIZACION, ACTUALIZACIONFECHA)" + 
                "VALUES (:id_institucion, :entID, :entName, )")
                .dataSource(targetDataSource)
                .build();
    }

    // 2.6: Step Configuration
    @Bean
    public Step step1() {
        return new StepBuilder("step1", jobRepository)
                .<Institucion, Institucion>chunk(10, transactionManager)
                .reader(reader())
                .listener(rubrosItemReadListener)
                .processor(processor())
                .writer(writer())            
                .build();
    }

    // 2.7: Job Configuration
    @Bean
    public Job importJob() {
        return new JobBuilder("importJob", jobRepository)
                .start(step1())
                .build();
    }
}

