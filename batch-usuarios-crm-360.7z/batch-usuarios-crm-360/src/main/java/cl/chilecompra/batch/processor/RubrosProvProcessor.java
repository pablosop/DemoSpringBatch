package cl.chilecompra.batch.processor;

import cl.chilecompra.batch.models.RubrosProv;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RubrosProvProcessor implements org.springframework.batch.item.ItemProcessor<RubrosProv, RubrosProv> {
    @Override
    public RubrosProv process(RubrosProv item) throws Exception {
        //log.info("Pasa por el procesor:" + item);
        item.setOrgCode(item.getOrgCode());
        return item;
    }
}	
	

