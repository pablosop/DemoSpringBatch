package cl.chilecompra.batch.config;

import javax.sql.DataSource;


import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.transaction.PlatformTransactionManager;

import cl.chilecompra.batch.listener.ProductosListener;
import cl.chilecompra.batch.listener.RubrosItemReadListener;
import cl.chilecompra.batch.models.Producto;
import cl.chilecompra.batch.models.RubrosProv;
import cl.chilecompra.batch.processor.ProductosProcessor;
import cl.chilecompra.batch.processor.RubrosProvProcessor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class ProductoBatchConfig {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final DataSource dataSource;
    private final DataSource targetDataSource;
    private final DataSource jobControlDataSourceDesa;
    
    private final ProductosListener productosListener;
    
    public ProductoBatchConfig(JobRepository jobRepository, PlatformTransactionManager transactionManager,
                       @Qualifier("jobControlDataSourceDesa") DataSource jobControlDataSourceDesa,
                       @Qualifier("destinoDataSource") DataSource targetDataSource,
                       @Qualifier("dataSource") DataSource dataSource,
                       @Autowired(required = false) ProductosListener productosListener){
                        this.jobRepository = jobRepository;
                        this.transactionManager = transactionManager;
                        this.jobControlDataSourceDesa = jobControlDataSourceDesa;
                        this.targetDataSource = targetDataSource;
                        this.productosListener = productosListener;
                        this.dataSource = dataSource;
                    }

    // 2.3: Item Reader - Reads data from SQL Server
    @Bean
    public JdbcCursorItemReader<Producto> reader() {
    	log.info("Leyendo datos");
    	JdbcCursorItemReader<Producto> listado = new JdbcCursorItemReaderBuilder<Producto>()
                .name("ProductosReader")
                .dataSource(dataSource)
                .sql("select top 1000000 codigo, descripcion from dbo.producto")
                .rowMapper(new BeanPropertyRowMapper<>(Producto.class))
                .build();
    	return listado;
    }
    
    
    public void testReader() throws Exception {
    	log.info("Testing");
        JdbcCursorItemReader<Producto> reader = reader();
        reader.open(new ExecutionContext());
        Producto item;
        while ((item = reader.read()) != null) {
            System.out.println("Item leído: " + item);
        }
        reader.close();
    }
    
    // 2.4: Item Processor - Optional data transformation
    @Bean
    public ProductosProcessor processor() {
        return new ProductosProcessor();
    }

    // 2.5: Item Writer - Writes data to MariaDB
    @Bean
    public JdbcBatchItemWriter<Producto> writer() {
    	log.info("Insertando");
        return new JdbcBatchItemWriterBuilder<Producto>()
                .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
                .sql("INSERT INTO producto (codigoGenerado, codigoNegocio, descripcion) VALUES (:codigoGenerado, :codigoNegocio, :descripcion) ON DUPLICATE KEY UPDATE descripcion = :descripcion")
                .dataSource(targetDataSource)
                .build();
    }

    // 2.6: Step Configuration
    @Bean
    public Step step1() {
        return new StepBuilder("step1", jobRepository)
                .<Producto, Producto>chunk(10, transactionManager)
                .reader(reader())
                .listener(productosListener)
                .processor(processor())
                .writer(writer())            
                .build();
    }

    // 2.7: Job Configuration
    @Bean
    public Job importJob() {
        return new JobBuilder("importJob", jobRepository)
                .start(step1())
                .build();
    }
}

