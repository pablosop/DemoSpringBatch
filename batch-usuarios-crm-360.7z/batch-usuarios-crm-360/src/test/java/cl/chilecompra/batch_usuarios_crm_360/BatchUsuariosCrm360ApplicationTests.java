package cl.chilecompra.batch_usuarios_crm_360;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatchUsuariosCrm360ApplicationTests {

	@Test
	void contextLoads() {
	}

}
